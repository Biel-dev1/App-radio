package com.gabriel.radioamigos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val serviceName = "RadioAmigos"
    private val serviceUuid: UUID = UUID.fromString("f47ac10b-58cc-4372-a567-0e02b2c3d479")
    private lateinit var statusText: TextView
    private lateinit var peerText: TextView
    private lateinit var talkButton: Button
    private lateinit var connectButton: Button
    private lateinit var serverButton: Button
    private lateinit var pairButton: Button
    private var adapter: BluetoothAdapter? = null
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var serverSocket: BluetoothServerSocket? = null
    private val transmitting = AtomicBoolean(false)
    @Volatile private var connected = false
    @Volatile private var audioRunning = false
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private val sampleRate = 16000
    private val frameBytes = 640 // 20 ms, mono, PCM 16-bit
    private val permissions = if (Build.VERSION.SDK_INT >= 31) arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.BLUETOOTH_ADVERTISE
    ) else arrayOf(Manifest.permission.RECORD_AUDIO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        buildUi()
        updateUi()
        if (!hasPermissions()) requestPermissions(permissions, 20)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(Color.rgb(11, 18, 32))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "📻 Rádio Amigos"
            textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Converse por Bluetooth, sem internet"
            textSize = 15f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0, 8, 0, 22)
        }
        statusText = TextView(this).apply {
            textSize = 17f; setTextColor(Color.rgb(125, 211, 252)); gravity = Gravity.CENTER
            setPadding(0, 10, 0, 6)
        }
        peerText = TextView(this).apply {
            text = "Passo 1: emparelhe os dois celulares nas configurações Bluetooth."
            textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0, 8, 0, 14)
        }
        pairButton = makeButton("1. Abrir configurações Bluetooth")
        serverButton = makeButton("2. Esperar conexão (neste celular)")
        connectButton = makeButton("3. Conectar ao celular emparelhado")
        talkButton = makeButton("SEGURE PARA FALAR")
        talkButton.textSize = 20f
        talkButton.setBackgroundColor(Color.rgb(14, 165, 233))
        talkButton.setTextColor(Color.WHITE)
        talkButton.minHeight = dp(90)
        talkButton.isEnabled = false
        val disconnectButton = makeButton("Desconectar")
        val help = TextView(this).apply {
            text = "Como usar:\n• Emparelhe os celulares pelo Bluetooth do Android.\n• No celular A, toque em “Esperar conexão”.\n• No celular B, toque em “Conectar” e escolha o celular A.\n• Quando aparecer Conectado, segure o botão azul para falar e solte para terminar.\n\nO app precisa da permissão do microfone. Bluetooth tem alcance limitado e paredes podem reduzir o sinal."
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(4, 20, 4, 16)
        }
        content.addView(title); content.addView(subtitle); content.addView(statusText)
        content.addView(peerText); content.addView(pairButton); content.addView(serverButton)
        content.addView(connectButton); content.addView(talkButton); content.addView(disconnectButton)
        content.addView(help); scroll.addView(content); root.addView(scroll); setContentView(root)

        pairButton.setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }
        serverButton.setOnClickListener { startServer() }
        connectButton.setOnClickListener { showPairedDevices() }
        disconnectButton.setOnClickListener { disconnect("Desconectado") }
        talkButton.setOnTouchListener { _, event ->
            if (!connected) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { transmitting.set(true); talkButton.text = "FALANDO… SOLTE PARA PARAR"; true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { transmitting.set(false); talkButton.text = "SEGURE PARA FALAR"; true }
                else -> true
            }
        }
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label; textSize = 15f; isAllCaps = false
        setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(36, 52, 77))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(5), 0, dp(5)); layoutParams = lp
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasPermissions() = permissions.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(requestCode: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, perms, results)
        if (requestCode == 20) {
            if (!hasPermissions()) toast("Permissões necessárias: microfone e Bluetooth. Ative-as para usar o rádio.")
            updateUi()
        }
    }

    private fun updateUi(message: String? = null) {
        runOnUiThread {
            statusText.text = message ?: if (connected) "● CONECTADO" else "○ Não conectado"
            talkButton.isEnabled = connected && hasPermissions()
            connectButton.isEnabled = !connected
            serverButton.isEnabled = !connected
        }
    }

    private fun startServer() {
        if (!checkReady()) return
        thread(name = "bt-server") {
            try {
                val a = adapter ?: throw IllegalStateException("Bluetooth não disponível")
                if (!a.isEnabled) { runOnUiThread { toast("Ative o Bluetooth primeiro.") }; return@thread }
                serverSocket = a.listenUsingRfcommWithServiceRecord(serviceName, serviceUuid)
                updateUi("Aguardando seu amigo…")
                val accepted = serverSocket!!.accept()
                serverSocket?.close(); serverSocket = null
                attachSocket(accepted)
            } catch (e: Exception) {
                updateUi("Não foi possível esperar conexão")
                runOnUiThread { toast("Erro Bluetooth: ${e.localizedMessage ?: "tente novamente"}") }
            }
        }
    }

    private fun showPairedDevices() {
        if (!checkReady()) return
        try {
            val devices = adapter?.bondedDevices?.toList().orEmpty()
            if (devices.isEmpty()) {
                toast("Nenhum celular emparelhado. Use primeiro as configurações Bluetooth.")
                return
            }
            val labels = devices.map { d -> "${safeName(d)}\n${d.address}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Escolha o celular do amigo")
                .setItems(labels) { _, which -> connectTo(devices[which]) }
                .setNegativeButton("Cancelar", null).show()
        } catch (e: SecurityException) { toast("Permita o acesso ao Bluetooth nas permissões do app.") }
    }

    private fun connectTo(device: BluetoothDevice) {
        if (!checkReady()) return
        thread(name = "bt-client") {
            try {
                updateUi("Conectando…")
                adapter?.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(serviceUuid)
                s.connect()
                attachSocket(s)
            } catch (e: Exception) {
                updateUi("Falha ao conectar")
                runOnUiThread { toast("Não conectou. No outro celular, toque em “Esperar conexão” e tente de novo.") }
            }
        }
    }

    private fun attachSocket(s: BluetoothSocket) {
        socket = s; connected = true
        updateUi("● CONECTADO com ${try { safeName(s.remoteDevice) } catch (_: Exception) { "amigo" }}")
        startAudio(s)
    }

    private fun startAudio(s: BluetoothSocket) {
        audioRunning = true
        thread(name = "radio-receiver") {
            var track: AudioTrack? = null
            try {
                val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                track = AudioTrack.Builder()
                    .setAudioAttributes(android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(maxOf(min, frameBytes * 4))
                    .setTransferMode(AudioTrack.MODE_STREAM).build()
                audioTrack = track; track.play()
                val input = s.inputStream
                val packet = ByteArray(frameBytes + 1)
                while (audioRunning && s.isConnected) {
                    readFully(input, packet)
                    if (packet[0].toInt() == 1) track.write(packet, 1, frameBytes)
                }
            } catch (_: Exception) {
                if (audioRunning) runOnUiThread { toast("A conexão foi encerrada.") }
                disconnect("Conexão encerrada")
            } finally {
                try { track?.stop() } catch (_: Exception) {}
                track?.release(); audioTrack = null
            }
        }
        thread(name = "radio-sender") {
            var recorder: AudioRecord? = null
            try {
                val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, sampleRate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, frameBytes * 4))
                audioRecord = recorder
                val out: OutputStream = s.outputStream
                val audio = ByteArray(frameBytes)
                val packet = ByteArray(frameBytes + 1)
                while (audioRunning && s.isConnected) {
                    if (transmitting.get()) {
                        if (recorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) recorder.startRecording()
                        var offset = 0
                        while (offset < frameBytes && transmitting.get() && audioRunning) {
                            val n = recorder.read(audio, offset, frameBytes - offset)
                            if (n > 0) offset += n else break
                        }
                        if (offset < frameBytes) java.util.Arrays.fill(audio, offset, frameBytes, 0.toByte())
                        packet[0] = if (transmitting.get()) 1 else 0
                        System.arraycopy(audio, 0, packet, 1, frameBytes)
                    } else {
                        if (recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) recorder.stop()
                        packet[0] = 0
                        java.util.Arrays.fill(packet, 1, packet.size, 0.toByte())
                        Thread.sleep(20)
                    }
                    out.write(packet)
                }
            } catch (e: Exception) {
                if (audioRunning) runOnUiThread { toast("Erro no áudio. Desconecte e tente novamente.") }
                disconnect("Conexão encerrada")
            } finally {
                try { if (recorder?.recordingState == AudioRecord.RECORDSTATE_RECORDING) recorder.stop() } catch (_: Exception) {}
                recorder?.release(); audioRecord = null
            }
        }
    }

    private fun readFully(input: InputStream, buffer: ByteArray) {
        var off = 0
        while (off < buffer.size) {
            val n = input.read(buffer, off, buffer.size - off)
            if (n < 0) throw java.io.EOFException("Bluetooth fechado")
            off += n
        }
    }

    private fun safeName(device: BluetoothDevice): String =
        try { device.name ?: "Celular Bluetooth" } catch (_: SecurityException) { "Celular Bluetooth" }

    private fun checkReady(): Boolean {
        if (!hasPermissions()) { requestPermissions(permissions, 20); return false }
        if (adapter == null) { toast("Este celular não tem Bluetooth."); return false }
        if (adapter?.isEnabled != true) { toast("Ative o Bluetooth nas configurações."); return false }
        return true
    }

    private fun disconnect(message: String) {
        transmitting.set(false); audioRunning = false; connected = false
        try { serverSocket?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        try { audioTrack?.pause(); audioTrack?.flush(); audioTrack?.release() } catch (_: Exception) {}
        serverSocket = null; socket = null; audioRecord = null; audioTrack = null
        updateUi(message)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        disconnect("Desconectado")
        super.onDestroy()
    }
}
