# Rádio Amigos para Android

App nativo Android para comunicação de voz por Bluetooth Classic (RFCOMM), sem internet.

## Recursos
- Emparelhar celulares nas configurações Android
- Um aparelho aguarda conexão e o outro se conecta
- Push-to-talk: segure para falar e solte para parar
- Interface em português
- Microfone e áudio em streaming PCM 16 kHz

## Limitações
- É um protótipo inicial; teste primeiro com dois aparelhos e volumes baixos.
- Os celulares precisam estar emparelhados nas configurações Bluetooth.
- Um aparelho deve tocar em "Esperar conexão" antes de o outro conectar.
- Alcance e qualidade dependem do Bluetooth, obstáculos e modelo do aparelho.
- Bluetooth Classic RFCOMM não é compatível com todos os perfis de dispositivos.
- APK de debug é para testes, não publicação na Play Store.

## Compilar
Requer JDK 17, Gradle 8.9 e Android Gradle Plugin 8.7.3. Execute `gradle assembleDebug`.
