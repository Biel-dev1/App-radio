package com.radioamigos

import android.app.*
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import okhttp3.*
import okio.ByteString
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class RadioService : Service() {
    companion object {
        const val ACTION_ONLINE = "online"
        const val ACTION_BT_CLIENT = "bt_client"
        const val ACTION_BT_SERVER = "bt_server"
        const val ACTION_TALK_START = "talk_start"
        const val ACTION_TALK_STOP = "talk_stop"
        private val UUID_RADIO: UUID = UUID.fromString("a7f11000-52c3-4b11-9a9a-111111111111")
        private const val CHANNEL = "radio_amigos"
        private const val RATE = 16000
    }
    private var socket: WebSocket? = null
    private var btSocket: BluetoothSocket? = null
    private var recording: AudioRecord? = null
    private var track: AudioTrack? = null
    private var talking = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var btOut: DataOutputStream? = null
    private var btIn: DataInputStream? = null
    private var client: OkHttpClient? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RadioAmigos:Audio")
        startForeground(7, notification("Rádio Amigos ativo"))
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ONLINE -> startOnline(intent.getStringExtra("server") ?: "", intent.getStringExtra("room") ?: "", intent.getStringExtra("nickname") ?: "Amigo")
            ACTION_BT_CLIENT -> startBtClient(intent.getStringExtra("deviceAddress") ?: "")
            ACTION_BT_SERVER -> startBtServer()
            ACTION_TALK_START -> startTalking()
            ACTION_TALK_STOP -> stopTalking()
        }
        return START_STICKY
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Rádio Amigos", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }
    private fun notification(msg: String): Notification =
        NotificationCompat.Builder(this, CHANNEL).setContentTitle("Rádio Amigos").setContentText(msg)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()

    private fun startOnline(server: String, room: String, nick: String) {
        wakeLock?.takeIf { !it.isHeld }?.acquire(4*60*60*1000L)
        client?.dispatcher?.executorService?.shutdown()
        client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
        val req = Request.Builder().url(server).build()
        socket = client!!.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(JSONObject().put("type","join").put("room",room).put("name",nick).toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val o = JSONObject(text)
                    if (o.optString("type") == "error") updateNotification(o.optString("message","Erro no servidor"))
                } catch (_: Exception) {}
            }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                play(bytes.toByteArray())
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                updateNotification("Falha online: ${t.message ?: "verifique servidor e internet"}")
            }
        })
    }
    private fun startBtClient(address: String) {
        thread {
            try {
                val d = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(address)
                val s = d.createRfcommSocketToServiceRecord(UUID_RADIO)
                BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                s.connect(); btSocket = s
                btOut = DataOutputStream(s.outputStream); btIn = DataInputStream(s.inputStream)
                updateNotification("Bluetooth conectado")
                while (true) {
                    val size = btIn!!.readInt()
                    if (size in 1..4096) { val b = ByteArray(size); btIn!!.readFully(b); play(b) }
                }
            } catch (e: Exception) { updateNotification("Bluetooth desconectado: ${e.message}") }
        }
    }
    private fun startBtServer() {
        thread {
            try {
                val server: BluetoothServerSocket = BluetoothAdapter.getDefaultAdapter()
                    .listenUsingRfcommWithServiceRecord("RadioAmigos", UUID_RADIO)
                updateNotification("Esperando amigo por Bluetooth")
                btSocket = server.accept()
                btOut = DataOutputStream(btSocket!!.outputStream); btIn = DataInputStream(btSocket!!.inputStream)
                updateNotification("Bluetooth conectado")
                while (true) {
                    val size = btIn!!.readInt()
                    if (size in 1..4096) { val b = ByteArray(size); btIn!!.readFully(b); play(b) }
                }
            } catch (e: Exception) { updateNotification("Bluetooth: ${e.message}") }
        }
    }
    private fun startTalking() {
        if (talking) return
        talking = true
        thread {
            try {
                val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096))
                recording = rec; rec.startRecording()
                val data = ByteArray(2048)
                while (talking) {
                    val n = rec.read(data, 0, data.size)
                    if (n > 0) {
                        val packet = data.copyOf(n)
                        socket?.send(ByteString.of(*packet))
                        synchronized(this) {
                            try { btOut?.writeInt(packet.size); btOut?.write(packet); btOut?.flush() } catch (_: Exception) {}
                        }
                    }
                }
                rec.stop(); rec.release(); recording = null
            } catch (e: Exception) { updateNotification("Microfone: ${e.message}") }
        }
    }
    private fun stopTalking() { talking = false }
    private fun play(bytes: ByteArray) {
        try {
            if (track == null) {
                val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                track = AudioTrack.Builder().setAudioAttributes(android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(maxOf(min,8192)).setTransferMode(AudioTrack.MODE_STREAM).build()
                track?.play()
            }
            track?.write(bytes,0,bytes.size)
        } catch (_: Exception) {}
    }
    private fun updateNotification(msg: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(7, notification(msg))
    }
    override fun onDestroy() {
        talking = false
        try { recording?.stop(); recording?.release() } catch (_: Exception) {}
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        try { socket?.close(1000,"stop") } catch (_: Exception) {}
        try { btSocket?.close() } catch (_: Exception) {}
        try { client?.dispatcher?.executorService?.shutdown() } catch (_: Exception) {}
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
