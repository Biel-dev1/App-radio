import { WebSocketServer } from "ws";
const port = process.env.PORT || 8080;
const wss = new WebSocketServer({ port });
const rooms = new Map();

wss.on("connection", (ws) => {
  ws.room = null;
  ws.on("message", (data, isBinary) => {
    if (!isBinary) {
      let msg;
      try { msg = JSON.parse(data.toString()); } catch { return; }
      if (msg.type === "join") {
        const room = String(msg.room || "").trim();
        if (!/^[A-Za-z0-9-]{4,20}$/.test(room)) {
          ws.send(JSON.stringify({ type:"error", message:"Use um código de 4 a 20 letras/números." })); return;
        }
        ws.room = room;
        if (!rooms.has(room)) rooms.set(room, new Set());
        rooms.get(room).add(ws);
        ws.send(JSON.stringify({ type:"joined", room }));
      }
      return;
    }
    if (!ws.room) return;
    for (const peer of rooms.get(ws.room) || []) {
      if (peer !== ws && peer.readyState === 1) peer.send(data, { binary: true });
    }
  });
  ws.on("close", () => {
    if (!ws.room) return;
    const set = rooms.get(ws.room);
    if (set) { set.delete(ws); if (!set.size) rooms.delete(ws.room); }
  });
});
console.log(`Rádio Amigos server listening on ${port}`);
