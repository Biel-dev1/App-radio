package com.radioamigos

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.security.SecureRandom

class MainActivity : Activity() {
    private companion object {
        const val DEFAULT_SERVER = "wss://radio-amigos-server.onrender.com"
        const val NAV_HEIGHT_DP = 68
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var contentHost: FrameLayout
    private lateinit var nav: GlassNavBar

    private var current = -1
    private var scroll: ScrollView? = null
    private var insetTop = 0
    private var insetBottom = 0
    private var imeHeight = 0

    private var statusText: TextView? = null
    private var statusDot: View? = null
    private var roomText: TextView? = null
    private var shareBtn: View? = null
    private var leaveBtn: View? = null
    private var talkLabel: TextView? = null
    private var devicesBox: LinearLayout? = null

    private var btDevices: List<BluetoothDevice> = emptyList()
    private var btSelected = -1

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("radio", MODE_PRIVATE)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        if (Build.VERSION.SDK_INT >= 29) window.setNavigationBarContrastEnforced(false)

        val root = FrameLayout(this)
        root.addView(AuroraBackground(this), FrameLayout.LayoutParams(MATCH, MATCH))
        contentHost = FrameLayout(this)
        root.addView(contentHost, FrameLayout.LayoutParams(MATCH, MATCH))

        nav = GlassNavBar(
            this,
            listOf(
                ICON_MIC to "Rádio",
                ICON_GRID to "Salas",
                ICON_BT to "Bluetooth",
                ICON_PROFILE to "Perfil",
                ICON_CHAT to "Feedback"
            )
        ) { i -> show(i) }
        val navLp = FrameLayout.LayoutParams(MATCH, dpi(NAV_HEIGHT_DP))
        navLp.gravity = Gravity.BOTTOM
        navLp.leftMargin = dpi(14)
        navLp.rightMargin = dpi(14)
        navLp.bottomMargin = dpi(14)
        root.addView(nav, navLp)
        setContentView(root)

        root.setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = ins.getInsets(WindowInsets.Type.systemBars())
                val ime = ins.getInsets(WindowInsets.Type.ime())
                insetTop = bars.top
                insetBottom = bars.bottom
                imeHeight = ime.bottom
            } else {
                @Suppress("DEPRECATION")
                val b = ins.systemWindowInsetBottom
                @Suppress("DEPRECATION")
                insetTop = ins.systemWindowInsetTop
                if (b > dpi(180)) { imeHeight = b; insetBottom = 0 } else { imeHeight = 0; insetBottom = b }
            }
            applyInsets()
            ins
        }

        requestNeededPermissions()
        show(0)
    }

    override fun onResume() {
        super.onResume()
        RadioService.onStatus = { runOnUiThread { refreshStatus() } }
        refreshStatus()
    }

    override fun onPause() {
        RadioService.onStatus = null
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (current != 0) {
            nav.select(0, true)
            show(0)
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private fun applyInsets() {
        val keyboard = imeHeight > 0
        val navBottom = dpi(14) + insetBottom
        val lp = nav.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = navBottom
        nav.layoutParams = lp
        nav.visibility = if (keyboard) View.GONE else View.VISIBLE
        val bottom = if (keyboard) imeHeight + dpi(16) else navBottom + dpi(NAV_HEIGHT_DP) + dpi(24)
        scroll?.setPadding(dpi(20), insetTop + dpi(14), dpi(20), bottom)
    }

    // ---------------------------------------------------------------- navegação

    private fun show(i: Int) {
        if (i == current) return
        current = i
        statusText = null; statusDot = null; roomText = null
        shareBtn = null; leaveBtn = null; talkLabel = null; devicesBox = null
        val view = when (i) {
            0 -> buildRadio()
            1 -> buildRooms()
            2 -> buildBluetooth()
            3 -> buildProfile()
            else -> buildFeedback()
        }
        scroll = view
        contentHost.removeAllViews()
        view.alpha = 0f
        view.translationY = dp(16f)
        contentHost.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
        view.animate().alpha(1f).translationY(0f).setDuration(260).start()
        applyInsets()
        refreshStatus()
    }

    // ---------------------------------------------------------------- telas

    private fun buildRadio(): ScrollView = scaffold("Rádio Amigos", "Fale com seus amigos, onde estiverem.") {
        put(statusChip(), 0)
        put(card {
            put(label("SALA ATUAL"), 0)
            val code = txt("Sem sala", 34f, cWhite, true)
            code.letterSpacing = 0.18f
            roomText = code
            put(code, 4)
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.HORIZONTAL
            val share = button("Convidar", false) { shareInvite() }
            val leave = button("Sair", false) { leaveRoom() }
            shareBtn = share
            leaveBtn = leave
            row.addView(share, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dpi(8) })
            row.addView(leave, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dpi(8) })
            put(row, 14)
        }, 14)

        val tb = TalkButton(this@MainActivity)
        tb.onDown = {
            if (!RadioService.linked) {
                toast(if (RadioService.mode.isEmpty()) "Entre em uma sala primeiro (aba Salas)." else "Ainda conectando… aguarde.")
                false
            } else {
                sendAction(RadioService.ACTION_TALK_START)
                talkLabel?.text = "Transmitindo…"
                tb.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                true
            }
        }
        tb.onUp = {
            sendAction(RadioService.ACTION_TALK_STOP)
            talkLabel?.text = "Segure para falar"
        }
        put(tb, 10, dpi(270), dpi(270))
        val lbl = txt("Segure para falar", 18f, cWhite, true)
        lbl.gravity = Gravity.CENTER
        talkLabel = lbl
        put(lbl, 0)
        val hint = txt("Solte o botão para ouvir os amigos.", 13f, cDim)
        hint.gravity = Gravity.CENTER
        put(hint, 4)
    }

    private fun buildRooms(): ScrollView = scaffold("Salas", "Crie uma sala ou entre com o código de um amigo.") {
        put(card {
            put(label("CRIAR SALA"), 0)
            put(txt("Gere um código único e mande para seus amigos entrarem.", 15f, cWhite), 8)
            put(button("+  Criar sala nova") { joinRoom(newCode()) }, 16)
        }, 0)

        put(card {
            put(label("ENTRAR COM CÓDIGO"), 0)
            val code = input("Código da sala", "")
            code.gravity = Gravity.CENTER
            code.textSize = 22f
            code.letterSpacing = 0.2f
            code.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            code.filters = arrayOf(InputFilter.AllCaps(), InputFilter.LengthFilter(20))
            code.imeOptions = EditorInfo.IME_ACTION_GO
            code.setOnEditorActionListener { _, _, _ -> joinRoom(code.text.toString()); true }
            put(code, 10)
            put(button("Entrar na sala") { joinRoom(code.text.toString()) }, 12)
            val last = prefs.getString("lastRoom", "") ?: ""
            if (last.isNotEmpty()) {
                put(button("Voltar para a sala $last", false) { joinRoom(last) }, 10)
            }
        }, 14)

        put(txt("O servidor gratuito pode levar até 1 minuto para acordar na primeira conexão.", 12f, cFaint), 14)
    }

    private fun buildBluetooth(): ScrollView = scaffold("Bluetooth", "Fale sem internet com celulares pareados.") {
        put(statusChip(), 0)
        put(card {
            put(txt("Como funciona", 16f, cWhite, true), 0)
            put(txt("1. Pareie os dois celulares em Configurações › Bluetooth.\n2. Em um deles, toque em “Ser o anfitrião”.\n3. No outro, escolha o celular na lista e toque em Conectar.", 14f, cDim), 8)
        }, 14)
        put(button("Atualizar lista de pareados", false) { loadPaired() }, 14)
        val box = LinearLayout(this@MainActivity)
        box.orientation = LinearLayout.VERTICAL
        devicesBox = box
        put(box, 4)
        put(button("Conectar ao selecionado") { connectBluetooth() }, 14)
        put(button("Ser o anfitrião neste celular", false) { startBluetoothServer() }, 10)
        if (hasBt()) loadPaired() else renderDevices()
    }

    private fun buildProfile(): ScrollView = scaffold("Perfil", "Como seus amigos veem você.") {
        val nick = prefs.getString("nick", "Amigo") ?: "Amigo"
        val avatar = TextView(this@MainActivity)
        avatar.text = nick.trim().take(1).uppercase().ifEmpty { "A" }
        avatar.textSize = 40f
        avatar.setTextColor(cWhite)
        avatar.gravity = Gravity.CENTER
        avatar.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val avBg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF7C4DFF.toInt(), 0xFF22D3EE.toInt()))
        avBg.shape = GradientDrawable.OVAL
        avatar.background = avBg
        put(avatar, 0, dpi(96), dpi(96))

        put(card {
            put(label("APELIDO"), 0)
            val nickIn = input("Seu apelido", nick)
            put(nickIn, 8)
            put(label("SERVIDOR (AVANÇADO)"), 16)
            val serverIn = input("wss://seu-servidor", prefs.getString("server", DEFAULT_SERVER) ?: DEFAULT_SERVER)
            serverIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            put(serverIn, 8)
            put(button("Salvar") {
                val n = nickIn.text.toString().trim().ifEmpty { "Amigo" }
                val s = serverIn.text.toString().trim()
                if (!s.startsWith("wss://")) {
                    toast("O servidor precisa começar com wss://")
                } else {
                    prefs.edit().putString("nick", n).putString("server", s).apply()
                    avatar.text = n.take(1).uppercase()
                    toast("Perfil salvo!")
                }
            }, 16)
        }, 18)

        put(card {
            put(txt("Rádio Amigos 2.0", 16f, cWhite, true), 0)
            put(txt("Sua voz é enviada sem criptografia de ponta a ponta. Não use para assuntos privados ou sensíveis.", 13f, cDim), 6)
        }, 14)
    }

    private fun buildFeedback(): ScrollView = scaffold("Feedback", "Conte o que achou e ajude a melhorar o app.") {
        put(card {
            put(label("SUA NOTA"), 0)
            var rating = 0
            val stars = ArrayList<TextView>()
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            fun paint() {
                for (k in stars.indices) stars[k].setTextColor(if (k < rating) 0xFFFBBF24.toInt() else 0x33FFFFFF)
            }
            for (k in 0..4) {
                val st = TextView(this@MainActivity)
                st.text = "★"
                st.textSize = 38f
                st.gravity = Gravity.CENTER
                st.setPadding(dpi(6), 0, dpi(6), 0)
                st.setOnClickListener {
                    rating = k + 1
                    paint()
                    it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                }
                st.pressable()
                stars.add(st)
                row.addView(st)
            }
            paint()
            put(row, 6)

            put(label("MENSAGEM"), 14)
            val msg = input("O que você gostou? O que podemos melhorar?", "")
            msg.setSingleLine(false)
            msg.minLines = 4
            msg.gravity = Gravity.TOP or Gravity.START
            msg.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            put(msg, 8)

            put(button("Enviar feedback") {
                val text = msg.text.toString().trim()
                if (rating == 0 && text.isEmpty()) {
                    toast("Dê uma nota ou escreva uma mensagem.")
                } else {
                    val body = "Nota: $rating/5\n\n$text\n\n— Rádio Amigos 2.0 · Android ${Build.VERSION.RELEASE} · ${Build.MODEL}"
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "text/plain"
                    i.putExtra(Intent.EXTRA_SUBJECT, "Feedback Rádio Amigos")
                    i.putExtra(Intent.EXTRA_TEXT, body)
                    startActivity(Intent.createChooser(i, "Enviar feedback por…"))
                }
            }, 16)
        }, 0)
    }

    // ---------------------------------------------------------------- ações

    private fun newCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val rnd = SecureRandom()
        val sb = StringBuilder()
        repeat(6) { sb.append(chars[rnd.nextInt(chars.length)]) }
        return sb.toString()
    }

    private fun joinRoom(raw: String) {
        val code = raw.trim().uppercase()
        if (!Regex("[A-Z0-9-]{4,20}").matches(code)) {
            toast("Use de 4 a 20 letras ou números."); return
        }
        if (!hasMic()) {
            requestNeededPermissions(); toast("Permita o microfone para falar."); return
        }
        val server = (prefs.getString("server", DEFAULT_SERVER) ?: DEFAULT_SERVER).trim()
        if (!server.startsWith("wss://")) {
            toast("Configure o servidor (wss://) na aba Perfil."); return
        }
        prefs.edit().putString("lastRoom", code).apply()
        RadioService.mode = "online"
        RadioService.currentRoom = code
        RadioService.linked = false
        RadioService.lastStatus = "Conectando… o servidor pode demorar até 1 min"
        val i = Intent(this, RadioService::class.java)
        i.action = RadioService.ACTION_ONLINE
        i.putExtra("server", server)
        i.putExtra("room", code)
        i.putExtra("nickname", prefs.getString("nick", "Amigo") ?: "Amigo")
        ContextCompat.startForegroundService(this, i)
        nav.select(0, true)
        show(0)
        refreshStatus()
    }

    private fun leaveRoom() {
        if (RadioService.mode.isEmpty()) return
        stopService(Intent(this, RadioService::class.java))
        RadioService.mode = ""
        RadioService.currentRoom = ""
        RadioService.linked = false
        RadioService.lastStatus = "Desconectado"
        refreshStatus()
    }

    private fun shareInvite() {
        val code = RadioService.currentRoom
        if (code.isEmpty() || RadioService.mode != "online") {
            toast("Crie ou entre em uma sala para convidar."); return
        }
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, "Entra na minha sala no Rádio Amigos! 📻\nCódigo da sala: $code")
        startActivity(Intent.createChooser(i, "Convidar amigos"))
    }

    private fun sendAction(action: String) {
        val i = Intent(this, RadioService::class.java)
        i.action = action
        startService(i)
    }

    private fun loadPaired() {
        if (!hasBt()) {
            requestNeededPermissions(); toast("Permita o Bluetooth e toque de novo."); return
        }
        try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null) {
                toast("Este celular não tem Bluetooth."); return
            }
            btDevices = adapter.bondedDevices.toList()
            if (btSelected >= btDevices.size) btSelected = -1
            if (btSelected < 0 && btDevices.isNotEmpty()) btSelected = 0
        } catch (e: SecurityException) {
            toast("Permita o acesso ao Bluetooth nas permissões do app.")
        }
        renderDevices()
    }

    private fun renderDevices() {
        val box = devicesBox ?: return
        box.removeAllViews()
        if (btDevices.isEmpty()) {
            box.put(txt("Nenhum celular pareado ainda.", 14f, cDim), 8)
            return
        }
        btDevices.forEachIndexed { i, d ->
            val name = (try { d.name } catch (e: SecurityException) { null }) ?: "Celular"
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
            if (i == btSelected) {
                val bg = GradientDrawable()
                bg.cornerRadius = dp(18f)
                bg.setColor(0x337C4DFF)
                bg.setStroke(dpi(2), 0xFF22D3EE.toInt())
                row.background = bg
            } else {
                row.background = glass(18f)
            }
            row.addView(txt(name, 16f, cWhite, true))
            row.addView(txt(d.address, 12f, cDim))
            row.isClickable = true
            row.setOnClickListener { btSelected = i; renderDevices() }
            row.pressable()
            box.put(row, 8)
        }
    }

    private fun connectBluetooth() {
        if (!hasMic() || !hasBt()) {
            requestNeededPermissions(); toast("Permita microfone e Bluetooth."); return
        }
        val d = btDevices.getOrNull(btSelected) ?: run {
            toast("Escolha um celular da lista."); return
        }
        RadioService.mode = "bt"
        RadioService.currentRoom = ""
        RadioService.linked = false
        RadioService.lastStatus = "Conectando por Bluetooth…"
        val i = Intent(this, RadioService::class.java)
        i.action = RadioService.ACTION_BT_CLIENT
        i.putExtra("deviceAddress", d.address)
        ContextCompat.startForegroundService(this, i)
        refreshStatus()
    }

    private fun startBluetoothServer() {
        if (!hasMic() || !hasBt()) {
            requestNeededPermissions(); toast("Permita microfone e Bluetooth."); return
        }
        RadioService.mode = "bt"
        RadioService.currentRoom = ""
        RadioService.linked = false
        RadioService.lastStatus = "Esperando conexão Bluetooth…"
        val i = Intent(this, RadioService::class.java)
        i.action = RadioService.ACTION_BT_SERVER
        ContextCompat.startForegroundService(this, i)
        refreshStatus()
    }

    private fun refreshStatus() {
        val linked = RadioService.linked
        val msg = RadioService.lastStatus
        statusText?.text = msg
        val color = when {
            linked -> 0xFF34D399
            msg.startsWith("Conectando") || msg.startsWith("Esperando") -> 0xFFFBBF24
            msg.startsWith("Falha") || msg.contains("desconectado") -> 0xFFF87171
            else -> 0xFF9CA3AF
        }.toInt()
        (statusDot?.background as? GradientDrawable)?.setColor(color)
        roomText?.text = when {
            RadioService.mode == "bt" -> "Bluetooth"
            RadioService.currentRoom.isNotEmpty() -> RadioService.currentRoom
            else -> "Sem sala"
        }
        shareBtn?.alpha = if (RadioService.mode == "online") 1f else 0.35f
        leaveBtn?.alpha = if (RadioService.mode.isNotEmpty()) 1f else 0.35f
    }

    // ---------------------------------------------------------------- permissões

    private fun requestNeededPermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) {
            perms += Manifest.permission.BLUETOOTH_CONNECT
            perms += Manifest.permission.BLUETOOTH_SCAN
        }
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 101)
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasBt() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    // ---------------------------------------------------------------- componentes visuais

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun glass(radiusDp: Float, strength: Float = 1f) = GlassDrawable(dp(radiusDp), dp(1f), strength)

    private fun txt(s: String, sp: Float, color: Int = cWhite, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        t.typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        return t
    }

    private fun label(s: String): TextView {
        val t = txt(s, 11f, cDim, true)
        t.letterSpacing = 0.14f
        return t
    }

    private fun LinearLayout.put(v: View, topDp: Int = 12, w: Int = MATCH, h: Int = WRAP): View {
        val lp = LinearLayout.LayoutParams(w, h)
        lp.topMargin = dpi(topDp)
        if (w != MATCH) lp.gravity = Gravity.CENTER_HORIZONTAL
        addView(v, lp)
        return v
    }

    private fun scaffold(title: String, subtitle: String, build: LinearLayout.() -> Unit): ScrollView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(txt(title, 32f, cWhite, true))
        val sub = txt(subtitle, 14f, cDim)
        sub.setPadding(0, dpi(4), 0, dpi(18))
        col.addView(sub)
        col.build()
        val sv = ScrollView(this)
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        sv.isVerticalScrollBarEnabled = false
        sv.clipToPadding = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        return sv
    }

    private fun card(build: LinearLayout.() -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dpi(18), dpi(18), dpi(18), dpi(18))
        c.background = glass(24f)
        c.build()
        return c
    }

    private fun button(label: String, primary: Boolean = true, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.textSize = 16f
        b.setTextColor(cWhite)
        b.gravity = Gravity.CENTER
        b.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        b.setPadding(dpi(16), dpi(16), dpi(16), dpi(16))
        if (primary) {
            val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7C4DFF.toInt(), 0xFF06B6D4.toInt()))
            g.cornerRadius = dp(18f)
            b.background = g
        } else {
            b.background = glass(18f)
        }
        b.isClickable = true
        b.setOnClickListener { onClick() }
        b.pressable()
        return b
    }

    private fun input(placeholder: String, value: String): EditText {
        val e = EditText(this)
        e.setText(value)
        e.hint = placeholder
        e.setTextColor(cWhite)
        e.setHintTextColor(cFaint)
        e.textSize = 16f
        e.setSingleLine(true)
        e.background = glass(16f, 0.7f)
        e.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
        return e
    }

    private fun statusChip(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = glass(22f)
        row.setPadding(dpi(16), dpi(12), dpi(16), dpi(12))
        val dot = View(this)
        val dotBg = GradientDrawable()
        dotBg.shape = GradientDrawable.OVAL
        dotBg.setColor(0xFF9CA3AF.toInt())
        dot.background = dotBg
        val dotLp = LinearLayout.LayoutParams(dpi(10), dpi(10))
        dotLp.rightMargin = dpi(12)
        row.addView(dot, dotLp)
        val t = txt("Desconectado", 14f, cWhite)
        row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        statusDot = dot
        statusText = t
        return row
    }
}
