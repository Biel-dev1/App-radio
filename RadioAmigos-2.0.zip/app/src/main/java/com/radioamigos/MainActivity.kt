package com.radioamigos

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var url: EditText
    private lateinit var room: EditText
    private lateinit var name: EditText
    private lateinit var deviceList: Spinner
    private var devices: List<BluetoothDevice> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNeededPermissions()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(28, 24, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        layout.addView(TextView(this).apply { text = "📻 Rádio Amigos 2.0"; textSize = 28f; gravity = Gravity.CENTER; setPadding(0,0,0,18) })
        layout.addView(TextView(this).apply { text = "Modo internet (Wi-Fi / 4G / 5G)"; textSize = 18f })
        url = EditText(this).apply { hint = "Servidor seguro wss://seu-servidor"; setSingleLine(true); setText("wss://SEU-SERVIDOR-AQUI") }
        room = EditText(this).apply { hint = "Código da sala (ex.: 4821)"; setSingleLine(true) }
        name = EditText(this).apply { hint = "Seu apelido"; setSingleLine(true); setText("Amigo") }
        layout.addView(url); layout.addView(room); layout.addView(name)
        layout.addView(button("Conectar à sala") { connectOnline() })
        layout.addView(button("Desconectar") { stopService(Intent(this, RadioService::class.java)); status.text = "Desconectado" })
        layout.addView(TextView(this).apply { text = "\nModo sem internet"; textSize = 18f })
        layout.addView(button("Procurar celulares Bluetooth pareados") { loadPairedDevices() })
        deviceList = Spinner(this); layout.addView(deviceList)
        layout.addView(button("Conectar ao celular selecionado") { connectBluetooth() })
        layout.addView(button("Ativar rádio Bluetooth neste celular") { startBluetoothServer() })
        layout.addView(TextView(this).apply {
            text = "\nComo falar: mantenha o botão abaixo pressionado e solte para parar."
            textSize = 15f
        })
        val talk = Button(this).apply {
            text = "SEGURE PARA FALAR"; textSize = 20f; minHeight = 100
            setOnTouchListener { _, event ->
                when (event.action) {
                    android.view.MotionEvent.ACTION_DOWN -> { sendAction(RadioService.ACTION_TALK_START); true }
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> { sendAction(RadioService.ACTION_TALK_STOP); true }
                    else -> true
                }
            }
        }
        layout.addView(talk)
        status = TextView(this).apply { text = "Status: pronto"; textSize = 15f; setPadding(0,20,0,0) }
        layout.addView(status)
        layout.addView(TextView(this).apply {
            text = "\nAtenção: o modo internet só funciona depois de configurar o servidor no projeto. O modo offline Bluetooth exige os dois celulares pareados nas configurações Android."
            textSize = 13f
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { action() }
    }
    private fun requestNeededPermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) {
            perms += Manifest.permission.BLUETOOTH_CONNECT
            perms += Manifest.permission.BLUETOOTH_SCAN
        }
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 101)
    }
    private fun connectOnline() {
        if (room.text.toString().trim().isEmpty()) { status.text = "Digite o código da sala."; return }
        val server = url.text.toString().trim()
        if (!server.startsWith("wss://") || server.contains("SEU-SERVIDOR")) {
            status.text = "Falta configurar o servidor online. Veja README.md no projeto."; return
        }
        val i = Intent(this, RadioService::class.java).apply {
            action = RadioService.ACTION_ONLINE
            putExtra("server", server)
            putExtra("room", room.text.toString().trim())
            putExtra("nickname", name.text.toString().trim())
        }
        ContextCompat.startForegroundService(this, i)
        status.text = "Solicitando conexão online…"
    }
    private fun sendAction(action: String) {
        val i = Intent(this, RadioService::class.java).apply { this.action = action }
        startService(i)
    }
    private fun loadPairedDevices() {
        try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null) { status.text = "Este celular não tem Bluetooth."; return }
            devices = adapter.bondedDevices.toList()
            deviceList.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, devices.map { "${it.name ?: "Celular"} — ${it.address}" })
            status.text = "Celulares pareados: ${devices.size}. Pareie os aparelhos nas configurações Bluetooth primeiro."
        } catch (e: SecurityException) { status.text = "Permita o acesso ao Bluetooth nas permissões do app." }
    }
    private fun connectBluetooth() {
        if (devices.isEmpty()) { status.text = "Primeiro procure os celulares pareados."; return }
        val d = devices.getOrNull(deviceList.selectedItemPosition) ?: return
        val i = Intent(this, RadioService::class.java).apply {
            action = RadioService.ACTION_BT_CLIENT
            putExtra("deviceAddress", d.address)
        }
        ContextCompat.startForegroundService(this, i)
        status.text = "Tentando conectar ao celular pareado…"
    }
    private fun startBluetoothServer() {
        ContextCompat.startForegroundService(this, Intent(this, RadioService::class.java).apply { action = RadioService.ACTION_BT_SERVER })
        status.text = "Esperando conexão Bluetooth…"
    }
}
