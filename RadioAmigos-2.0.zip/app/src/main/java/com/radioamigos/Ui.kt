package com.radioamigos

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

const val MATCH = -1
const val WRAP = -2

val cWhite = 0xFFFFFFFF.toInt()
val cDim = 0xB3FFFFFF.toInt()
val cFaint = 0x80FFFFFF.toInt()

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

const val ICON_GRID = 0
const val ICON_MIC = 1
const val ICON_BT = 2
const val ICON_PROFILE = 3
const val ICON_CHAT = 4

/** Efeito de toque: o botão "afunda" um pouquinho ao ser pressionado. */
fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
        }
        false
    }
}

/** Desenha um ícone de traço dentro de uma caixa de 24x24 unidades centrada em (cx, cy). */
fun drawIcon(c: Canvas, kind: Int, cx: Float, cy: Float, u: Float, p: Paint) {
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    p.strokeJoin = Paint.Join.ROUND
    p.strokeWidth = 1.8f
    p.shader = null
    c.save()
    c.translate(cx, cy)
    c.scale(u, u)
    when (kind) {
        ICON_GRID -> {
            c.drawRoundRect(RectF(-9f, -9f, -1.5f, -1.5f), 2.5f, 2.5f, p)
            c.drawRoundRect(RectF(1.5f, -9f, 9f, -1.5f), 2.5f, 2.5f, p)
            c.drawRoundRect(RectF(-9f, 1.5f, -1.5f, 9f), 2.5f, 2.5f, p)
            c.drawRoundRect(RectF(1.5f, 1.5f, 9f, 9f), 2.5f, 2.5f, p)
        }
        ICON_MIC -> {
            c.drawRoundRect(RectF(-3.5f, -10f, 3.5f, 3f), 3.5f, 3.5f, p)
            val arc = Path()
            arc.addArc(RectF(-7f, -5f, 7f, 9f), 0f, 180f)
            c.drawPath(arc, p)
            c.drawLine(0f, 9f, 0f, 12f, p)
        }
        ICON_BT -> {
            val path = Path()
            path.moveTo(-5f, -5f)
            path.lineTo(5f, 5f)
            path.lineTo(0f, 10f)
            path.lineTo(0f, -10f)
            path.lineTo(5f, -5f)
            path.lineTo(-5f, 5f)
            c.drawPath(path, p)
        }
        ICON_PROFILE -> {
            c.drawCircle(0f, -4.5f, 4.2f, p)
            val body = Path()
            body.addArc(RectF(-8.5f, 3f, 8.5f, 20f), 180f, 180f)
            c.drawPath(body, p)
        }
        else -> {
            c.drawRoundRect(RectF(-9.5f, -8.5f, 9.5f, 5f), 4f, 4f, p)
            val tail = Path()
            tail.moveTo(-3.5f, 5f)
            tail.lineTo(-3.5f, 10f)
            tail.lineTo(2f, 5f)
            c.drawPath(tail, p)
        }
    }
    c.restore()
}

/** Fundo de "vidro": gradiente translúcido + brilho + borda que reflete a luz. */
class GlassDrawable(
    private val radius: Float,
    private val strokePx: Float,
    private val strength: Float = 1f,
    private val base: Int = 0x33000000
) : Drawable() {
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        basePaint.color = base
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = strokePx
    }

    private fun a(v: Int): Int = ((v * strength).toInt().coerceIn(0, 255) shl 24) or 0x00FFFFFF

    override fun onBoundsChange(bounds: Rect) {
        rect.set(bounds)
        rect.inset(strokePx, strokePx)
        val l = bounds.left.toFloat()
        val t = bounds.top.toFloat()
        val r = bounds.right.toFloat()
        val b = bounds.bottom.toFloat()
        fill.shader = LinearGradient(0f, t, 0f, b, a(0x42), a(0x0E), Shader.TileMode.CLAMP)
        stroke.shader = LinearGradient(
            l, t, r, b,
            intArrayOf(a(0xB8), a(0x14), a(0x14), a(0x78)),
            floatArrayOf(0f, 0.4f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        canvas.drawRoundRect(rect, radius, radius, basePaint)
        canvas.drawRoundRect(rect, radius, radius, fill)
        canvas.drawRoundRect(rect, radius, radius, stroke)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Fundo escuro com manchas de cor que flutuam devagar (dá o que "refratar" no vidro). */
class AuroraBackground(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 22000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    private fun blob(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        p.shader = RadialGradient(
            cx, cy, r,
            (color and 0x00FFFFFF) or 0x80000000.toInt(), color and 0x00FFFFFF,
            Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r, p)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val a = 2f * PI.toFloat() * t
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF0A0F2C.toInt(), 0xFF140B2E.toInt(), 0xFF0A1A2C.toInt()),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, p)
        blob(canvas, w * (0.22f + 0.12f * sin(a)), h * (0.16f + 0.05f * cos(a)), w * 0.75f, 0xFF7C4DFF.toInt())
        blob(canvas, w * (0.85f + 0.08f * cos(a)), h * (0.45f + 0.07f * sin(a)), w * 0.70f, 0xFF06B6D4.toInt())
        blob(canvas, w * (0.25f + 0.10f * cos(a + 1.5f)), h * (0.85f + 0.05f * sin(a + 1f)), w * 0.80f, 0xFFEC4899.toInt())
    }
}

/** Botão grande de "segure para falar" com anéis que pulsam enquanto transmite. */
class TalkButton(ctx: Context) : View(ctx) {
    var onDown: (() -> Boolean)? = null
    var onUp: (() -> Unit)? = null
    private var active = false
    private var scale = 1f
    private var phase = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = ctx.resources.displayMetrics.density

    private val pulse = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1500
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    private val scaler = ValueAnimator.ofFloat(1f, 1f).apply {
        duration = 260
        interpolator = OvershootInterpolator(2.2f)
        addUpdateListener { scale = it.animatedValue as Float; invalidate() }
    }

    private fun setActive(on: Boolean) {
        active = on
        scaler.cancel()
        scaler.setFloatValues(scale, if (on) 1.1f else 1f)
        scaler.start()
        if (on) pulse.start() else pulse.cancel()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        pulse.cancel()
        scaler.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) * 0.30f

        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, base * 2.1f,
            intArrayOf(if (active) 0x807C4DFF.toInt() else 0x387C4DFF, 0x007C4DFF),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, base * 2.1f, p)

        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = density * 2f
        if (active) {
            for (i in 0..2) {
                val ph = (phase + i / 3f) % 1f
                p.color = (((1f - ph) * 0.5f * 255).toInt() shl 24) or 0x0022D3EE
                canvas.drawCircle(cx, cy, base * (1.05f + 0.75f * ph), p)
            }
        } else {
            p.color = 0x2AFFFFFF
            canvas.drawCircle(cx, cy, base * 1.22f, p)
            p.color = 0x16FFFFFF
            canvas.drawCircle(cx, cy, base * 1.48f, p)
        }

        val r = base * scale
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            if (active) 0xFFA78BFA.toInt() else 0xFF7C4DFF.toInt(),
            if (active) 0xFF67E8F9.toInt() else 0xFF22D3EE.toInt(),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, p)

        p.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.45f, r * 1.0f,
            0x66FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, p)

        p.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            0xCCFFFFFF.toInt(), 0x33FFFFFF, Shader.TileMode.CLAMP
        )
        p.style = Paint.Style.STROKE
        p.strokeWidth = density * 1.5f
        canvas.drawCircle(cx, cy, r - density, p)

        p.shader = null
        p.color = cWhite
        drawIcon(canvas, ICON_MIC, cx, cy, r * 0.042f, p)
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (onDown?.invoke() == true) setActive(true)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (active) {
                    setActive(false)
                    onUp?.invoke()
                }
            }
        }
        return true
    }
}

/** Barra de navegação flutuante estilo "vidro líquido": a bolha desliza e estica ao trocar de aba. */
class GlassNavBar(
    ctx: Context,
    private val tabs: List<Pair<Int, String>>,
    private val onSelect: (Int) -> Unit
) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val pad = d * 8f
    private val bg = GlassDrawable(d * 34f, d * 1.2f, 1.2f, 0x73101030)
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = d * 10.5f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()

    var selected = 0
        private set
    private var fromC = 0f
    private var toC = 0f
    private var ease = 1f
    private var lin = 1f
    private var press = false

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 560
        interpolator = OvershootInterpolator(1.5f)
        addUpdateListener {
            ease = it.animatedValue as Float
            lin = it.animatedFraction
            invalidate()
        }
    }

    private fun tabW(): Float = (width - 2f * pad) / tabs.size
    private fun centerX(i: Int): Float = pad + tabW() * (i + 0.5f)
    private fun curCx(): Float = fromC + (toC - fromC) * ease

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        bg.setBounds(0, 0, w, h)
        fromC = centerX(selected)
        toC = fromC
        ease = 1f
    }

    fun select(i: Int, animate: Boolean) {
        if (i == selected && animate) return
        val now = curCx()
        selected = i
        if (animate && width > 0) {
            fromC = now
            toC = centerX(i)
            anim.cancel()
            anim.start()
        } else {
            fromC = centerX(i)
            toC = fromC
            ease = 1f
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        bg.draw(canvas)
        val tw = tabW()
        val h = height.toFloat()
        val cx = curCx()

        val stretch = tw * 0.30f * sin(PI.toFloat() * lin)
        val sc = if (press) 1.07f else 1f
        val hw = (tw * 0.5f - d * 3f + stretch) * sc
        val hh = (h / 2f - d * 6f) * sc
        rect.set(cx - hw, h / 2f - hh, cx + hw, h / 2f + hh)

        bp.style = Paint.Style.FILL
        bp.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, 0x66A78BFA, 0x3322D3EE, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, hh, hh, bp)
        bp.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, 0x4DFFFFFF, 0x0DFFFFFF, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, hh, hh, bp)
        bp.style = Paint.Style.STROKE
        bp.strokeWidth = d * 1.2f
        bp.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, 0xCCFFFFFF.toInt(), 0x33FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, hh, hh, bp)

        for (i in tabs.indices) {
            val ix = centerX(i)
            val k = (1f - abs(ix - cx) / tw).coerceIn(0f, 1f)
            val alpha = (0xA0 + (0xFF - 0xA0) * k).toInt()
            val col = (alpha shl 24) or 0x00FFFFFF
            ip.color = col
            drawIcon(canvas, tabs[i].first, ix, h * 0.40f - d * 1.5f * k, d * 0.92f, ip)
            tp.color = col
            canvas.drawText(tabs[i].second, ix, h - d * 13f, tp)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { press = true; invalidate() }
            MotionEvent.ACTION_UP -> {
                press = false
                val i = ((e.x - pad) / tabW()).toInt().coerceIn(0, tabs.size - 1)
                invalidate()
                if (i != selected) {
                    select(i, true)
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    onSelect(i)
                }
            }
            MotionEvent.ACTION_CANCEL -> { press = false; invalidate() }
        }
        return true
    }
}
