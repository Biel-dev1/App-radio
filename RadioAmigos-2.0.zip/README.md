# Rádio Amigos 2.0 — projeto inicial

## O que existe nesta versão
- Interface Android com modo internet e modo Bluetooth.
- Botão pressionado para transmitir áudio PCM.
- Serviço Android em primeiro plano para tentar manter áudio ativo com a tela apagada.
- Servidor WebSocket simples em `server/` para retransmitir áudio entre celulares na mesma sala.
- GitHub Actions para compilar o APK.

## Limitações importantes
Este é um protótipo inicial e precisa ser testado em dois aparelhos reais. A transmissão usa PCM sem compressão/criptografia de ponta a ponta, portanto não deve ser usada para conversas privadas ou sensíveis. O servidor precisa ser publicado com TLS (wss://) antes de uso online. Não exponha um servidor `ws://` público.
O modo offline nesta versão implementa Bluetooth RFCOMM com dispositivos previamente pareados. Wi-Fi local ainda não está implementado. O áudio em segundo plano depende das permissões e restrições da versão Android; conceda microfone e permita notificações.
O servidor relay é temporário: salas desaparecem quando todos saem; não há autenticação, limite de usuários ou proteção contra abuso. Use apenas para testes.
## Como publicar servidor
1. Crie conta em Render e conecte este repositório GitHub.
2. Selecione o blueprint `render.yaml` (ou crie um Web Service com Root Directory `server`, Build Command `npm install`, Start Command `npm start`).
3. Depois de publicado, copie o domínio HTTPS fornecido. O WebSocket seguro normalmente usa `wss://` seguido do domínio e porta gerenciada pelo Render. O servidor atual escuta na porta `PORT` e o host do provedor faz o TLS.
4. No app, substitua `wss://SEU-SERVIDOR-AQUI` pelo endereço `wss://SEU-DOMINIO.onrender.com` e compile novamente.
## Como compilar
GitHub Actions compila o APK quando você envia commits para `main`/`master`, ou manualmente em Actions → Construir Rádio Amigos APK → Run workflow. Baixe o artifact `RadioAmigos-2.0-APK` após sucesso.
