# Rádio Amigos 2.0 — projeto inicial

## O que existe nesta versão
- Interface Android com modo internet e modo Bluetooth.
- Botão pressionado para transmitir áudio PCM.
- Serviço Android em primeiro plano para tentar manter áudio ativo com a tela apagada.
- Servidor WebSocket simples em `server/` para retransmitir áudio entre celulares na mesma sala.
- GitHub Actions para compilar o APK.

## Limitações importantes
Este é um protótipo inicial e precisa ser testado em dois aparelhos reais. A transmissão usa PCM sem compressão/criptografia de ponta a ponta, portanto não deve ser usada para conversas privadas ou sensíveis. O servidor precisa ser publicado com TLS (wss://) antes de uso online. Não exponha um servidor `ws://` público.
O modo offline nesta versão implementa Bluetooth RFCOMM com dispositivos previamente pareados. Wi-Fi local ainda não está implementado. O áudio em segundo plano depende das permissões e restrições da versão Android; conceda microfone e permita notificações.
O servidor relay é temporário: salas desaparecem quando todos saem; não há autenticação, limite de usuários ou proteção contra abuso. Use apenas para testes.
## Como publicar servidor
1. Crie conta em Render e conecte este repositório GitHub.
2. Selecione o blueprint `render.yaml` (ou crie um Web Service com Root Directory `server`, Build Command `npm install`, Start Command `npm start`).
3. Depois de publicado, copie o domínio HTTPS fornecido. O WebSocket seguro normalmente usa `wss://` seguido do domínio e porta gerenciada pelo Render. O servidor atual escuta na porta `PORT` e o host do provedor faz o TLS.
4. No app, substitua `wss://SEU-SERVIDOR-AQUI` pelo endereço `wss://SEU-DOMINIO.onrender.com` e compile novamente.
## Como compilar
GitHub Actions compila o APK quando você envia commits para `main`/`master`, ou manualmente em Actions → Construir Rádio Amigos APK → Run workflow. Baixe o artifact `RadioAmigos-2.0-APK` após sucesso.


## Endereço do servidor configurado
O app está pré-configurado para `wss://radio-amigos-server.onrender.com`. Confirme que este é o domínio do serviço Render publicado na sua conta antes de compilar.

## Pagamento por sala (Stripe)
Entrar numa sala é grátis; criar uma sala é pago (cartão ou Pix, via Stripe Checkout).
O app nunca guarda chave do Stripe: quem cria o pagamento é o servidor (`server/server.js`).

Variáveis de ambiente no Render (Environment):
- `STRIPE_SECRET_KEY` — chave secreta do Stripe (`sk_test_...` para testar, `sk_live_...` para valer). **Sem ela, as salas são grátis.**
- `BASE_URL` — endereço do servidor, ex.: `https://radio-amigos-server.onrender.com`
- `ROOM_PRICE_CENTS` — preço em centavos (`990` = R$ 9,90)
- `ROOM_DAYS` — quantos dias a sala fica ativa depois de paga (`30`)

Como funciona: o app pede `/checkout` → abre a página de pagamento do Stripe no navegador → consulta `/checkout-status` até confirmar → entra na sala.
O Stripe é o "banco de dados": cada pagamento leva o código da sala nos metadados, então o servidor não precisa de banco próprio.
