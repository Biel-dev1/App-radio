-- Duelo de Minas: correção de segurança da senha de 6 dígitos (versão 07).
-- Problemas corrigidos:
--  1) O usuário conseguia ler o hash do PIN (coluna em profiles). Agora fica em tabela sem acesso.
--  2) Senha errada dava RAISE, e o PostgreSQL desfazia a contagem de tentativas: nunca bloqueava.
--     Agora as funções RETORNAM um código; a contagem é gravada sempre.
--  3) Bloqueio fixo de 5 min podia ser repetido para sempre. Agora o tempo dobra a cada rodada.
--  4) Trocar a senha não pedia a senha atual.
-- Rode no Supabase > SQL Editor. Tudo numa transação.
begin;

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------- tabela protegida
create table if not exists public.security_pins (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  pin_hash text not null,
  attempts integer not null default 0,
  lockouts integer not null default 0,
  locked_until timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.security_pins enable row level security;
revoke all on public.security_pins from anon, authenticated;
grant select, insert, update, delete on public.security_pins to service_role;

-- migra o que a 07 gravou em profiles (se existir) e remove as colunas expostas
do $mig$
begin
  if exists (select 1 from information_schema.columns
             where table_schema = 'public' and table_name = 'profiles' and column_name = 'pin_hash') then
    insert into public.security_pins (user_id, pin_hash, attempts, locked_until)
    select id, pin_hash, coalesce(pin_attempts, 0), pin_locked_until
    from public.profiles where pin_hash is not null
    on conflict (user_id) do nothing;
  end if;
end
$mig$;

alter table public.profiles drop column if exists pin_hash;
alter table public.profiles drop column if exists pin_attempts;
alter table public.profiles drop column if exists pin_locked_until;

-- versões antigas que davam erro/retornavam boolean
drop function if exists public.verify_user_pin(uuid, text);
drop function if exists public.request_withdrawal(uuid, bigint, text, text);
drop function if exists public.request_withdrawal(uuid, bigint, text, text, text);
-- a 07 criou set_my_security_pin(text); sem este drop a chamada do app fica ambígua
drop function if exists public.set_my_security_pin(text);

-- ---------------------------------------------------------------- verificação (NÃO dá RAISE na senha errada)
-- Retorna: 'ok' | 'wrong' | 'locked' | 'not_set' | 'invalid'
create or replace function public.check_user_pin(p_user uuid, p_pin text)
returns text
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  r public.security_pins%rowtype;
  n integer;
begin
  if p_pin is null or p_pin !~ '^[0-9]{6}$' then
    return 'invalid';
  end if;

  select * into r from public.security_pins where user_id = p_user for update;
  if not found then
    return 'not_set';
  end if;

  if r.locked_until is not null and now() < r.locked_until then
    return 'locked';
  end if;

  if crypt(p_pin, r.pin_hash) = r.pin_hash then
    update public.security_pins
       set attempts = 0, lockouts = 0, locked_until = null
     where user_id = p_user;
    return 'ok';
  end if;

  n := r.attempts + 1;
  if n >= 5 then
    -- 5 min, depois 10, 20, ... até 24 h
    update public.security_pins
       set attempts = 0,
           lockouts = r.lockouts + 1,
           locked_until = now() + least(interval '5 minutes' * power(2, r.lockouts), interval '24 hours')
     where user_id = p_user;
    return 'locked';
  end if;

  update public.security_pins set attempts = n where user_id = p_user;
  return 'wrong';
end
$fn$;

-- ---------------------------------------------------------------- cadastrar / trocar (usuário logado)
-- Se já existe senha, exige a senha atual (p_current). Retorna um código como acima.
create or replace function public.set_my_security_pin(p_pin text, p_current text default null)
returns text
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  u uuid := auth.uid();
  code text;
begin
  if u is null then
    raise exception 'Não autenticado.' using errcode = 'P0001';
  end if;
  if p_pin is null or p_pin !~ '^[0-9]{6}$' then
    raise exception 'A senha precisa ter exatamente 6 números.' using errcode = 'P0001';
  end if;
  if p_pin ~ '^([0-9])\1{5}$' or p_pin in ('123456', '654321', '012345', '543210') then
    raise exception 'Escolha uma senha menos óbvia (sem repetir ou sequência).' using errcode = 'P0001';
  end if;

  if exists (select 1 from public.security_pins where user_id = u) then
    code := public.check_user_pin(u, p_current);   -- conta a tentativa mesmo se errar
    if code <> 'ok' then
      return code;
    end if;
  end if;

  insert into public.security_pins (user_id, pin_hash, attempts, lockouts, locked_until, updated_at)
  values (u, crypt(p_pin, gen_salt('bf', 10)), 0, 0, null, now())
  on conflict (user_id) do update
    set pin_hash = excluded.pin_hash, attempts = 0, lockouts = 0,
        locked_until = null, updated_at = now();
  return 'ok';
end
$fn$;

create or replace function public.has_security_pin()
returns boolean
language sql
security definer
stable
set search_path = public
as $fn$
  select exists (select 1 from public.security_pins where user_id = auth.uid());
$fn$;

-- ---------------------------------------------------------------- saque (service_role)
-- Sempre RETORNA jsonb (nunca dá RAISE por regra de negócio), para o contador ser gravado.
create or replace function public.request_withdrawal(
  p_user uuid, p_amount bigint, p_pix_type text, p_pix_key text, p_pin text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  code text;
  bal bigint;
  wid bigint;
begin
  code := public.check_user_pin(p_user, p_pin);
  if code <> 'ok' then
    return jsonb_build_object('ok', false, 'error', code);
  end if;

  if p_amount < 2000 then
    return jsonb_build_object('ok', false, 'error', 'min');
  end if;
  if p_pix_type not in ('cpf', 'cnpj', 'email', 'phone', 'random') then
    return jsonb_build_object('ok', false, 'error', 'pix_type');
  end if;
  if char_length(coalesce(p_pix_key, '')) < 3 or char_length(p_pix_key) > 140 then
    return jsonb_build_object('ok', false, 'error', 'pix_key');
  end if;
  if exists (select 1 from public.withdrawals where user_id = p_user and status = 'pending') then
    return jsonb_build_object('ok', false, 'error', 'pending');
  end if;

  select balance_cents into bal from public.profiles where id = p_user for update;
  if bal is null or bal < p_amount then
    return jsonb_build_object('ok', false, 'error', 'insufficient');
  end if;

  insert into public.withdrawals (user_id, amount_cents, pix_type, pix_key, status)
  values (p_user, p_amount, p_pix_type, p_pix_key, 'pending')
  returning id into wid;

  perform public.move_balance(p_user, 'withdraw', -p_amount, 'withdraw:' || wid::text);

  return jsonb_build_object('ok', true, 'withdrawal_id', wid);
end
$fn$;

-- ---------------------------------------------------------------- permissões
revoke all on function public.check_user_pin(uuid, text) from public, anon, authenticated;
grant execute on function public.check_user_pin(uuid, text) to service_role;

revoke all on function public.set_my_security_pin(text, text) from public, anon;
grant execute on function public.set_my_security_pin(text, text) to authenticated;

revoke all on function public.has_security_pin() from public, anon;
grant execute on function public.has_security_pin() to authenticated;

revoke all on function public.request_withdrawal(uuid, bigint, text, text, text) from public, anon, authenticated;
grant execute on function public.request_withdrawal(uuid, bigint, text, text, text) to service_role;

commit;

-- Verificação: a tabela do PIN não deve ser legível pelo usuário; profiles não deve ter colunas de PIN.
select has_table_privilege('authenticated', 'public.security_pins', 'SELECT') as usuario_le_pins_esperado_false,
       (select count(*) from information_schema.columns
         where table_schema = 'public' and table_name = 'profiles' and column_name like 'pin%') as colunas_pin_em_profiles_esperado_0;
