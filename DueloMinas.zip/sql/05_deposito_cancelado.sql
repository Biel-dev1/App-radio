-- Duelo de Minas: permite depósito 'cancelled' (jogador desistiu do Pix antes de pagar).
-- Rode depois do 04_depositos_saques.sql. Tudo numa transação.
begin;

alter table public.deposits drop constraint if exists deposits_status_check;
alter table public.deposits add constraint deposits_status_check
  check (status in ('pending', 'credited', 'cancelled', 'failed'));

commit;

select pg_get_constraintdef(oid) as status_check
from pg_constraint where conrelid = 'public.deposits'::regclass and conname = 'deposits_status_check';
