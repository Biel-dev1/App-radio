-- Rode no Supabase > SQL Editor (uma vez). Corrige "permission denied for table profiles"
-- ao concluir nome/foto/bio no app.

begin;

-- App só pode alterar campos públicos (não saldo/ban/wins).
revoke update on public.profiles from anon, authenticated;
grant update (display_name, bio, avatar_url, profile_done, country)
  on public.profiles to authenticated;

-- Caminho seguro: RPC com security definer
create or replace function public.complete_profile(
  p_display_name text,
  p_bio text default '',
  p_country text default 'BR',
  p_avatar_url text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $fn$
declare
  uid uuid := auth.uid();
  nome text := left(trim(coalesce(p_display_name, '')), 20);
begin
  if uid is null then
    raise exception 'Não autenticado' using errcode = 'P0001';
  end if;
  if char_length(nome) < 3 then
    raise exception 'O nome precisa ter pelo menos 3 letras.' using errcode = 'P0001';
  end if;

  update public.profiles set
    display_name = nome,
    bio = left(coalesce(p_bio, ''), 200),
    country = left(coalesce(nullif(trim(p_country), ''), 'BR'), 8),
    avatar_url = case
      when p_avatar_url is null or p_avatar_url = '' then avatar_url
      else p_avatar_url
    end,
    profile_done = true
  where id = uid;

  if not found then
    raise exception 'Perfil não encontrado. Saia e entre de novo.' using errcode = 'P0001';
  end if;
end
$fn$;

revoke all on function public.complete_profile(text, text, text, text) from public, anon;
grant execute on function public.complete_profile(text, text, text, text) to authenticated, service_role;

-- Garante que o usuário autenticado enxerga o próprio perfil
drop policy if exists "perfil: ler o proprio" on public.profiles;
create policy "perfil: ler o proprio"
  on public.profiles for select to authenticated
  using (id = auth.uid());

drop policy if exists "perfil: editar o proprio" on public.profiles;
create policy "perfil: editar o proprio"
  on public.profiles for update to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

commit;

select 'complete_profile ok' as status;
