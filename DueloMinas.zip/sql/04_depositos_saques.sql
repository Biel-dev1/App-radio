-- Duelo de Minas: depósitos pendentes no banco + base de saques.
-- Rode UMA vez no Supabase > SQL Editor. Tudo numa transação.
begin;

-- ---------------------------------------------------------------- depósitos
create table if not exists public.deposits (
  identifier text primary key,                       -- id da transação na SyncPay
  user_id uuid not null references public.profiles(id) on delete cascade,
  cents bigint not null check (cents > 0),
  status text not null default 'pending' check (status in ('pending', 'credited', 'failed')),
  created_at timestamptz not null default now(),
  credited_at timestamptz
);
create index if not exists deposits_status_created_idx on public.deposits(status, created_at);

-- Só o servidor (service_role) mexe aqui. Ninguém do app lê ou escreve direto.
alter table public.deposits enable row level security;
revoke all on public.deposits from anon, authenticated;
grant select, insert, update on public.deposits to service_role;

-- ---------------------------------------------------------------- saques
-- Pedido de saque: debita o saldo e cria o pedido como 'pending', tudo numa transação.
-- Se algo falhar, nada fica pela metade. Só o servidor chama (service_role).
create or replace function public.request_withdrawal(
  p_user uuid, p_amount bigint, p_pix_type text, p_pix_key text
)
returns bigint
language plpgsql
security definer
set search_path = public
as $fn$
declare
  wid bigint;
begin
  if p_amount < 1000 then   -- mínimo R$ 10,00 (ajuste se quiser)
    raise exception 'O saque mínimo é R$ 10,00.' using errcode = 'P0001';
  end if;
  if p_pix_type not in ('cpf', 'cnpj', 'email', 'phone', 'random') then
    raise exception 'Tipo de chave Pix inválido.' using errcode = 'P0001';
  end if;
  if char_length(coalesce(p_pix_key, '')) < 3 or char_length(p_pix_key) > 140 then
    raise exception 'Chave Pix inválida.' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.withdrawals where user_id = p_user and status = 'pending') then
    raise exception 'Você já tem um saque em andamento.' using errcode = 'P0001';
  end if;

  insert into public.withdrawals (user_id, amount_cents, pix_type, pix_key, status)
  values (p_user, p_amount, p_pix_type, p_pix_key, 'pending')
  returning id into wid;

  begin
    perform public.move_balance(p_user, 'withdraw', -p_amount, 'withdraw:' || wid::text);
  exception when check_violation then
    raise exception 'Saldo insuficiente.' using errcode = 'P0001';
  end;

  return wid;
end
$fn$;

-- Cancela/recusa um saque pendente e devolve o valor ao saldo.
create or replace function public.cancel_withdrawal(p_id bigint, p_reason text default null)
returns void
language plpgsql
security definer
set search_path = public
as $fn$
declare
  w public.withdrawals%rowtype;
begin
  select * into w from public.withdrawals where id = p_id for update;
  if not found or w.status <> 'pending' then
    return;   -- já tratado: não devolve de novo
  end if;

  perform public.move_balance(w.user_id, 'withdraw_refund', w.amount_cents, 'withdraw_refund:' || p_id::text);
  update public.withdrawals set status = 'failed', decided_at = now() where id = p_id;
  insert into public.security_audit (action, target_id, detail)
  values ('withdraw_cancelled', w.user_id, jsonb_build_object('withdrawal_id', p_id, 'reason', left(coalesce(p_reason, ''), 200)));
end
$fn$;

-- Marca saque como enviado (depois que a SyncPay aceitar o pagamento).
create or replace function public.mark_withdrawal_sent(p_id bigint)
returns void
language sql
security definer
set search_path = public
as $fn$
  update public.withdrawals set status = 'sent', decided_at = now()
  where id = p_id and status = 'pending';
$fn$;

revoke all on function public.request_withdrawal(uuid, bigint, text, text) from public, anon, authenticated;
revoke all on function public.cancel_withdrawal(bigint, text) from public, anon, authenticated;
revoke all on function public.mark_withdrawal_sent(bigint) from public, anon, authenticated;
grant execute on function public.request_withdrawal(uuid, bigint, text, text) to service_role;
grant execute on function public.cancel_withdrawal(bigint, text) to service_role;
grant execute on function public.mark_withdrawal_sent(bigint) to service_role;

commit;

-- Verificação: RLS ligado em deposits e funções só para service_role.
select tablename, rowsecurity from pg_tables where schemaname = 'public' and tablename = 'deposits';
