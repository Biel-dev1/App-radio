-- Duelo de Minas: 2ª etapa de segurança. Idempotente. Rode DEPOIS de 01_security_hardening.sql.
-- Supabase → SQL Editor → colar tudo → Run.

begin;

-- ---- Banimento (só service_role) ----
create or replace function public.ban_user(p_user uuid, p_reason text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.profiles
     set banned = true,
         banned_reason = left(coalesce(p_reason, 'bloqueado'), 200),
         banned_at = now()
   where id = p_user;
  insert into public.security_audit(action, target_id, detail)
  values ('ban', p_user, jsonb_build_object('reason', left(coalesce(p_reason, ''), 200)));
end $$;

create or replace function public.unban_user(p_user uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.profiles
     set banned = false, banned_reason = null, banned_at = null
   where id = p_user;
  insert into public.security_audit(action, target_id, detail)
  values ('unban', p_user, '{}'::jsonb);
end $$;

revoke all on function public.ban_user(uuid, text) from public, anon, authenticated;
revoke all on function public.unban_user(uuid) from public, anon, authenticated;
grant execute on function public.ban_user(uuid, text) to service_role;
grant execute on function public.unban_user(uuid) to service_role;

-- ---- Apagar conta: anonimiza perfil e preserva extrato/partidas (exigência legal) ----
-- Partidas e ledger mantêm o uuid do usuário; o perfil vira "Conta apagada" e fica banido.
create or replace function public.delete_my_account()
returns void language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
begin
  if uid is null then
    raise exception 'Não autenticado';
  end if;

  -- Impede apagar no meio de partida paga ainda em andamento
  if exists (
    select 1 from public.matches
     where status in ('pending', 'paid')
       and (p1 = uid or p2 = uid)
  ) then
    raise exception 'Você tem partida em andamento. Termine ou aguarde o reembolso antes de apagar a conta.'
      using errcode = 'P0001';
  end if;

  update public.profiles set
    display_name = 'Conta apagada',
    bio = null,
    avatar_url = null,
    profile_done = false,
    banned = true,
    banned_reason = 'conta_apagada',
    banned_at = now()
  where id = uid;

  -- Remove arquivos de avatar do próprio usuário (melhora esforço; storage pode falhar sem abortar)
  begin
    delete from storage.objects
     where bucket_id = 'avatars'
       and (name like uid::text || '/%' or name like 'avatar/' || uid::text || '/%');
  exception when others then
    null;
  end;

  insert into public.security_audit(action, actor_id, target_id, detail)
  values ('delete_account', uid, uid, '{}'::jsonb);

  -- Soft-delete do usuário de auth (se a extensão/API permitir; senão o app ainda desloga)
  -- Não chamamos auth.admin aqui: fica no app/serviço. O perfil já está inutilizável.
end $$;

revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated, service_role;

-- ---- Storage: políticas restritas ao próprio avatar ----
-- Garante limite de tamanho/MIME (idempotente com o 01)
update storage.buckets
   set file_size_limit = 1048576,
       allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif']
 where id = 'avatars';

-- Remove políticas antigas genéricas (se existirem) e recria as seguras
drop policy if exists "avatars_public_read" on storage.objects;
drop policy if exists "avatars_owner_insert" on storage.objects;
drop policy if exists "avatars_owner_update" on storage.objects;
drop policy if exists "avatars_owner_delete" on storage.objects;
drop policy if exists "Avatar images are publicly accessible" on storage.objects;
drop policy if exists "Anyone can upload an avatar" on storage.objects;
drop policy if exists "Anyone can update their own avatar" on storage.objects;

create policy "avatars_public_read"
  on storage.objects for select
  using (bucket_id = 'avatars');

-- Só grava em <uid>/... (um prefixo fixo por usuário)
create policy "avatars_owner_insert"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "avatars_owner_update"
  on storage.objects for update to authenticated
  using (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = auth.uid()::text
  )
  with check (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "avatars_owner_delete"
  on storage.objects for delete to authenticated
  using (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

commit;

-- Verificação rápida
select proname from pg_proc
 where pronamespace = 'public'::regnamespace
   and proname in ('ban_user','unban_user','delete_my_account')
 order by 1;
