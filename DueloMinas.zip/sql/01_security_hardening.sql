-- Duelo de Minas: execute UMA vez no Supabase > SQL Editor. É idempotente.
-- Confirme os nomes das tabelas existentes antes de executar em produção.
begin;

alter table public.profiles add column if not exists banned boolean not null default false;
alter table public.profiles add column if not exists banned_reason text;
alter table public.profiles add column if not exists banned_at timestamptz;
alter table public.matches add column if not exists instance_id text;
alter table public.matches add column if not exists last_activity_at timestamptz not null default now();
alter table public.matches add column if not exists attention_required boolean not null default false;
alter table public.matches add column if not exists attention_detail text;

alter table public.profiles drop constraint if exists profiles_display_name_safe;
alter table public.profiles add constraint profiles_display_name_safe
  check (char_length(display_name) between 3 and 20 and display_name !~ '[[:cntrl:]]');
alter table public.profiles drop constraint if exists profiles_avatar_own_bucket;
alter table public.profiles add constraint profiles_avatar_own_bucket check (
  avatar_url is null or avatar_url = '' or avatar_url like ('https://zrvzrxbkviurspuotdzi.supabase.co/storage/v1/object/public/avatars/' || id::text || '/%')
);

-- Somente campos públicos podem ser alterados pelo app. Dinheiro, banimento,
-- username, termos e profile_done continuam fora da permissão do authenticated.
revoke update on public.profiles from anon, authenticated;
grant update (display_name, bio, avatar_url) on public.profiles to authenticated;
revoke insert, update, delete on public.ledger, public.matches from anon, authenticated;
revoke all on function public.pay_match(uuid, uuid) from public, anon, authenticated;
revoke all on function public.finish_match(uuid, uuid) from public, anon, authenticated;
revoke all on function public.refund_match(uuid) from public, anon, authenticated;
grant execute on function public.pay_match(uuid, uuid) to service_role;
grant execute on function public.finish_match(uuid, uuid) to service_role;
grant execute on function public.refund_match(uuid) to service_role;

-- A chave do extrato deve ser por usuário; ajuste os nomes se a versão antiga usar outra constraint.
drop index if exists public.ledger_type_ref_key;
create unique index if not exists ledger_user_type_ref_unique on public.ledger(user_id, type, ref) where ref is not null;

create table if not exists public.security_audit (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(), actor_id uuid, action text not null,
  target_id uuid, match_id uuid, detail jsonb not null default '{}'::jsonb
);
alter table public.security_audit enable row level security;
revoke all on public.security_audit from anon, authenticated;

create or replace function public.touch_match(p_match uuid, p_instance text)
returns void language plpgsql security definer set search_path = public as $$
begin
 update matches set instance_id=p_instance, last_activity_at=now() where id=p_match and status in ('pending','paid');
end $$;
create or replace function public.recover_matches(p_instance text, p_stale_before timestamptz)
returns integer language plpgsql security definer set search_path = public as $$
declare n integer := 0; r record;
begin
 -- Só partidas órfãs: uma instância saudável atualiza last_activity_at.
 for r in select id from matches where status in ('pending','paid') and last_activity_at < p_stale_before for update skip locked loop
   perform refund_match(r.id);
   update matches set instance_id=p_instance, last_activity_at=now() where id=r.id;
   n := n + 1;
 end loop;
 return n;
end $$;
create or replace function public.mark_match_attention(p_match uuid, p_detail text)
returns void language plpgsql security definer set search_path = public as $$
begin
 update matches set attention_required=true, attention_detail=left(p_detail,500), last_activity_at=now() where id=p_match;
 insert into security_audit(action, match_id, detail) values ('settlement_attention', p_match, jsonb_build_object('detail',left(p_detail,500)));
end $$;
create or replace function public.flag_match(p_match uuid, p_kind text, p_detail jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
 insert into security_audit(action, match_id, detail) values (left(p_kind,60), p_match, coalesce(p_detail,'{}'::jsonb));
end $$;
revoke all on function public.touch_match(uuid,text), public.recover_matches(text,timestamptz), public.mark_match_attention(uuid,text), public.flag_match(uuid,text,jsonb) from public, anon, authenticated;
grant execute on function public.touch_match(uuid,text), public.recover_matches(text,timestamptz), public.mark_match_attention(uuid,text), public.flag_match(uuid,text,jsonb) to service_role;

-- O bucket e as políticas são seguros para avatar/<uid>/avatar.{jpg,png,webp,gif}.
update storage.buckets set file_size_limit=1048576, allowed_mime_types=array['image/jpeg','image/png','image/webp','image/gif'] where id='avatars';
commit;

-- Verificação: o resultado deve mostrar RLS=true e somente display_name,bio,avatar_url em update.
select table_name, rowsecurity from pg_tables where schemaname='public' and tablename in ('profiles','ledger','matches','security_audit');
select column_name, privilege_type from information_schema.column_privileges where table_schema='public' and table_name='profiles' and grantee='authenticated' order by column_name;
