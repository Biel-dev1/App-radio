-- Saque automático via SyntraPay. Rode no Supabase → SQL Editor.
-- 1) A tabela não aceitava chave CNPJ, mas request_withdrawal aceita: o saque com CNPJ falharia.
alter table public.withdrawals drop constraint if exists withdrawals_pix_type_check;
alter table public.withdrawals add constraint withdrawals_pix_type_check
  check (pix_type = any (array['random','cpf','cnpj','email','phone']));

-- 2) mark_withdrawal_sent gravava status 'sent', que a tabela não permite (só pending/approved/paid/rejected).
--    O servidor novo não usa esta função; ela passa a gravar 'paid' para não quebrar se alguém chamar.
create or replace function public.mark_withdrawal_sent(p_id bigint)
returns void language sql security definer set search_path = public as $$
  update public.withdrawals set status = 'paid', decided_at = now() where id = p_id and status in ('pending','approved');
$$;
revoke all on function public.mark_withdrawal_sent(bigint) from public, anon, authenticated;
grant execute on function public.mark_withdrawal_sent(bigint) to service_role;

-- Conferência: não deve devolver nenhuma linha com status inválido.
select id, status from public.withdrawals where status not in ('pending','approved','paid','rejected');
