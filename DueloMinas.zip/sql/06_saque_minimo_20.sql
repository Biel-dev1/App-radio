-- Duelo de Minas: saque mínimo passa a ser R$ 20,00.
-- Rode no Supabase > SQL Editor. Se você já rodou o 04 com R$ 10, este script corrige.
begin;

create or replace function public.request_withdrawal(
  p_user uuid, p_amount bigint, p_pix_type text, p_pix_key text
)
returns bigint
language plpgsql
security definer
set search_path = public
as $fn$
declare
  wid bigint;
begin
  if p_amount < 2000 then   -- mínimo R$ 20,00
    raise exception 'O saque mínimo é R$ 20,00.' using errcode = 'P0001';
  end if;
  if p_pix_type not in ('cpf', 'cnpj', 'email', 'phone', 'random') then
    raise exception 'Tipo de chave Pix inválido.' using errcode = 'P0001';
  end if;
  if char_length(coalesce(p_pix_key, '')) < 3 or char_length(p_pix_key) > 140 then
    raise exception 'Chave Pix inválida.' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.withdrawals where user_id = p_user and status = 'pending') then
    raise exception 'Você já tem um saque em andamento.' using errcode = 'P0001';
  end if;

  insert into public.withdrawals (user_id, amount_cents, pix_type, pix_key, status)
  values (p_user, p_amount, p_pix_type, p_pix_key, 'pending')
  returning id into wid;

  begin
    perform public.move_balance(p_user, 'withdraw', -p_amount, 'withdraw:' || wid::text);
  exception when check_violation then
    raise exception 'Saldo insuficiente.' using errcode = 'P0001';
  end;

  return wid;
end
$fn$;

revoke all on function public.request_withdrawal(uuid, bigint, text, text) from public, anon, authenticated;
grant execute on function public.request_withdrawal(uuid, bigint, text, text) to service_role;

commit;

select pg_get_functiondef('public.request_withdrawal(uuid,bigint,text,text)'::regprocedure) ilike '%p_amount < 2000%' as minimo_20_ok;
