-- Duelo de Minas: Senha de segurança de 6 dígitos para Saques e Pagamentos
-- Criptografia com pgcrypto (bcrypt) e proteção contra força bruta
begin;

create extension if not exists pgcrypto;

-- Colunas de segurança na tabela profiles
alter table public.profiles add column if not exists pin_hash text;
alter table public.profiles add column if not exists pin_attempts integer not null default 0;
alter table public.profiles add column if not exists pin_locked_until timestamptz;

-- 1. Verifica se o usuário atual tem PIN cadastrado
create or replace function public.has_security_pin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select coalesce(pin_hash is not null, false) from public.profiles where id = auth.uid();
$$;

-- 2. Cadastra ou altera a senha de 6 dígitos do próprio usuário
create or replace function public.set_my_security_pin(p_pin text)
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  u uuid := auth.uid();
begin
  if u is null then
    raise exception 'Não autenticado.' using errcode = 'P0001';
  end if;
  if p_pin is null or length(p_pin) <> 6 or p_pin !~ '^[0-9]{6}$' then
    raise exception 'A senha precisa ter exatamente 6 números.' using errcode = 'P0001';
  end if;

  update public.profiles
  set pin_hash = crypt(p_pin, gen_salt('bf', 10)),
      pin_attempts = 0,
      pin_locked_until = null
  where id = u;

  return true;
end;
$$;

-- 3. Verifica o PIN de um usuário (chamado pelo servidor com chave service_role)
create or replace function public.verify_user_pin(p_user uuid, p_pin text)
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  stored_hash text;
  attempts int;
  locked_until timestamptz;
begin
  if p_pin is null or length(p_pin) <> 6 or p_pin !~ '^[0-9]{6}$' then
    raise exception 'A senha precisa ter 6 dígitos.' using errcode = 'P0001';
  end if;

  select pin_hash, coalesce(pin_attempts, 0), pin_locked_until
  into stored_hash, attempts, locked_until
  from public.profiles
  where id = p_user;

  if stored_hash is null then
    raise exception 'Você ainda não cadastrou sua senha de 6 dígitos.' using errcode = 'P0001';
  end if;

  if locked_until is not null and now() < locked_until then
    raise exception 'Senha bloqueada por excesso de tentativas. Tente novamente mais tarde.' using errcode = 'P0001';
  end if;

  if stored_hash = crypt(p_pin, stored_hash) then
    update public.profiles
    set pin_attempts = 0, pin_locked_until = null
    where id = p_user;
    return true;
  else
    attempts := attempts + 1;
    if attempts >= 5 then
      update public.profiles
      set pin_attempts = 0, pin_locked_until = now() + interval '5 minutes'
      where id = p_user;
      raise exception 'Muitas tentativas erradas. Senha bloqueada por 5 minutos.' using errcode = 'P0001';
    else
      update public.profiles
      set pin_attempts = attempts
      where id = p_user;
      raise exception 'Senha de 6 dígitos incorreta.' using errcode = 'P0001';
    end if;
  end if;
end;
$$;

-- 4. Solicitação de saque com validação obrigatória do PIN no banco
create or replace function public.request_withdrawal(
  p_user uuid, p_amount bigint, p_pix_type text, p_pix_key text, p_pin text
)
returns bigint
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  wid bigint;
begin
  -- Valida a senha no banco antes de qualquer operação financeira
  perform public.verify_user_pin(p_user, p_pin);

  if p_amount < 2000 then   -- mínimo R$ 20,00
    raise exception 'O saque mínimo é R$ 20,00.' using errcode = 'P0001';
  end if;
  if p_pix_type not in ('cpf', 'cnpj', 'email', 'phone', 'random') then
    raise exception 'Tipo de chave Pix inválido.' using errcode = 'P0001';
  end if;
  if char_length(coalesce(p_pix_key, '')) < 3 or char_length(p_pix_key) > 140 then
    raise exception 'Chave Pix inválida.' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.withdrawals where user_id = p_user and status = 'pending') then
    raise exception 'Você já tem um saque em andamento.' using errcode = 'P0001';
  end if;

  insert into public.withdrawals (user_id, amount_cents, pix_type, pix_key, status)
  values (p_user, p_amount, p_pix_type, p_pix_key, 'pending')
  returning id into wid;

  begin
    perform public.move_balance(p_user, 'withdraw', -p_amount, 'withdraw:' || wid::text);
  exception when check_violation then
    raise exception 'Saldo insuficiente.' using errcode = 'P0001';
  end;

  return wid;
end;
$$;

-- Compatibilidade com chamada sem PIN (apenas service_role se necessário)
create or replace function public.request_withdrawal(
  p_user uuid, p_amount bigint, p_pix_type text, p_pix_key text
)
returns bigint
language plpgsql
security definer
set search_path = public
as $$
begin
  raise exception 'A senha de 6 dígitos é obrigatória para efetuar saques.' using errcode = 'P0001';
end;
$$;

revoke all on function public.set_my_security_pin(text) from public, anon;
grant execute on function public.set_my_security_pin(text) to authenticated;

revoke all on function public.has_security_pin() from public, anon;
grant execute on function public.has_security_pin() to authenticated;

revoke all on function public.verify_user_pin(uuid, text) from public, anon, authenticated;
grant execute on function public.verify_user_pin(uuid, text) to service_role;

revoke all on function public.request_withdrawal(uuid, bigint, text, text, text) from public, anon, authenticated;
grant execute on function public.request_withdrawal(uuid, bigint, text, text, text) to service_role;

commit;

select '07_security_pin_aplicado_com_sucesso' as status;
