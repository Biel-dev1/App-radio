# Duelo de Minas — Fase 1
Login, termos e 18+, perfil obrigatório, menu Liquid Glass (Lobby, Salas, Ranking, Perfil).
Banco: Supabase (rode supabase_base.sql e depois supabase_fase1.sql no SQL Editor).
A chave em Api.kt é a "publishable" (pública). Nunca coloque a chave secret/service_role no app.
Saldo em modo teste: ainda não vale dinheiro. Salas, partidas, depósito e saque vêm nas próximas fases.
