# Duelo de Minas

Android (Kotlin) e servidor Node (`server/`). Para aplicar esta versão: execute primeiro `sql/01_security_hardening.sql` no **Supabase > SQL Editor**, suba o único `DueloMinas.zip` na raiz do GitHub e só depois faça o deploy no Render.

## Painéis (celular)

1. **Supabase > Authentication > Providers > Email**: ative confirmação de e-mail. Em **Security**, ative CAPTCHA (Turnstile/hCaptcha) e configure o mesmo token no app antes de habilitar o cadastro; enquanto isso, mantenha rate limits conservadores. Exija senha com 10+ caracteres, letras e números e ative proteção contra senha vazada se o plano mostrar a opção.
2. **GitHub > Settings > Password and authentication**: ative 2FA. Em **Settings > Branches > Add branch protection rule**, proteja `main`, exija PR e bloqueie force push. Em **Settings > Environments**, crie `release` com aprovação e coloque os secrets de assinatura somente nele. Pesquise no histórico por `sk_`, `sb_secret_`, `eyJ` e `keystore`; qualquer chave encontrada deve ser revogada e gerada de novo.
3. **Render > Service > Environment**: cadastre `SUPABASE_URL` e `SUPABASE_SERVICE_KEY` somente aqui. Use uma instância até mover as salas da memória para armazenamento compartilhado. Configure `ALERT_WEBHOOK_URL` apenas quando houver um endpoint confiável para alertas.

## Segurança

- APK externo só instala após SHA-256; esse recurso deve sair se publicar na Google Play.
- Release usa R8, backup desligado, HTTPS e `filterTouchesWhenObscured` nos botões.
- O primeiro build Android pode apontar erro de ambiente; envie o log completo se ocorrer.

## Segurança (resumo)
- Servidor do jogo fixo no app (sem tela para trocar). Endereço em Game.kt.
- Sessão (tokens) cifrada com o Keystore do Android (Vault.kt).
- Release com R8 (ofuscação), tráfego só HTTPS/WSS, backup desligado, tela protegida (MainActivity.SECURE_SCREEN).
- Servidor: limite de mensagens, de conexões por IP e de falhas de login; recusa conexões de navegador.
- Banco: rode seguranca_banco.sql no Supabase antes de usar dinheiro real.
- Zerar saldos: zerar_saldos.sql.
