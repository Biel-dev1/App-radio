# Duelo de Minas — Fase 2
App Android (Kotlin) + servidor de jogo (Node, pasta server/).
Banco: Supabase. Rode no SQL Editor, em ordem: supabase_base.sql, supabase_fase1.sql, supabase_fase2.sql.
Servidor (Render): variáveis SUPABASE_URL e SUPABASE_SERVICE_KEY (a chave secret fica SÓ no Render).
Não existe mais saldo de teste. "Adicionar saldo" pede o valor (mínimo R$ 10,00) e o servidor valida; o crédito só virá quando o gateway de pagamento (Pix) for ligado (Fase 3).
Banco: rode também reforma_perfil.sql (trocar @usuário, remover saldo de teste, GIF no avatar).
Ao abrir, o app confere sozinho se há versão nova no GitHub (Releases) e pede para atualizar.

## Segurança (resumo)
- Servidor do jogo fixo no app (sem tela para trocar). Endereço em Game.kt.
- Sessão (tokens) cifrada com o Keystore do Android (Vault.kt).
- Release com R8 (ofuscação), tráfego só HTTPS/WSS, backup desligado, tela protegida (MainActivity.SECURE_SCREEN).
- Servidor: limite de mensagens, de conexões por IP e de falhas de login; recusa conexões de navegador.
- Banco: rode seguranca_banco.sql no Supabase antes de usar dinheiro real.
- Zerar saldos: zerar_saldos.sql.
