# Duelo de Minas

Android (Kotlin) + servidor Node (`server/`).

## Aplicar esta versão (celular)

1. No **Supabase → SQL Editor**, rode nesta ordem:
   1. `sql/01_security_hardening.sql`
   2. `sql/02_account_ban_storage.sql`
2. Suba **um único** `DueloMinas.zip` na raiz do repositório GitHub.
3. No **Botkeep → Environment**, confira `SUPABASE_URL` e `SUPABASE_SERVICE_KEY`. Opcional: `ALERT_WEBHOOK_URL`, `PAIR_PER_HOUR`, `INSTANCE_ID`, `ALLOWED_ORIGINS`.
4. Redeploy no Botkeep.

Detalhes e checklist de painéis: veja `HANDOFF.md`.

## Segurança (resumo)

- Servidor fixo no app (`Game.kt` → `wss://y6z95j.bot-keep.xyz`).
- Tokens cifrados no Keystore (`Vault.kt`).
- Release com R8, backup desligado, HTTPS/WSS, `filterTouchesWhenObscured`.
- Atualização por APK só instala após SHA-256 (remover se for para a Play Store).
- Servidor: limite por IP/mensagem, banimento, recuperação de órfãs, alerta se liquidação falhar.
- Dinheiro só via funções SQL `security definer` com `service_role`.
