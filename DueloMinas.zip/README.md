# Duelo de Minas — Fase 2
App Android (Kotlin) + servidor de jogo (Node, pasta server/).
Banco: Supabase. Rode no SQL Editor, em ordem: supabase_base.sql, supabase_fase1.sql, supabase_fase2.sql.
Servidor (Render): variáveis SUPABASE_URL e SUPABASE_SERVICE_KEY (a chave secret fica SÓ no Render).
Saldo em modo de teste (TEST_MODE): não vale dinheiro. Depósito e saque reais vêm na Fase 3.
