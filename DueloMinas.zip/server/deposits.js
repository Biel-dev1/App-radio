// Confirmação de depósitos Pix. Regra de ouro: o webhook NÃO é fonte de verdade.
// Só creditamos depois de consultar a própria SyncPay e conferir status e valor.

export async function confirmDeposit(identifier, { db, syncpay, log = console }) {
  const dep = await db.getDeposit(identifier);
  if (!dep) return { ok: false, reason: "unknown" };
  if (dep.status === "credited") return { ok: true, reason: "already" };

  const cents = Number(dep.cents);
  const tx = await syncpay.getTransaction(identifier);
  if (!tx) return { ok: false, reason: "not_found" };
  if (tx.status !== "completed") return { ok: false, reason: `status:${tx.status}` };

  // Valor vem da SyncPay e tem que bater com o valor que pedimos.
  if (!Number.isFinite(tx.amountReais) || Math.round(tx.amountReais * 100) !== cents) {
    log.error("deposit amount mismatch", identifier, "esperado", cents, "recebido", tx.amountReais);
    await db.audit("deposit_amount_mismatch", dep.user_id, { identifier, expected_cents: cents, got: tx.amountReais });
    return { ok: false, reason: "amount_mismatch" };
  }

  // Idempotente: o ref "syncpay:<identifier>" impede crédito duplicado no ledger.
  await db.creditDeposit(dep.user_id, cents, identifier);
  await db.markDepositCredited(identifier);
  return { ok: true, reason: "credited" };
}

// Rede de segurança: pega pagamentos cujo webhook não chegou (ou chegou com erro).
export async function reconcilePending({ db, syncpay, olderThanMs = 3 * 60_000, log = console }) {
  if (!syncpay.enabled) return { checked: 0 };
  const cutoff = new Date(Date.now() - olderThanMs).toISOString();
  const rows = await db.pendingDepositsOlderThan(cutoff);
  let credited = 0;
  for (const r of rows) {
    try {
      const res = await confirmDeposit(r.identifier, { db, syncpay, log });
      if (res.reason === "credited") credited++;
    } catch (e) {
      log.error("reconcile", r.identifier, e && e.message ? e.message : e);
    }
  }
  return { checked: rows.length, credited };
}
