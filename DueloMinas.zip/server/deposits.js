// Confirmação de depósitos Pix. Regra de ouro: o webhook NÃO é fonte de verdade.
// Só creditamos depois de consultar a própria SyntraPay e conferir status e valor.

export async function confirmDeposit(identifier, { db, syncpay: pay, log = console, notify = null }) {
  const dep = await db.getDeposit(identifier);
  if (!dep) return { ok: false, reason: "unknown" };
  if (dep.status === "credited") return { ok: true, reason: "already" };
  // 'cancelled' também passa daqui: se o dinheiro chegou, creditamos mesmo assim.

  const cents = Number(dep.cents);
  const tx = await pay.getTransaction(identifier);
  if (!tx) return { ok: false, reason: "not_found" };
  if (tx.status !== "completed") {
    // Cobrança vencida/falha na SyntraPay: não será mais paga. Fecha aqui para sair da fila de conferência.
    if (["failed", "expired", "canceled", "cancelled", "error"].includes(String(tx.status))) {
      try { await db.markDepositFailed?.(identifier); } catch (e) { log.error("markDepositFailed", e && e.message); }
      return { ok: false, reason: `status:${tx.status}` };
    }
    return { ok: false, reason: `status:${tx.status}` };
  }

  // Valor vem da SyntraPay (em centavos) e tem que bater com o valor que pedimos.
  if (!Number.isFinite(tx.amountCents) || Math.round(tx.amountCents) !== cents) {
    log.error("deposit amount mismatch", identifier, "esperado", cents, "recebido", tx.amountCents);
    await db.audit("deposit_amount_mismatch", dep.user_id, { identifier, expected_cents: cents, got_cents: tx.amountCents });
    return { ok: false, reason: "amount_mismatch" };
  }

  // Idempotente: o ref "syntrapay:<identifier>" impede crédito duplicado no ledger.
  await db.creditDeposit(dep.user_id, cents, identifier);
  await db.markDepositCredited(identifier);
  // Avisa o app na hora (se o jogador estiver conectado). Falha de aviso não desfaz o crédito.
  if (notify) {
    try { notify(dep.user_id, { type: "deposit_status", identifier, status: "credited", cents }); }
    catch (e) { log.error("notify deposit", e && e.message ? e.message : e); }
  }
  return { ok: true, reason: "credited" };
}

// Rede de segurança: pega pagamentos cujo webhook não chegou (ou chegou com erro).
export async function reconcilePending({ db, syncpay, notify = null, olderThanMs = 3 * 60_000, log = console }) {
  if (!syncpay.enabled) return { checked: 0 };
  const cutoff = new Date(Date.now() - olderThanMs).toISOString();
  const rows = await db.pendingDepositsOlderThan(cutoff);
  let credited = 0;
  for (const r of rows) {
    try {
      const res = await confirmDeposit(r.identifier, { db, syncpay, log, notify });
      if (res.reason === "credited") credited++;
    } catch (e) {
      log.error("reconcile", r.identifier, e && e.message ? e.message : e);
    }
  }
  return { checked: rows.length, credited };
}
