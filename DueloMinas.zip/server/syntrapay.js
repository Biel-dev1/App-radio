// Cliente SyntraPay (só no servidor). Docs: https://www.syntrapay.com.br/docs
// A chave de API e o segredo do webhook vêm SÓ de variáveis de ambiente (painel do Botkeep).
import { createHmac, timingSafeEqual, randomUUID } from "node:crypto";

const BASE = (process.env.SYNTRAPAY_BASE_URL || "https://api.syntrapay.com.br").replace(/\/$/, "");

const PAID = new Set(["PAID", "COMPLETED", "APPROVED", "SUCCESS", "SUCCEEDED"]);
const FAILED = new Set(["FAILED", "CANCELED", "CANCELLED", "REJECTED", "REFUSED", "EXPIRED", "ERROR"]);
export const isPaidStatus = (s) => PAID.has(String(s || "").toUpperCase());
export const isFailedStatus = (s) => FAILED.has(String(s || "").toUpperCase());

/** Chave Pix no formato que a SyntraPay detecta sozinha (CPF/CNPJ/telefone só dígitos; telefone com +55). */
export function normalizePixKey(type, key) {
  const k = String(key || "").trim();
  if (type === "email") return k.toLowerCase();
  if (type === "cpf" || type === "cnpj") return k.replace(/\D/g, "");
  if (type === "phone") {
    const d = k.replace(/\D/g, "");
    return d.startsWith("55") && d.length >= 12 ? `+${d}` : `+55${d}`;
  }
  return k; // aleatória (EVP)
}

export function createSyntraPay({
  apiKey = process.env.SYNTRAPAY_API_KEY || "",
  webhookSecret = process.env.SYNTRAPAY_WEBHOOK_SECRET || "",
  fetchImpl = fetch,
} = {}) {
  const enabled = !!apiKey;

  async function call(method, path, body, headers = {}) {
    if (!enabled) throw new Error("SyntraPay não configurada");
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15_000);
    try {
      const r = await fetchImpl(BASE + path, {
        method,
        headers: {
          authorization: apiKey, // sem prefixo Bearer, como manda a documentação
          accept: "application/json",
          ...(body ? { "content-type": "application/json" } : {}),
          ...headers,
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: ctrl.signal,
      });
      const j = await r.json().catch(() => ({}));
      const d = j && typeof j.data === "object" && j.data ? j.data : j;
      return { ok: r.ok, status: r.status, d, raw: j };
    } finally {
      clearTimeout(timer);
    }
  }

  const failure = (r, what) => {
    const msg = (r.raw && (r.raw.message || r.raw.error)) || `${what} ${r.status}`;
    const e = new Error(String(msg).slice(0, 200));
    e.status = r.status;
    // 4xx (menos 408/429) = a SyntraPay recusou de vez; o resto pode ter passado ou pode repetir.
    e.definite = r.status >= 400 && r.status < 500 && r.status !== 408 && r.status !== 429;
    return e;
  };

  /** Cria cobrança Pix. Valores em CENTAVOS. */
  async function cashIn({ amountCents, webhookUrl }) {
    const r = await call("POST", "/transactions",
      { amount: amountCents, ...(webhookUrl ? { webhook: webhookUrl } : {}) },
      { "Idempotency-Key": randomUUID() });
    if (!r.ok) throw failure(r, "cobrança");
    const id = r.d.id || r.d.transactionId || r.d.identifier;
    const pixCode = r.d.copyPaste || r.d.pixCode || r.d.pix_code;
    if (!id || !pixCode) throw new Error("Resposta SyntraPay incompleta");
    return { identifier: String(id), pixCode: String(pixCode) };
  }

  /** Consulta direto no banco da SyntraPay (nocache). null se não existe. */
  async function getTransaction(identifier) {
    const r = await call("GET", `/transactions/${encodeURIComponent(identifier)}?nocache=1`);
    if (r.status === 404) return null;
    if (!r.ok) throw failure(r, "consulta");
    const amount = r.d.amount ?? r.d.amountCents ?? r.d.value;
    return { status: isPaidStatus(r.d.status) ? "completed" : String(r.d.status || "").toLowerCase(), amountCents: Number(amount) };
  }

  /** Saque Pix. A chave de idempotência evita pagar duas vezes se repetirmos o pedido. */
  async function cashOut({ amountCents, pixKey, idempotencyKey }) {
    const r = await call("POST", "/withdrawals", { pixKey, amount: amountCents },
      idempotencyKey ? { "Idempotency-Key": idempotencyKey } : {});
    if (!r.ok) throw failure(r, "saque");
    const id = r.d.id || r.d.withdrawalId || r.d.transactionId;
    if (!id) throw new Error("Resposta de saque incompleta");
    return { id: String(id), status: String(r.d.status || "") };
  }

  async function getWithdrawal(id) {
    const r = await call("GET", `/withdrawals/${encodeURIComponent(id)}`);
    if (r.status === 404) return null;
    if (!r.ok) throw failure(r, "consulta de saque");
    return { status: String(r.d.status || "") };
  }

  /**
   * Confere a assinatura do webhook: HMAC-SHA256 de "<timestamp>.<corpo bruto>" com o signing secret,
   * janela de 300 s contra replay. Sem segredo configurado devolve false (o chamador decide).
   */
  function verifyWebhook(headers, rawBody, nowMs = Date.now()) {
    if (!webhookSecret) return false;
    const sig = String(headers["syntrapay-signature"] || "").replace(/^sha256=/i, "").trim();
    const tsRaw = String(headers["syntrapay-timestamp"] || "").trim();
    if (!sig || !tsRaw) return false;
    let ts = Number(tsRaw);
    if (!Number.isFinite(ts)) ts = Date.parse(tsRaw);
    if (!Number.isFinite(ts)) return false;
    if (ts < 1e11) ts *= 1000; // segundos -> ms
    if (Math.abs(nowMs - ts) > 300_000) return false;
    const want = createHmac("sha256", webhookSecret).update(`${tsRaw}.${rawBody}`).digest();
    let got;
    try { got = Buffer.from(sig, "hex"); } catch { return false; }
    return got.length === want.length && timingSafeEqual(got, want);
  }

  return { enabled, cashIn, getTransaction, cashOut, getWithdrawal, verifyWebhook, hasWebhookSecret: !!webhookSecret };
}
