import { test } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { createSyntraPay, normalizePixKey } from "./syntrapay.js";
import { processWithdrawals, settleWithdrawal } from "./withdrawals.js";

const silent = { error() {}, log() {} };
const sign = (secret, ts, body) => "sha256=" + createHmac("sha256", secret).update(`${ts}.${body}`).digest("hex");

test("webhook: assinatura válida passa; adulterada, velha ou sem segredo não", () => {
  const p = createSyntraPay({ apiKey: "k", webhookSecret: "segredo" });
  const body = '{"event":"payment.approved","data":{"id":"abc"}}';
  const ts = String(Math.floor(Date.now() / 1000));
  assert.equal(p.verifyWebhook({ "syntrapay-signature": sign("segredo", ts, body), "syntrapay-timestamp": ts }, body), true);
  assert.equal(p.verifyWebhook({ "syntrapay-signature": sign("segredo", ts, body), "syntrapay-timestamp": ts }, body + " "), false);
  assert.equal(p.verifyWebhook({ "syntrapay-signature": sign("outro", ts, body), "syntrapay-timestamp": ts }, body), false);
  const old = String(Math.floor(Date.now() / 1000) - 3600);
  assert.equal(p.verifyWebhook({ "syntrapay-signature": sign("segredo", old, body), "syntrapay-timestamp": old }, body), false);
  assert.equal(createSyntraPay({ apiKey: "k" }).verifyWebhook({ "syntrapay-signature": "x", "syntrapay-timestamp": ts }, body), false);
});

test("chave Pix é normalizada", () => {
  assert.equal(normalizePixKey("cpf", "123.456.789-09"), "12345678909");
  assert.equal(normalizePixKey("phone", "(11) 99999-9999"), "+5511999999999");
  assert.equal(normalizePixKey("email", " A@B.com "), "a@b.com");
});

test("cashIn manda centavos, chave sem Bearer e Idempotency-Key", async () => {
  let seen;
  const p = createSyntraPay({ apiKey: "sk_live_x", fetchImpl: async (url, o) => { seen = { url, o }; return { ok: true, status: 200, json: async () => ({ id: "t1", copyPaste: "000201..." }) }; } });
  const r = await p.cashIn({ amountCents: 1490 });
  assert.deepEqual(r, { identifier: "t1", pixCode: "000201..." });
  assert.equal(JSON.parse(seen.o.body).amount, 1490);
  assert.equal(seen.o.headers.authorization, "sk_live_x");
  assert.ok(seen.o.headers["Idempotency-Key"]);
});

function fakeDb(rows) {
  const log = [];
  return {
    log, rows,
    async listPendingWithdrawals() { return rows.filter((w) => w.status === "pending"); },
    async claimWithdrawal(id) { const w = rows.find((x) => x.id === id && x.status === "pending"); if (!w) return false; w.status = "approved"; return true; },
    async listStuckWithdrawals() { return []; },
    async touchWithdrawal() {},
    async setWithdrawalProvider(id, pid) { rows.find((x) => x.id === id).provider_id = pid; log.push(["provider", id, pid]); },
    async setWithdrawalError(id, m) { log.push(["error", id, m]); },
    async cancelWithdrawal(id, r) { rows.find((x) => x.id === id).status = "rejected"; log.push(["cancel", id]); },
    async markWithdrawalPaid(id) { rows.find((x) => x.id === id).status = "paid"; },
    async getWithdrawalByProvider(pid) { return rows.find((x) => x.provider_id === pid) || null; },
    async audit() {}, async alert() {},
  };
}

test("saque: envia uma vez e guarda o id da SyntraPay", async () => {
  const db = fakeDb([{ id: 1, user_id: "u", status: "pending", amount_cents: 2500, pix_type: "cpf", pix_key: "123.456.789-09" }]);
  const calls = [];
  const pay = { enabled: true, async cashOut(a) { calls.push(a); return { id: "w9" }; } };
  await processWithdrawals({ db, pay, log: silent });
  await processWithdrawals({ db, pay, log: silent });
  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0], { amountCents: 2500, pixKey: "12345678909", idempotencyKey: "wd-1" });
  assert.equal(db.rows[0].provider_id, "w9");
});

test("saque: recusa definitiva devolve o saldo; erro incerto NÃO devolve", async () => {
  const mk = (err) => ({ enabled: true, async cashOut() { throw err; } });
  const d1 = fakeDb([{ id: 1, user_id: "u", status: "pending", amount_cents: 2000, pix_type: "random", pix_key: "k" }]);
  await processWithdrawals({ db: d1, pay: mk(Object.assign(new Error("chave inválida"), { definite: true })), log: silent });
  assert.equal(d1.rows[0].status, "rejected");
  const d2 = fakeDb([{ id: 2, user_id: "u", status: "pending", amount_cents: 2000, pix_type: "random", pix_key: "k" }]);
  await processWithdrawals({ db: d2, pay: mk(new Error("timeout")), log: silent });
  assert.equal(d2.rows[0].status, "approved");
});

test("saque: confirma como pago ou devolve conforme a SyntraPay (não o webhook)", async () => {
  const d = fakeDb([{ id: 1, user_id: "u", status: "approved", provider_id: "w1" }, { id: 2, user_id: "u", status: "approved", provider_id: "w2" }]);
  const pay = { async getWithdrawal(id) { return { status: id === "w1" ? "PAID" : "FAILED" }; } };
  assert.equal((await settleWithdrawal("w1", { db: d, pay, log: silent })).reason, "paid");
  assert.equal((await settleWithdrawal("w2", { db: d, pay, log: silent })).reason, "refunded");
  assert.equal((await settleWithdrawal("w1", { db: d, pay, log: silent })).reason, "already");
});
