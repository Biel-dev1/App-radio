import http from "node:http";
import { WebSocketServer } from "ws";
import { createEngine } from "./engine.js";
import { createDb } from "./supabase.js";

const port = process.env.PORT || 8080;
const SUPABASE_URL = process.env.SUPABASE_URL || "";
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY || "";
if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error("Faltam as variáveis SUPABASE_URL e SUPABASE_SERVICE_KEY.");
}

const db = createDb({ url: SUPABASE_URL, key: SUPABASE_SERVICE_KEY });
const engine = createEngine({
  db,
  cfg: {
    feePercent: parseFloat(process.env.FEE_PERCENT || "25"),
    minStakeCents: parseInt(process.env.MIN_STAKE_CENTS || "100", 10),
    maxStakeCents: parseInt(process.env.MAX_STAKE_CENTS || "50000", 10),
    testMode: (process.env.TEST_MODE || "true") === "true",
  },
});

// Ao ligar, devolve qualquer partida que ficou pela metade (servidor reiniciou no meio do jogo).
engine.recover()
  .then((n) => console.log("Partidas pendentes devolvidas:", n))
  .catch((e) => console.error("recover:", e.message));

const server = http.createServer((req, res) => {
  if (req.url === "/health" || req.url === "/") {
    res.writeHead(200, { "content-type": "text/plain; charset=utf-8" });
    return res.end("Duelo de Minas OK");
  }
  res.writeHead(404);
  res.end();
});

const wss = new WebSocketServer({ server, maxPayload: 4096 });

wss.on("connection", (ws) => {
  let uid = null;
  const send = (obj) => { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); };
  const authTimer = setTimeout(() => ws.close(), 10000);   // quem não se identifica em 10s é desconectado
  let queue = Promise.resolve();                           // processa as mensagens de cada jogador em ordem

  ws.on("message", (data) => {
    queue = queue.then(async () => {
      let m;
      try { m = JSON.parse(data.toString()); } catch { return; }
      if (!uid) {
        if (m.type !== "auth" || typeof m.token !== "string") return;
        const id = await db.userFromToken(m.token).catch(() => null);
        if (!id) { send({ type: "error", message: "Sessão inválida. Entre de novo." }); return ws.close(); }
        const ok = await engine.connect(id, send);
        if (!ok) return ws.close();
        uid = id;
        clearTimeout(authTimer);
        return;
      }
      await engine.message(uid, m);
    }).catch((e) => console.error("ws:", e));
  });

  ws.on("close", () => {
    clearTimeout(authTimer);
    if (uid) engine.disconnect(uid, send);
  });
  ws.on("error", () => {});
});

server.listen(port, () => console.log("Duelo de Minas server na porta", port));
