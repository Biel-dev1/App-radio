import http from "node:http";
import { WebSocketServer } from "ws";
import { createEngine } from "./engine.js";
import { createDb } from "./supabase.js";

const port = process.env.PORT || 8080;
const SUPABASE_URL = process.env.SUPABASE_URL || "";
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY || "";
if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  // Melhor cair com erro claro no log do Render do que subir "meio quebrado" e recusar todo login.
  console.error("ERRO: faltam as variáveis SUPABASE_URL e SUPABASE_SERVICE_KEY. Configure em Environment no Render.");
  process.exit(1);
}
if ((process.env.TEST_MODE || "true") === "true") {
  console.warn("ATENÇÃO: TEST_MODE ligado (saldo de teste liberado). Para dinheiro real, defina TEST_MODE=false.");
}

// ---- limites de proteção (ajustáveis por variável de ambiente)
const MAX_CONN_PER_IP = parseInt(process.env.MAX_CONN_PER_IP || "8", 10);
const MAX_CONN_TOTAL = parseInt(process.env.MAX_CONN_TOTAL || "2000", 10);
const MSG_BURST = 30;          // mensagens que cabem de uma vez
const MSG_PER_SEC = 10;        // reposição por segundo
const AUTH_FAIL_LIMIT = 8;     // falhas de login por IP...
const AUTH_FAIL_WINDOW_MS = 60_000; // ...a cada minuto

const connsByIp = new Map();
const authFails = new Map();
let totalConns = 0;

function clientIp(req) {
  const xff = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return xff || req.socket.remoteAddress || "?";
}
function tooManyAuthFails(ip) {
  const now = Date.now();
  const a = authFails.get(ip);
  return !!a && now - a.t < AUTH_FAIL_WINDOW_MS && a.n >= AUTH_FAIL_LIMIT;
}
function noteAuthFail(ip) {
  const now = Date.now();
  const a = authFails.get(ip);
  if (!a || now - a.t >= AUTH_FAIL_WINDOW_MS) authFails.set(ip, { t: now, n: 1 });
  else a.n++;
}
setInterval(() => {   // limpa a memória dos contadores
  const now = Date.now();
  for (const [ip, a] of authFails) if (now - a.t >= AUTH_FAIL_WINDOW_MS) authFails.delete(ip);
}, 60_000).unref();

const db = createDb({ url: SUPABASE_URL, key: SUPABASE_SERVICE_KEY });
const engine = createEngine({
  db,
  cfg: {
    feePercent: parseFloat(process.env.FEE_PERCENT || "25"),
    minStakeCents: parseInt(process.env.MIN_STAKE_CENTS || "100", 10),
    maxStakeCents: parseInt(process.env.MAX_STAKE_CENTS || "50000", 10),
    testMode: (process.env.TEST_MODE || "true") === "true",
  },
});

// Ao ligar, devolve qualquer partida que ficou pela metade (servidor reiniciou no meio do jogo).
engine.recover()
  .then((n) => console.log("Partidas pendentes devolvidas:", n))
  .catch((e) => console.error("recover:", e.message));

const SEC_HEADERS = {
  "x-content-type-options": "nosniff",
  "x-frame-options": "DENY",
  "referrer-policy": "no-referrer",
  "cache-control": "no-store",
};

const server = http.createServer((req, res) => {
  if ((req.method === "GET" || req.method === "HEAD") && (req.url === "/health" || req.url === "/")) {
    res.writeHead(200, { ...SEC_HEADERS, "content-type": "text/plain; charset=utf-8" });
    return res.end(req.method === "HEAD" ? undefined : "Duelo de Minas OK");
  }
  res.writeHead(404, SEC_HEADERS);
  res.end();
});
server.headersTimeout = 15_000;
server.requestTimeout = 15_000;

const wss = new WebSocketServer({
  server,
  maxPayload: 4096,
  // O app Android não manda "Origin". Quem manda é navegador: bloqueia páginas web usando o servidor.
  verifyClient: ({ req }) => !req.headers.origin && totalConns < MAX_CONN_TOTAL,
});

wss.on("connection", (ws, req) => {
  const ip = clientIp(req);
  const mine = (connsByIp.get(ip) || 0) + 1;
  if (mine > MAX_CONN_PER_IP || tooManyAuthFails(ip)) { ws.close(1008, "limite"); return; }
  connsByIp.set(ip, mine);
  totalConns++;

  // pings: derruba conexões "fantasma" (celular sem sinal) para não acumular
  ws.isAlive = true;
  ws.on("pong", () => { ws.isAlive = true; });

  // balde de mensagens: quem inunda o servidor é desconectado
  let tokens = MSG_BURST;
  let lastRefill = Date.now();
  const allow = () => {
    const now = Date.now();
    tokens = Math.min(MSG_BURST, tokens + ((now - lastRefill) / 1000) * MSG_PER_SEC);
    lastRefill = now;
    if (tokens < 1) return false;
    tokens -= 1;
    return true;
  };

  let uid = null;
  const send = (obj) => { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); };
  const authTimer = setTimeout(() => ws.close(), 10000);   // quem não se identifica em 10s é desconectado
  let queue = Promise.resolve();                           // processa as mensagens de cada jogador em ordem

  ws.on("message", (data) => {
    if (!allow()) { ws.close(1008, "devagar"); return; }
    queue = queue.then(async () => {
      let m;
      try { m = JSON.parse(data.toString()); } catch { return; }
      if (!m || typeof m !== "object") return;
      if (!uid) {
        if (m.type !== "auth" || typeof m.token !== "string" || m.token.length > 4000) return;
        const id = await db.userFromToken(m.token).catch(() => null);
        if (!id) { noteAuthFail(ip); send({ type: "error", message: "Sessão inválida. Entre de novo." }); return ws.close(); }
        const ok = await engine.connect(id, send);
        if (!ok) return ws.close();
        uid = id;
        clearTimeout(authTimer);
        return;
      }
      await engine.message(uid, m);
    }).catch((e) => console.error("ws:", e));
  });

  ws.on("close", () => {
    clearTimeout(authTimer);
    totalConns = Math.max(0, totalConns - 1);
    const left = (connsByIp.get(ip) || 1) - 1;
    if (left <= 0) connsByIp.delete(ip); else connsByIp.set(ip, left);
    if (uid) engine.disconnect(uid, send);
  });
  ws.on("error", () => {});
});

const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive = false;
    try { ws.ping(); } catch { /* ignore */ }
  }
}, 30_000);
heartbeat.unref();

process.on("unhandledRejection", (e) => console.error("unhandledRejection:", e && e.message ? e.message : e));
process.on("uncaughtException", (e) => console.error("uncaughtException:", e && e.message ? e.message : e));
process.on("SIGTERM", () => {   // Render avisa antes de reiniciar: fecha direito
  console.log("SIGTERM: encerrando…");
  for (const ws of wss.clients) { try { ws.close(1001, "reiniciando"); } catch { /* ignore */ } }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 5000).unref();
});

server.listen(port, () => console.log("Duelo de Minas server na porta", port));
