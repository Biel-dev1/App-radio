import http from "node:http";
import { randomUUID } from "node:crypto";
import { WebSocketServer } from "ws";
import { createEngine } from "./engine.js";
import { createDb } from "./supabase.js";
import { createSyncPay } from "./syncpay.js";
import { confirmDeposit, reconcilePending } from "./deposits.js";

const port = process.env.PORT || 8080;
const SUPABASE_URL = process.env.SUPABASE_URL || "";
const SUPABASE_SERVICE_KEY =
  process.env.SUPABASE_SERVICE_KEY ||
  process.env.SUPABASE_SERVICE_ROLE ||
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  "";
if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error("ERRO: faltam SUPABASE_URL e SUPABASE_SERVICE_KEY (ou SUPABASE_SERVICE_ROLE) no Environment do Render.");
  process.exit(1);
}

// ---- limites de proteção (ajustáveis por variável de ambiente)
const MAX_CONN_PER_IP = parseInt(process.env.MAX_CONN_PER_IP || "8", 10);
const MAX_CONN_TOTAL = parseInt(process.env.MAX_CONN_TOTAL || "2000", 10);
const MSG_BURST = 30;          // mensagens que cabem de uma vez
const MSG_PER_SEC = 10;        // reposição por segundo
const AUTH_FAIL_LIMIT = 8;     // falhas de login por IP...
const AUTH_FAIL_WINDOW_MS = 60_000; // ...a cada minuto

const connsByIp = new Map();
const authFails = new Map();
let totalConns = 0;

function clientIp(req) {
  // O proxy do Render acrescenta o IP observado ao FIM do XFF. O primeiro pode
  // ter sido escolhido pelo cliente; usar o último evita que ele escolha a chave do rate-limit.
  const parts = String(req.headers["x-forwarded-for"] || "").split(",").map((x) => x.trim()).filter(Boolean);
  const xff = parts.at(-1);
  return xff || req.socket.remoteAddress || "?";
}
function tooManyAuthFails(ip) {
  const now = Date.now();
  const a = authFails.get(ip);
  return !!a && now - a.t < AUTH_FAIL_WINDOW_MS && a.n >= AUTH_FAIL_LIMIT;
}
function noteAuthFail(ip) {
  const now = Date.now();
  const a = authFails.get(ip);
  if (!a || now - a.t >= AUTH_FAIL_WINDOW_MS) authFails.set(ip, { t: now, n: 1 });
  else a.n++;
}
setInterval(() => {   // limpa a memória dos contadores
  const now = Date.now();
  for (const [ip, a] of authFails) if (now - a.t >= AUTH_FAIL_WINDOW_MS) authFails.delete(ip);
}, 60_000).unref();

const db = createDb({ url: SUPABASE_URL, key: SUPABASE_SERVICE_KEY });
const syncpay = createSyncPay();
const PUBLIC_BASE = (process.env.PUBLIC_BASE_URL || "").replace(/\/$/, "") ||
  (process.env.RENDER_EXTERNAL_URL || "").replace(/\/$/, "");

async function createPixDeposit({ uid, cents, cpf, name, email }) {
  const amountReais = Math.round(cents) / 100;
  const webhookUrl = PUBLIC_BASE
    ? `${PUBLIC_BASE}/webhooks/syncpay`
    : undefined;
  const { pixCode, identifier } = await syncpay.cashIn({
    amountReais,
    description: `Deposito Duelo de Minas ${uid.slice(0, 8)}`,
    webhookUrl,
    client: { name, cpf, email, phone: "11999999999" },
  });
  // Grava no banco (não na memória): sobrevive a reinício do Render.
  await db.createDeposit(identifier, uid, cents);
  return { pixCode, identifier };
}

// Rede de segurança: a cada 2 min confere depósitos pendentes direto na SyncPay.
if (syncpay.enabled) {
  setInterval(() => {
    reconcilePending({ db, syncpay })
      .then((r) => { if (r.credited) console.log("reconcile: creditados", r.credited); })
      .catch((e) => console.error("reconcile:", e && e.message ? e.message : e));
  }, 120_000).unref();
}

const engine = createEngine({
  db,
  cfg: {
    feePercent: parseFloat(process.env.FEE_PERCENT || "25"),
    minStakeCents: parseInt(process.env.MIN_STAKE_CENTS || "100", 10),
    maxStakeCents: parseInt(process.env.MAX_STAKE_CENTS || "50000", 10),
    pairPerHour: parseInt(process.env.PAIR_PER_HOUR || "12", 10),
    depositsEnabled: syncpay.enabled,
    createPixDeposit: syncpay.enabled ? createPixDeposit : null,
    instanceId: process.env.INSTANCE_ID || randomUUID(),
  },
});

// Ao ligar, devolve qualquer partida que ficou pela metade (servidor reiniciou no meio do jogo).
engine.recover()
  .then((n) => console.log("Partidas pendentes devolvidas:", n))
  .catch((e) => console.error("recover:", e.message));

const SEC_HEADERS = {
  "x-content-type-options": "nosniff",
  "x-frame-options": "DENY",
  "referrer-policy": "no-referrer",
  "cache-control": "no-store",
};

function readBody(req, limit = 64_000) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > limit) {
        reject(new Error("body too large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function pickStatus(body) {
  const s = String(
    body.status ||
    body?.data?.status ||
    body?.transaction?.status ||
    ""
  ).toLowerCase();
  return s;
}

function pickId(body) {
  return String(
    body.identifier ||
    body.id ||
    body?.data?.id ||
    body?.data?.identifier ||
    body?.transaction?.id ||
    ""
  );
}

function pickAmountCents(body, fallback) {
  const raw =
    body.amount ??
    body.final_amount ??
    body?.data?.amount ??
    body?.data?.final_amount;
  if (raw == null || raw === "") return fallback;
  const n = Number(raw);
  if (!Number.isFinite(n)) return fallback;
  // SyncPay docs: valores em reais. Se vier inteiro grande, assume centavos.
  if (Number.isInteger(n) && n >= 1000 && !String(raw).includes(".")) return n;
  return Math.round(n * 100);
}

const PAID = new Set(["completed", "paid", "approved", "confirmed", "success", "succeeded"]);

const server = http.createServer(async (req, res) => {
  const path = (req.url || "").split("?")[0];
  if ((req.method === "GET" || req.method === "HEAD") && (path === "/health" || path === "/")) {
    res.writeHead(200, { ...SEC_HEADERS, "content-type": "text/plain; charset=utf-8" });
    return res.end(req.method === "HEAD" ? undefined : "Duelo de Minas OK");
  }

  if (req.method === "POST" && path === "/webhooks/syncpay") {
    try {
      if (!syncpay.verifyWebhookAuth(req)) {
        res.writeHead(401, SEC_HEADERS);
        return res.end("unauthorized");
      }
      const raw = await readBody(req);
      let body = {};
      try { body = raw ? JSON.parse(raw) : {}; } catch { body = {}; }
      // formato legado: { event, data }
      const data = body.data && typeof body.data === "object" ? { ...body, ...body.data } : body;
      const identifier = pickId(data);
      console.log("syncpay webhook", identifier || "(sem id)");

      // O corpo do webhook é só um aviso. Status e valor são conferidos na SyncPay
      // dentro de confirmDeposit: nunca creditamos com base no que chegou aqui.
      if (identifier) {
        try {
          const r = await confirmDeposit(identifier, { db, syncpay });
          console.log("deposit", identifier, r.reason);
        } catch (e) {
          console.error("confirmDeposit:", e && e.message ? e.message : e);
          // 500 faz a SyncPay tentar de novo; o crédito é idempotente.
          res.writeHead(500, SEC_HEADERS);
          return res.end("error");
        }
      }
      res.writeHead(200, SEC_HEADERS);
      return res.end("ok");
    } catch (e) {
      console.error("webhook:", e && e.message ? e.message : e);
      res.writeHead(400, SEC_HEADERS);
      return res.end("bad");
    }
  }

  res.writeHead(404, SEC_HEADERS);
  res.end();
});
server.headersTimeout = 15_000;
server.requestTimeout = 15_000;

const wss = new WebSocketServer({
  server,
  maxPayload: 4096,
  // O app Android não manda "Origin". Quem manda é navegador: bloqueia páginas web usando o servidor.
  verifyClient: ({ req }) => !req.headers.origin && totalConns < MAX_CONN_TOTAL,
});

wss.on("connection", (ws, req) => {
  const ip = clientIp(req);
  const mine = (connsByIp.get(ip) || 0) + 1;
  if (mine > MAX_CONN_PER_IP || tooManyAuthFails(ip)) { ws.close(1008, "limite"); return; }
  connsByIp.set(ip, mine);
  totalConns++;

  // pings: derruba conexões "fantasma" (celular sem sinal) para não acumular
  ws.isAlive = true;
  ws.on("pong", () => { ws.isAlive = true; });

  // balde de mensagens: quem inunda o servidor é desconectado
  let tokens = MSG_BURST;
  let lastRefill = Date.now();
  const allow = () => {
    const now = Date.now();
    tokens = Math.min(MSG_BURST, tokens + ((now - lastRefill) / 1000) * MSG_PER_SEC);
    lastRefill = now;
    if (tokens < 1) return false;
    tokens -= 1;
    return true;
  };

  let uid = null;
  const send = (obj) => { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); };
  const authTimer = setTimeout(() => ws.close(), 10000);   // quem não se identifica em 10s é desconectado
  let queue = Promise.resolve();                           // processa as mensagens de cada jogador em ordem

  ws.on("message", (data) => {
    if (!allow()) { ws.close(1008, "devagar"); return; }
    queue = queue.then(async () => {
      let m;
      try { m = JSON.parse(data.toString()); } catch { return; }
      if (!m || typeof m !== "object") return;
      if (!uid) {
        if (m.type !== "auth" || typeof m.token !== "string" || m.token.length > 4000) return;
        const user = await db.userFromToken(m.token).catch(() => null);
        if (!user || !user.id) { noteAuthFail(ip); send({ type: "error", message: "Sessão inválida. Entre de novo." }); return ws.close(); }
        const ok = await engine.connect(user.id, send);
        if (!ok) return ws.close();
        // e-mail para a SyncPay (cash-in)
        try { engine.setSessionEmail?.(user.id, user.email || ""); } catch (_) {}
        uid = user.id;
        clearTimeout(authTimer);
        return;
      }
      await engine.message(uid, m);
    }).catch((e) => console.error("ws:", e));
  });

  ws.on("close", () => {
    clearTimeout(authTimer);
    totalConns = Math.max(0, totalConns - 1);
    const left = (connsByIp.get(ip) || 1) - 1;
    if (left <= 0) connsByIp.delete(ip); else connsByIp.set(ip, left);
    if (uid) engine.disconnect(uid, send);
  });
  ws.on("error", () => {});
});

const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive = false;
    try { ws.ping(); } catch { /* ignore */ }
  }
}, 30_000);
heartbeat.unref();

process.on("unhandledRejection", (e) => console.error("unhandledRejection:", e && e.message ? e.message : e));
process.on("uncaughtException", (e) => console.error("uncaughtException:", e && e.message ? e.message : e));
process.on("SIGTERM", () => {   // Render avisa antes de reiniciar: fecha direito
  console.log("SIGTERM: encerrando…");
  for (const ws of wss.clients) { try { ws.close(1001, "reiniciando"); } catch { /* ignore */ } }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 5000).unref();
});

server.listen(port, () => {
  console.log("Duelo de Minas server na porta", port);
  console.log("SyncPay depósitos:", syncpay.enabled ? "LIGADO" : "desligado (faltam SYNCPAY_CLIENT_ID/SECRET)");
});
