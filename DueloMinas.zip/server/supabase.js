// Conversa com o Supabase usando a chave SECRETA (fica só no servidor, nunca no app).
export function createDb({ url, key }) {
  const base = url.replace(/\/$/, "");
  const headers = (extra = {}) => ({
    apikey: key,
    ...(key.startsWith("eyJ") ? { Authorization: `Bearer ${key}` } : {}),
    "content-type": "application/json",
    ...extra,
  });

  async function rest(method, path, body, extra) {
    const r = await fetch(base + path, {
      method,
      headers: headers(extra),
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await r.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* resposta vazia */ }
    if (!r.ok) {
      const e = new Error((json && (json.message || json.error)) || `Supabase ${r.status}`);
      // mensagens que escrevemos no banco (raise exception) são seguras de mostrar ao jogador
      if (json && json.code === "P0001") e.userMessage = json.message;
      throw e;
    }
    return json;
  }

  return {
    async userFromToken(token) {
      const r = await fetch(base + "/auth/v1/user", {
        headers: { apikey: key, Authorization: `Bearer ${token}` },
      });
      if (!r.ok) return null;
      const u = await r.json();
      return u && u.id ? u.id : null;
    },
    async profile(uid) {
      const rows = await rest("GET",
        `/rest/v1/profiles?select=id,display_name,avatar_url,balance_cents,profile_done,terms_version&id=eq.${encodeURIComponent(uid)}`);
      return rows && rows[0] ? rows[0] : null;
    },
    async createMatch(roomCode, p1, p2, stake, fee) {
      const rows = await rest("POST", "/rest/v1/matches",
        { room_code: roomCode, p1, p2, stake_cents: stake, fee_cents: fee },
        { Prefer: "return=representation" });
      return rows[0].id;
    },
    payMatch: (matchId, uid) => rest("POST", "/rest/v1/rpc/pay_match", { p_match: matchId, p_user: uid }),
    finishMatch: (matchId, winner) => rest("POST", "/rest/v1/rpc/finish_match", { p_match: matchId, p_winner: winner }),
    refundMatch: (matchId) => rest("POST", "/rest/v1/rpc/refund_match", { p_match: matchId }),
    recover: () => rest("POST", "/rest/v1/rpc/recover_matches", {}),
  };
}
