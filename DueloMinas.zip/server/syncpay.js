// Cliente SyncPay (só no servidor). Docs: https://syncpay.apidog.io/
const BASE = "https://api.syncpayments.com.br/api/partner/v1";

export function createSyncPay({
  clientId = process.env.SYNCPAY_CLIENT_ID || "",
  clientSecret = process.env.SYNCPAY_CLIENT_SECRET || "",
  webhookSecret = process.env.SYNCPAY_WEBHOOK_SECRET || "",
} = {}) {
  let cached = { token: "", exp: 0 };

  const enabled = !!(clientId && clientSecret);

  async function authToken() {
    if (!enabled) throw new Error("SyncPay não configurada");
    const now = Date.now();
    if (cached.token && now < cached.exp - 60_000) return cached.token;
    const r = await fetch(`${BASE}/auth-token`, {
      method: "POST",
      headers: { "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify({ client_id: clientId, client_secret: clientSecret }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.access_token) {
      const msg = j.error_description || j.error || `auth ${r.status}`;
      throw new Error(msg);
    }
    cached = {
      token: j.access_token,
      exp: now + (Number(j.expires_in) || 3600) * 1000,
    };
    return cached.token;
  }

  async function cashIn({ amountReais, description, webhookUrl, client }) {
    const token = await authToken();
    const r = await fetch(`${BASE}/cash-in`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${token}`,
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        amount: amountReais,
        description: description || "Deposito Duelo de Minas",
        webhook_url: webhookUrl || undefined,
        client: {
          name: client.name || "Jogador",
          cpf: client.cpf || "00000000000",
          email: client.email || "jogador@duelominas.app",
          phone: client.phone || "11999999999",
        },
      }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) {
      const msg = j.message || j.error_description || j.error || `cash-in ${r.status}`;
      const e = new Error(msg);
      e.status = r.status;
      throw e;
    }
    if (!j.pix_code || !j.identifier) throw new Error("Resposta SyncPay incompleta");
    return { pixCode: j.pix_code, identifier: String(j.identifier) };
  }

  /**
   * Consulta uma transação na SyncPay (GET /transaction/{identifier}).
   * Usado para confirmar pagamento sem confiar no corpo do webhook.
   * Retorna null se a transação não existir.
   */
  async function getTransaction(identifier) {
    const token = await authToken();
    const r = await fetch(`${BASE}/transaction/${encodeURIComponent(identifier)}`, {
      headers: { authorization: `Bearer ${token}`, accept: "application/json" },
    });
    if (r.status === 401) cached = { token: "", exp: 0 }; // token expirou: força novo login na próxima
    if (r.status === 404) return null;
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`transaction ${r.status}`);
    const d = j.data || {};
    return {
      status: String(d.status || "").toLowerCase(),
      amountReais: Number(d.amount),
    };
  }

  /** Valida token do painel se configurado (Authorization: Bearer <secret>). */
  function verifyWebhookAuth(req) {
    if (!webhookSecret) return true; // ainda não configurado: aceita (logar)
    const h = String(req.headers.authorization || "");
    const m = /^Bearer\s+(.+)$/i.exec(h);
    if (m && m[1] === webhookSecret) return true;
    // alguns painéis mandam o token em header próprio
    if (req.headers["x-webhook-token"] === webhookSecret) return true;
    return false;
  }

  return { enabled, cashIn, getTransaction, verifyWebhookAuth, webhookSecret: !!webhookSecret };
}
