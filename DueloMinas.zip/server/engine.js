// Regras do jogo: salas, pagamento, minas secretas e turnos.
// Não conhece rede nem banco: tudo entra por `db` e `send`, o que permite testar sem internet.
import { randomInt } from "node:crypto";

export const CELLS = 25;       // tabuleiro 5x5
export const MAX_MINES = 10;

export const DEFAULT_CFG = {
  feePercent: 25,        // taxa por jogador, em % do valor da sala (R$ 2,00 -> R$ 0,50)
  minStakeCents: 100,    // mínimo R$ 1,00
  maxStakeCents: 50000,  // máximo R$ 500,00
  minDepositCents: 1000, // depósito mínimo R$ 10,00
  maxDepositCents: 500000, // depósito máximo R$ 5.000,00 por pedido
  depositsEnabled: false, // true se SyncPay estiver configurada no servidor
  turnMs: 30000,         // tempo para jogar
  animMs: 3500,          // tempo da animação do sorteio
  placeMs: 90000,        // tempo para posicionar minas
  checkoutMs: 120000,    // tempo para pagar
  graceMs: 45000,        // tempo para reconectar antes de perder por abandono
  actionWindowMs: 60_000,
  createPerWindow: 5,
  joinPerWindow: 12,
  payPerWindow: 6,
  pairPerHour: 12,
  instanceId: "",
};

const CODE_RE = /^[A-Z0-9-]{4,20}$/;

// Mensagens para os códigos devolvidos pelas funções de PIN/saque no banco.
const PIN_MSG = {
  wrong: "Senha de 6 dígitos incorreta.",
  locked: "Senha bloqueada por excesso de tentativas. Tente de novo mais tarde.",
  not_set: "Você ainda não cadastrou sua senha de 6 dígitos.",
  invalid: "A senha precisa ter 6 números.",
  min: "O saque mínimo é R$ 20,00.",
  pix_type: "Tipo de chave Pix inválido.",
  pix_key: "Chave Pix inválida.",
  pending: "Você já tem um saque em andamento.",
  insufficient: "Saldo insuficiente para saque.",
};

export function createEngine({ db, cfg: userCfg = {}, now = () => Date.now() }) {
  const cfg = { ...DEFAULT_CFG, ...userCfg };
  const sessions = new Map(); // userId -> { id, name, avatar, send, room, dc }
  const rooms = new Map();    // code -> room
  const actions = new Map();  // uid:action -> timestamps; evita custo de banco por spam
  const pairPlays = new Map(); // "a|b" -> timestamps (última 1h) — limite de conluio
  const matchmakingQueue = []; // { uid, stake, mines, queuedAt }
  let roomSeq = 0;

  const cleanName = (value, max = 24) => String(value || "")
    .normalize("NFKC")
    .replace(/[\u0000-\u001F\u007F-\u009F\u200B-\u200F\u202A-\u202E\u2066-\u2069]/g, "")
    // Só caracteres que *imitam* letras latinas (cirílico/grego), sem tocar no alfabeto normal
    .replace(/\u041E|\u043E|\u039F/g, "O")   // О о Ο
    .replace(/\u0406|\u0456|\u0399/g, "I")   // І і Ι
    .replace(/\u0410|\u0430|\u0391/g, "A")   // А а Α
    .replace(/\u0415|\u0435|\u0395/g, "E")   // Е е Ε
    .replace(/\u0405|\u0455/g, "S")           // Ѕ ѕ
    .replace(/\u0412|\u0432|\u0392/g, "B")   // В в Β
    .replace(/\s+/g, " ").trim().slice(0, max);

  const pairKey = (a, b) => [a, b].sort().join("|");
  const pairTooMany = (a, b) => {
    const key = pairKey(a, b);
    const cut = now() - 3_600_000;
    const arr = (pairPlays.get(key) || []).filter((t) => t > cut);
    pairPlays.set(key, arr);
    return arr.length >= cfg.pairPerHour;
  };
  const notePair = (a, b) => {
    const key = pairKey(a, b);
    const cut = now() - 3_600_000;
    const arr = (pairPlays.get(key) || []).filter((t) => t > cut);
    arr.push(now());
    pairPlays.set(key, arr);
  };
  const allowed = (uid, action, max, window = cfg.actionWindowMs) => {
    const key = `${uid}:${action}`, cut = now() - window;
    const a = (actions.get(key) || []).filter((t) => t > cut);
    if (a.length >= max) return false;
    a.push(now()); actions.set(key, a); return true;
  };

  const feeOf = (stake) => Math.round((stake * cfg.feePercent) / 100);
  const other = (room, uid) => room.players.find((p) => p !== uid) || null;
  const roomOf = (uid) => {
    const s = sessions.get(uid);
    return s && s.room ? rooms.get(s.room) || null : null;
  };
  const sendTo = (uid, msg) => {
    const s = sessions.get(uid);
    if (s && s.send) {
      try { s.send(msg); } catch { /* conexão caiu */ }
    }
  };
  const err = (uid, message) => sendTo(uid, { type: "error", message });
  const money = (c) => "R$ " + (c / 100).toFixed(2).replace(".", ",");

  function setTimer(room, ms, fn) {
    clearTimeout(room.timer);
    room.timer = setTimeout(() => {
      Promise.resolve(fn()).catch((e) => console.error("timer:", e));
    }, ms);
  }

  // ---------------------------------------------------------------- estado enviado a cada jogador
  function stateFor(room, uid) {
    const opp = other(room, uid);
    const over = room.status === "over" && room.result;
    return {
      type: "state",
      room: {
        id: room.id,
        code: room.code,
        name: room.name,
        isPublic: room.isPublic,
        stakeCents: room.stake,
        feeCents: room.fee,
        mines: room.mines,
        status: room.status,
        you: uid,
        creator: room.creatorId,
        players: room.players.map((p) => {
          const s = sessions.get(p);
          return {
            id: p,
            name: s ? s.name : "Jogador",
            avatar: s ? s.avatar : "",
            verified: !!(s && s.verified),
            confirmed: !!room.confirmed[p],
            paid: !!room.paid[p],
            placed: !!room.placed[p],
            online: !!(s && s.send),
          };
        }),
        turn: room.turn,
        first: room.first,
        startedAt: room.startedAt,
        deadline: room.deadline,
        serverNow: now(),
        myMines: [...(room.boards[uid] || [])],               // só eu vejo as minhas
        hitsOnMe: [...(room.hits[uid] || [])],                // casas que o adversário abriu no meu tabuleiro
        myPicks: opp ? [...(room.hits[opp] || [])] : [],      // casas que eu abri no tabuleiro dele
        opponentLeft: room.players.length < 2 && room.status !== "waiting",
        result: over
          ? {
              winner: room.result.winner,
              youWon: room.result.winner === uid,
              reason: room.result.reason,
              prizeCents: room.stake * 2,
              oppMines: opp ? [...(room.boards[opp] || [])] : [],   // só revelado no fim
            }
          : null,
        rematch: { you: !!room.rematch[uid], opp: !!(opp && room.rematch[opp]) },
      },
    };
  }

  function broadcast(room) {
    for (const p of room.players) sendTo(p, stateFor(room, p));
  }

  // ---------------------------------------------------------------- fechar / sair
  function closeRoom(room, message) {
    clearTimeout(room.timer);
    rooms.delete(room.code);
    for (const p of room.players) {
      const s = sessions.get(p);
      if (s) {
        s.room = null;
        clearTimeout(s.dc);
      }
      sendTo(p, { type: "room_closed", message: message || "Sala fechada." });
      dropIfIdle(p);
    }
    room.players = [];
  }

  function dropIfIdle(uid) {
    const s = sessions.get(uid);
    if (s && !s.send && !s.room) sessions.delete(uid);
  }

  async function cancelWithRefund(room, message) {
    const matchId = room.matchId;
    room.matchId = null;
    if (matchId) {
      try { await db.refundMatch(matchId); } catch (e) { console.error("refund:", e.message); }
    }
    closeRoom(room, message);
  }

  function detach(room, uid) {
    room.players = room.players.filter((p) => p !== uid);
    const s = sessions.get(uid);
    if (s) {
      s.room = null;
      clearTimeout(s.dc);
    }
    sendTo(uid, { type: "left" });
    dropIfIdle(uid);
    if (room.players.length === 0) {
      clearTimeout(room.timer);
      rooms.delete(room.code);
    } else {
      room.rematch = {};
      broadcast(room);
    }
  }

  async function leave(uid) {
    removeFromQueue(uid);
    const room = roomOf(uid);
    if (!room) return sendTo(uid, { type: "left" });
    switch (room.status) {
      case "waiting":
        closeRoom(room, "Sala fechada.");
        break;
      case "lobby":
        if (uid === room.creatorId) {
          closeRoom(room, "O criador fechou a sala.");
        } else {
          room.players = room.players.filter((p) => p !== uid);
          room.confirmed = {};
          room.status = "waiting";
          const s = sessions.get(uid);
          if (s) s.room = null;
          sendTo(uid, { type: "left" });
          dropIfIdle(uid);
          broadcast(room);
        }
        break;
      case "checkout":
      case "placing":
        await cancelWithRefund(room, "Partida cancelada. Os valores pagos foram devolvidos.");
        break;
      case "playing":
        await finish(room, other(room, uid), "abandono");
        detach(room, uid);
        break;
      default:
        detach(room, uid);
    }
  }

  // ---------------------------------------------------------------- fluxo da partida
  async function newMatch(room) {
    const p1 = room.players[0], p2 = room.players[1];
    if (pairTooMany(p1, p2)) {
      const msg = "Vocês jogaram demais juntos nesta hora. Aguarde um pouco.";
      for (const p of room.players) err(p, msg);
      throw Object.assign(new Error("pair_limit"), { userMessage: msg });
    }
    room.matchId = await db.createMatch(room.code, p1, p2, room.stake, room.fee);
    room.status = "checkout";
    room.paid = {};
    room.placed = {};
    room.boards = {};
    room.hits = {};
    room.turn = null;
    room.first = null;
    room.result = null;
    room.rematch = {};
    room.confirmed = { [p1]: true, [p2]: true };
    notePair(p1, p2);
    if (db.touchMatch && cfg.instanceId) await db.touchMatch(room.matchId, cfg.instanceId);
    try { await db.flagMatch?.(room.matchId, "pair_seen", { p1, p2 }); } catch (e) { console.error("pair audit:", e.message); }
    setTimer(room, cfg.checkoutMs, () => cancelWithRefund(room, "Tempo de pagamento esgotado. Os valores pagos foram devolvidos."));
    broadcast(room);
  }

  function randomMines(n) {
    const set = new Set();
    while (set.size < n) set.add(randomInt(CELLS));
    return set;
  }

  function startPlacing(room) {
    room.status = "placing";
    room.deadline = now() + cfg.placeMs;
    setTimer(room, cfg.placeMs, () => {
      if (room.status !== "placing") return;
      for (const p of room.players) {
        if (!room.placed[p]) {
          room.boards[p] = randomMines(room.mines);
          room.placed[p] = true;
        }
      }
      startGame(room);
    });
    broadcast(room);
  }

  function startGame(room) {
    room.status = "playing";
    room.first = room.players[randomInt(2)];
    room.turn = room.first;
    room.startedAt = now();
    room.deadline = now() + cfg.animMs + cfg.turnMs;
    room.hits = { [room.players[0]]: new Set(), [room.players[1]]: new Set() };
    setTimer(room, cfg.animMs + cfg.turnMs, () => onTurnTimeout(room));
    broadcast(room);
  }

  async function onTurnTimeout(room) {
    if (room.status !== "playing") return;
    const uid = room.turn;
    const opp = other(room, uid);
    const free = [];
    for (let i = 0; i < CELLS; i++) if (!room.hits[opp].has(i)) free.push(i);
    if (free.length === 0) return finish(room, opp, "tempo");
    await pick(uid, free[randomInt(free.length)], true);
  }

  async function pick(uid, cell, auto = false) {
    const room = roomOf(uid);
    if (!room || room.status !== "playing") return;
    if (room.turn !== uid) return err(uid, "Ainda não é a sua vez.");
    if (!Number.isInteger(cell) || cell < 0 || cell >= CELLS) return;
    const opp = other(room, uid);
    if (room.hits[opp].has(cell)) return err(uid, "Essa casa já foi aberta.");
    if (!auto && now() < room.startedAt + cfg.animMs - 200) return; // ainda no sorteio
    room.hits[opp].add(cell);
    if (room.boards[opp].has(cell)) {
      await finish(room, opp, "mina");
    } else {
      room.turn = opp;
      room.deadline = now() + cfg.turnMs;
      setTimer(room, cfg.turnMs, () => onTurnTimeout(room));
      broadcast(room);
    }
  }

  async function finish(room, winner, reason) {
    if (room.status !== "playing") return;
    room.status = "over";            // trava na hora: evita acertar duas vezes
    clearTimeout(room.timer);
    room.result = { winner, reason };
    room.rematch = {};
    for (const p of room.players) {
      const s = sessions.get(p);
      if (s) clearTimeout(s.dc);
    }
    let ok = false;
    for (let i = 0; i < 3 && !ok; i++) {
      try {
        await db.finishMatch(room.matchId, winner);
        ok = true;
      } catch (e) {
        console.error("finish_match falhou:", e.message);
        await new Promise((r) => setTimeout(r, 500 * (i + 1)));
      }
    }
    if (!ok) {
      // O banco guarda o estado para auditoria/reconciliação; nunca "finge" que pagou.
      console.error("ATENÇÃO: partida não liquidada; marcada para revisão");
      try { await db.markSettlementAttention?.(room.matchId, "finish_match falhou após 3 tentativas"); } catch (e) { console.error("mark attention:", e.message); }
      if (typeof db.alert === "function") {
        try {
          await db.alert("settlement_failed", {
            matchId: room.matchId,
            winner,
            reason,
            players: room.players,
            stakeCents: room.stake,
          });
        } catch (e) { console.error("alert:", e.message); }
      }
    }
    broadcast(room);
  }

  // ---------------------------------------------------------------- ações dos jogadores
  async function listRooms(uid) {
    const list = [];
    for (const r of rooms.values()) {
      if (r.isPublic && r.status === "waiting") {
        const c = sessions.get(r.creatorId);
        list.push({ id: r.id, name: r.name, creator: c ? c.name : "Jogador", mines: r.mines, stakeCents: r.stake });
      }
    }
    sendTo(uid, { type: "rooms", list });
  }

  async function create(uid, m) {
    if (roomOf(uid)) return err(uid, "Você já está em uma sala.");
    if (!allowed(uid, "create", cfg.createPerWindow)) return err(uid, "Aguarde um pouco antes de criar outra sala.");
    const name = cleanName(m.name);
    const code = String(m.code || "").trim().toUpperCase();
    const stake = Number(m.stakeCents);
    const mines = Number(m.mines);
    if (name.length < 3 || name.length > 24) return err(uid, "O nome da sala precisa ter de 3 a 24 letras.");
    if (!CODE_RE.test(code)) return err(uid, "O código precisa ter de 4 a 20 letras ou números.");
    if (!Number.isInteger(stake) || stake < cfg.minStakeCents || stake > cfg.maxStakeCents) {
      return err(uid, `O valor precisa ficar entre ${money(cfg.minStakeCents)} e ${money(cfg.maxStakeCents)}.`);
    }
    if (!Number.isInteger(mines) || mines < 1 || mines > MAX_MINES) return err(uid, "Escolha de 1 a 10 minas.");
    if (rooms.has(code)) return err(uid, "Esse código já está em uso. Escolha outro.");
    const fee = feeOf(stake);
    const p = await db.profile(uid);
    if (!p || p.balance_cents < stake + fee) {
      return err(uid, `Saldo insuficiente. Você precisa de ${money(stake + fee)} (valor + taxa).`);
    }
    if (rooms.has(code)) return err(uid, "Esse código já está em uso. Escolha outro.");
    const room = {
      id: String(++roomSeq), code, name, isPublic: !!m.isPublic, stake, fee, mines,
      creatorId: uid, players: [uid], status: "waiting",
      confirmed: {}, paid: {}, placed: {}, boards: {}, hits: {}, rematch: {},
      turn: null, first: null, startedAt: null, deadline: null, matchId: null, result: null, timer: null,
    };
    rooms.set(code, room);
    sessions.get(uid).room = code;
    broadcast(room);
  }

  function findOpenRoom(uid, m) {
    let room = null;
    if (m.id !== undefined && m.id !== null && m.id !== "") {
      // salas públicas podem ser abertas pelo id da lista, sem digitar código
      for (const r of rooms.values()) if (r.id === String(m.id) && r.isPublic) room = r;
      if (!room) { err(uid, "Sala não encontrada. Atualize a lista."); return null; }
    } else {
      const code = String(m.code || "").trim().toUpperCase();
      room = rooms.get(code);
      if (!room) { err(uid, "Sala não encontrada. Confira o código."); return null; }
    }
    if (room.players.includes(uid)) { err(uid, "Você já está nessa sala."); return null; }
    if (room.status !== "waiting" || room.players.length >= 2) { err(uid, "Essa sala já está cheia."); return null; }
    return room;
  }

  async function joinInfo(uid, m) {
    if (roomOf(uid)) return err(uid, "Você já está em uma sala.");
    const room = findOpenRoom(uid, m);
    if (!room) return;
    const c = sessions.get(room.creatorId);
    sendTo(uid, {
      type: "room_info", code: room.code, name: room.name, stakeCents: room.stake,
      feeCents: room.fee, mines: room.mines, creator: c ? c.name : "Jogador",
    });
  }

  async function join(uid, m) {
    if (roomOf(uid)) return err(uid, "Você já está em uma sala.");
    if (!allowed(uid, "join", cfg.joinPerWindow)) return err(uid, "Aguarde um pouco antes de entrar em outra sala.");
    const room = findOpenRoom(uid, m);
    if (!room) return;
    const p = await db.profile(uid);
    if (!p || p.balance_cents < room.stake + room.fee) {
      return err(uid, `Saldo insuficiente. Você precisa de ${money(room.stake + room.fee)} (valor + taxa).`);
    }
    if (room.status !== "waiting" || room.players.length >= 2) return err(uid, "Essa sala já está cheia.");
    room.players.push(uid);
    room.status = "lobby";
    room.confirmed = {};
    sessions.get(uid).room = room.code;
    broadcast(room);
  }

  async function confirm(uid) {
    const room = roomOf(uid);
    if (!room || room.status !== "lobby" || room.players.length < 2) return;
    room.confirmed[uid] = true;
    if (room.players.every((p) => room.confirmed[p])) {
      room.status = "checkout";            // trava enquanto cria a partida no banco
      try {
        await newMatch(room);
      } catch (e) {
        console.error("newMatch:", e.message);
        room.status = "lobby";
        room.confirmed = {};
        const msg = e.userMessage || "Não consegui iniciar o pagamento. Tente de novo.";
        for (const p of room.players) err(p, msg);
        broadcast(room);
      }
    } else {
      broadcast(room);
    }
  }

  async function pay(uid, m) {
    const room = roomOf(uid);
    if (!room || room.status !== "checkout" || !room.matchId || room.paid[uid]) return;
    const matchId = room.matchId;
    if (!allowed(uid, "pay", cfg.payPerWindow)) return err(uid, "Aguarde um pouco antes de tentar pagar de novo.");
    const pin = String(m && m.pin || "").trim();
    if (pin.length !== 6) return err(uid, "Informe sua senha de 6 dígitos.");
    try {
      // checkPin não dá erro na senha errada: devolve um código, e a contagem fica gravada.
      const code = await db.checkPin(uid, pin);
      if (code !== "ok") return err(uid, PIN_MSG[code] || PIN_MSG.wrong);
      await db.payMatch(matchId, uid);
    } catch (e) {
      console.error("pay_match:", e.message);
      return err(uid, e.userMessage || "Não foi possível pagar. Confira sua senha de 6 dígitos.");
    }
    if (room.matchId !== matchId || room.status !== "checkout") return;
    room.paid[uid] = true;
    try { await db.touchMatch?.(matchId, cfg.instanceId); } catch (e) { console.error("touch_match:", e.message); }
    if (room.players.every((p) => room.paid[p])) startPlacing(room);
    else broadcast(room);
  }

  function placeMines(uid, m) {
    const room = roomOf(uid);
    if (!room || room.status !== "placing" || room.placed[uid]) return;
    const cells = Array.isArray(m.cells) ? m.cells : [];
    const set = new Set(cells);
    if (cells.length !== room.mines || set.size !== room.mines ||
        ![...set].every((c) => Number.isInteger(c) && c >= 0 && c < CELLS)) {
      return err(uid, `Escolha exatamente ${room.mines} casas diferentes.`);
    }
    room.boards[uid] = set;
    room.placed[uid] = true;
    if (room.players.every((p) => room.placed[p])) startGame(room);
    else broadcast(room);
  }

  async function rematch(uid) {
    const room = roomOf(uid);
    if (!room || room.status !== "over") return;
    if (room.players.length < 2) return err(uid, "O adversário saiu da sala.");
    room.rematch[uid] = true;
    if (room.players.every((p) => room.rematch[p])) {
      room.status = "checkout";
      try {
        await newMatch(room);
      } catch (e) {
        console.error("rematch:", e.message);
        room.status = "over";
        room.rematch = {};
        const msg = e.userMessage || "Não consegui iniciar a revanche. Tente de novo.";
        for (const p of room.players) err(p, msg);
        broadcast(room);
      }
    } else {
      broadcast(room);
    }
  }

  // Depósito PIX via gateway (SyncPay). O saldo só sobe no webhook, nunca aqui.
  async function deposit(uid, m) {
    const cents = Number(m.cents);
    if (!Number.isInteger(cents) || cents < cfg.minDepositCents) {
      return err(uid, `O depósito mínimo é R$ ${(cfg.minDepositCents / 100).toFixed(2).replace(".", ",")}.`);
    }
    if (cents > cfg.maxDepositCents) {
      return err(uid, `O depósito máximo é R$ ${(cfg.maxDepositCents / 100).toFixed(2).replace(".", ",")}.`);
    }
    if (!cfg.depositsEnabled || typeof cfg.createPixDeposit !== "function") {
      return err(uid, "Depósito por Pix ainda não está disponível.");
    }
    const cpf = String(m.cpf || "").replace(/\D/g, "");
    if (cpf.length !== 11) return err(uid, "Informe um CPF válido com 11 dígitos.");
    try {
      if (!allowed(uid, "deposit", 5)) return err(uid, "Muitos pedidos de depósito. Espere um pouco.");
      const s = sessions.get(uid);
      const result = await cfg.createPixDeposit({
        uid,
        cents,
        cpf,
        name: s?.name || "Jogador",
        email: s?.email || "",
      });
      sendTo(uid, {
        type: "pix_deposit",
        pixCode: result.pixCode,
        identifier: result.identifier,
        cents,
      });
    } catch (e) {
      console.error("deposit:", e && e.message ? e.message : e);
      return err(uid, e.userMessage || "Não deu para gerar o Pix. Tente de novo.");
    }
  }

  // Jogador desistiu do Pix antes de pagar. Se ele pagar mesmo assim, o webhook ainda
  // credita (o dinheiro chegou de verdade), então cancelar aqui só fecha a tela.
  async function depositCancel(uid, m) {
    const identifier = String(m.identifier || "");
    if (!identifier || identifier.length > 80) return err(uid, "Depósito inválido.");
    try {
      const ok = await cfg.cancelDeposit(identifier, uid);
      sendTo(uid, { type: "deposit_cancelled", identifier, ok: !!ok });
    } catch (e) {
      console.error("deposit_cancel:", e && e.message ? e.message : e);
      err(uid, "Não deu para cancelar agora. Tente de novo.");
    }
  }

  function removeFromQueue(uid) {
    const idx = matchmakingQueue.findIndex((entry) => entry.uid === uid);
    if (idx !== -1) {
      matchmakingQueue.splice(idx, 1);
      return true;
    }
    return false;
  }

  // ---------------------------------------------------------------- Matchmaking (Encontrar Partida)
  async function findMatch(uid, m) {
    if (roomOf(uid)) return err(uid, "Você já está em uma sala ou partida.");
    const stake = Number(m.stakeCents);
    const mines = Number(m.mines);
    if (!Number.isInteger(stake) || stake < cfg.minStakeCents || stake > cfg.maxStakeCents) {
      return err(uid, `O valor precisa ficar entre ${money(cfg.minStakeCents)} e ${money(cfg.maxStakeCents)}.`);
    }
    if (!Number.isInteger(mines) || mines < 1 || mines > MAX_MINES) {
      return err(uid, "Escolha de 1 a 10 minas.");
    }
    const fee = feeOf(stake);
    const p = await db.profile(uid);
    if (!p || p.balance_cents < stake + fee) {
      return err(uid, `Saldo insuficiente. Você precisa de ${money(stake + fee)} (valor + taxa).`);
    }

    removeFromQueue(uid);

    // Busca alguém na fila esperando com a mesma quantidade de minas e valor
    const oppIndex = matchmakingQueue.findIndex((entry) =>
      entry.uid !== uid &&
      entry.stake === stake &&
      entry.mines === mines &&
      !pairTooMany(uid, entry.uid) &&
      sessions.has(entry.uid) &&
      sessions.get(entry.uid).send
    );

    if (oppIndex !== -1) {
      const opp = matchmakingQueue.splice(oppIndex, 1)[0];
      const code = "M" + Math.random().toString(36).substring(2, 8).toUpperCase();
      const room = {
        id: String(++roomSeq),
        code,
        name: `Duelo ${mines} Minas`,
        isPublic: false,
        stake,
        fee,
        mines,
        creatorId: opp.uid,
        players: [opp.uid, uid],
        status: "lobby",
        confirmed: {},
        paid: {},
        placed: {},
        boards: {},
        hits: {},
        rematch: {},
        turn: null,
        first: null,
        startedAt: null,
        deadline: null,
        matchId: null,
        result: null,
        timer: null,
      };
      rooms.set(code, room);
      sessions.get(opp.uid).room = code;
      sessions.get(uid).room = code;
      try {
        await newMatch(room);
      } catch (e) {
        console.error("newMatch matchmaking:", e && e.message ? e.message : e);
        room.status = "lobby";
        broadcast(room);
      }
    } else {
      matchmakingQueue.push({ uid, stake, mines, queuedAt: now() });
      sendTo(uid, { type: "matchmaking_searching", stakeCents: stake, mines });
    }
  }

  async function cancelMatch(uid) {
    if (removeFromQueue(uid)) {
      sendTo(uid, { type: "matchmaking_cancelled" });
    }
  }

  // ---------------------------------------------------------------- Saques
  async function withdraw(uid, m) {
    const cents = Number(m.cents);
    if (!Number.isInteger(cents) || cents < 2000) {
      return err(uid, "O saque mínimo é R$ 20,00.");
    }
    const pixType = String(m.pixType || "").trim().toLowerCase();
    const pixKey = String(m.pixKey || "").trim();
    const pin = String(m.pin || "").trim();
    if (!["cpf", "cnpj", "email", "phone", "random"].includes(pixType)) {
      return err(uid, "Tipo de chave Pix inválido.");
    }
    if (pixKey.length < 3 || pixKey.length > 140) {
      return err(uid, "Chave Pix inválida.");
    }
    if (pin.length !== 6) {
      return err(uid, "Informe sua senha de 6 dígitos.");
    }
    const p = await db.profile(uid);
    if (!p || p.balance_cents < cents) {
      return err(uid, "Saldo insuficiente para saque.");
    }
    if (!allowed(uid, "withdraw", 3, 60_000)) {
      return err(uid, "Muitos pedidos de saque. Aguarde um momento.");
    }
    try {
      const r = await db.requestWithdrawal(uid, cents, pixType, pixKey, pin);
      if (!r || !r.ok) return err(uid, PIN_MSG[r && r.error] || "Não foi possível solicitar o saque.");
      const wid = r.withdrawal_id;
      sendTo(uid, { type: "withdraw_success", wid, cents });
      const updated = await db.profile(uid);
      if (updated) {
        sendTo(uid, { type: "profile_updated", balanceCents: updated.balance_cents });
      }
    } catch (e) {
      console.error("withdraw error:", e && e.message ? e.message : e);
      return err(uid, e.userMessage || "Não foi possível solicitar o saque. Confira sua senha de 6 dígitos.");
    }
  }

  // ---------------------------------------------------------------- entrada e saída de conexões
  async function connect(uid, send) {
    const p = await db.profile(uid);
    if (p && p.banned) {
      send({ type: "error", message: "Esta conta está bloqueada. Fale com o suporte." });
      return false;
    }
    if (!p || !p.profile_done || !p.terms_version) {
      send({ type: "error", message: "Complete seu perfil e aceite os termos antes de jogar." });
      return false;
    }
    let s = sessions.get(uid);
    if (s && s.send && s.send !== send) {
      try { s.send({ type: "error", message: "Você entrou em outro aparelho." }); } catch { /* ignore */ }
    }
    if (!s) {
      s = { id: uid, room: null, dc: null };
      sessions.set(uid, s);
    }
    s.name = cleanName(p.display_name, 20) || "Jogador";
    if (typeof s.pendingEmail === "string") { s.email = s.pendingEmail; delete s.pendingEmail; }
    s.avatar = p.avatar_url || "";
    s.verified = !!p.verified;
    s.banCheckedAt = now();
    s.send = send;
    clearTimeout(s.dc);
    send({
      type: "hello", you: uid, feePercent: cfg.feePercent, minDepositCents: cfg.minDepositCents,
      minStakeCents: cfg.minStakeCents, maxStakeCents: cfg.maxStakeCents, maxMines: MAX_MINES,
    });
    const room = roomOf(uid);
    if (room) broadcast(room);
    return true;
  }

  function disconnect(uid, send) {
    removeFromQueue(uid);
    const s = sessions.get(uid);
    if (!s || s.send !== send) return;
    s.send = null;
    const room = roomOf(uid);
    if (!room) {
      sessions.delete(uid);
      return;
    }
    broadcast(room); // mostra "offline" para o outro
    clearTimeout(s.dc);
    s.dc = setTimeout(() => {
      Promise.resolve(onGraceExpired(uid)).catch((e) => console.error("grace:", e));
    }, cfg.graceMs);
  }

  async function onGraceExpired(uid) {
    const s = sessions.get(uid);
    if (!s || s.send) return;
    await leave(uid);
    dropIfIdle(uid);
  }

  async function message(uid, m) {
    if (!m || typeof m.type !== "string") return;
    try {
      const s = sessions.get(uid);
      // Revalidação periódica permite expulsar banidos sem fazer uma consulta em cada clique.
      if (s && now() - (s.banCheckedAt || 0) > 30_000) {
        const p = await db.profile(uid);
        s.banCheckedAt = now();
        if (!p || p.banned) { await leave(uid); return err(uid, "Esta conta está bloqueada. Fale com o suporte."); }
      }
      switch (m.type) {
        case "find_match": return await findMatch(uid, m);
        case "cancel_match": return await cancelMatch(uid);
        case "withdraw": return await withdraw(uid, m);
        case "list": return await listRooms(uid);
        case "create": return await create(uid, m);
        case "join_info": return await joinInfo(uid, m);
        case "join": return await join(uid, m);
        case "leave": return await leave(uid);
        case "confirm": return await confirm(uid);
        case "pay": return await pay(uid, m);
        case "place_mines": return placeMines(uid, m);
        case "pick": return await pick(uid, m.cell);
        case "rematch": return await rematch(uid);
        case "deposit": return await deposit(uid, m);
        case "deposit_cancel": return await depositCancel(uid, m);
        case "sync": { const r = roomOf(uid); if (r) sendTo(uid, stateFor(r, uid)); else sendTo(uid, { type: "left" }); return; }
        default: return;
      }
    } catch (e) {
      console.error("erro em", m.type, e && e.message ? e.message : e);
      err(uid, "Erro no servidor. Tente de novo.");
    }
  }

  async function recover() {
    // Só devolve partidas cujo último sinal de vida expirou. Uma instância nova não toca
    // na partida ainda ativa na instância antiga durante um deploy.
    return db.recover(cfg.instanceId, new Date(now() - 3 * 60_000).toISOString());
  }

  
  function setSessionEmail(uid, email) {
    let s = sessions.get(uid);
    if (!s) {
      s = { id: uid, room: null, dc: null, pendingEmail: email };
      sessions.set(uid, s);
    } else {
      s.email = email || s.email || "";
    }
  }

  return {
    connect,
    disconnect,
    message,
    notify: (uid, msg) => sendTo(uid, msg),
    setSessionEmail,
    recover,
    _rooms: rooms,
    _sessions: sessions,
    cfg,
  };
}

