// Regras do jogo: salas, pagamento, minas secretas e turnos.
// Não conhece rede nem banco: tudo entra por `db` e `send`, o que permite testar sem internet.
import { randomInt } from "node:crypto";

export const CELLS = 25;       // tabuleiro 5x5
export const MAX_MINES = 10;

export const DEFAULT_CFG = {
  feePercent: 25,        // taxa por jogador, em % do valor da sala (R$ 2,00 -> R$ 0,50)
  minStakeCents: 100,    // mínimo R$ 1,00
  maxStakeCents: 50000,  // máximo R$ 500,00
  testMode: true,        // libera "saldo de teste"
  testGrantCents: 5000,  // R$ 50,00 por pedido
  turnMs: 30000,         // tempo para jogar
  animMs: 3500,          // tempo da animação do sorteio
  placeMs: 90000,        // tempo para posicionar minas
  checkoutMs: 120000,    // tempo para pagar
  graceMs: 45000,        // tempo para reconectar antes de perder por abandono
};

const CODE_RE = /^[A-Z0-9-]{4,20}$/;

export function createEngine({ db, cfg: userCfg = {}, now = () => Date.now() }) {
  const cfg = { ...DEFAULT_CFG, ...userCfg };
  const sessions = new Map(); // userId -> { id, name, avatar, send, room, dc }
  const rooms = new Map();    // code -> room
  let roomSeq = 0;

  const feeOf = (stake) => Math.round((stake * cfg.feePercent) / 100);
  const other = (room, uid) => room.players.find((p) => p !== uid) || null;
  const roomOf = (uid) => {
    const s = sessions.get(uid);
    return s && s.room ? rooms.get(s.room) || null : null;
  };
  const sendTo = (uid, msg) => {
    const s = sessions.get(uid);
    if (s && s.send) {
      try { s.send(msg); } catch { /* conexão caiu */ }
    }
  };
  const err = (uid, message) => sendTo(uid, { type: "error", message });
  const money = (c) => "R$ " + (c / 100).toFixed(2).replace(".", ",");

  function setTimer(room, ms, fn) {
    clearTimeout(room.timer);
    room.timer = setTimeout(() => {
      Promise.resolve(fn()).catch((e) => console.error("timer:", e));
    }, ms);
  }

  // ---------------------------------------------------------------- estado enviado a cada jogador
  function stateFor(room, uid) {
    const opp = other(room, uid);
    const over = room.status === "over" && room.result;
    return {
      type: "state",
      room: {
        id: room.id,
        code: room.code,
        name: room.name,
        isPublic: room.isPublic,
        stakeCents: room.stake,
        feeCents: room.fee,
        mines: room.mines,
        status: room.status,
        you: uid,
        creator: room.creatorId,
        players: room.players.map((p) => {
          const s = sessions.get(p);
          return {
            id: p,
            name: s ? s.name : "Jogador",
            avatar: s ? s.avatar : "",
            confirmed: !!room.confirmed[p],
            paid: !!room.paid[p],
            placed: !!room.placed[p],
            online: !!(s && s.send),
          };
        }),
        turn: room.turn,
        first: room.first,
        startedAt: room.startedAt,
        deadline: room.deadline,
        serverNow: now(),
        myMines: [...(room.boards[uid] || [])],               // só eu vejo as minhas
        hitsOnMe: [...(room.hits[uid] || [])],                // casas que o adversário abriu no meu tabuleiro
        myPicks: opp ? [...(room.hits[opp] || [])] : [],      // casas que eu abri no tabuleiro dele
        opponentLeft: room.players.length < 2 && room.status !== "waiting",
        result: over
          ? {
              winner: room.result.winner,
              youWon: room.result.winner === uid,
              reason: room.result.reason,
              prizeCents: room.stake * 2,
              oppMines: opp ? [...(room.boards[opp] || [])] : [],   // só revelado no fim
            }
          : null,
        rematch: { you: !!room.rematch[uid], opp: !!(opp && room.rematch[opp]) },
      },
    };
  }

  function broadcast(room) {
    for (const p of room.players) sendTo(p, stateFor(room, p));
  }

  // ---------------------------------------------------------------- fechar / sair
  function closeRoom(room, message) {
    clearTimeout(room.timer);
    rooms.delete(room.code);
    for (const p of room.players) {
      const s = sessions.get(p);
      if (s) {
        s.room = null;
        clearTimeout(s.dc);
      }
      sendTo(p, { type: "room_closed", message: message || "Sala fechada." });
      dropIfIdle(p);
    }
    room.players = [];
  }

  function dropIfIdle(uid) {
    const s = sessions.get(uid);
    if (s && !s.send && !s.room) sessions.delete(uid);
  }

  async function cancelWithRefund(room, message) {
    const matchId = room.matchId;
    room.matchId = null;
    if (matchId) {
      try { await db.refundMatch(matchId); } catch (e) { console.error("refund:", e.message); }
    }
    closeRoom(room, message);
  }

  function detach(room, uid) {
    room.players = room.players.filter((p) => p !== uid);
    const s = sessions.get(uid);
    if (s) {
      s.room = null;
      clearTimeout(s.dc);
    }
    sendTo(uid, { type: "left" });
    dropIfIdle(uid);
    if (room.players.length === 0) {
      clearTimeout(room.timer);
      rooms.delete(room.code);
    } else {
      room.rematch = {};
      broadcast(room);
    }
  }

  async function leave(uid) {
    const room = roomOf(uid);
    if (!room) return sendTo(uid, { type: "left" });
    switch (room.status) {
      case "waiting":
        closeRoom(room, "Sala fechada.");
        break;
      case "lobby":
        if (uid === room.creatorId) {
          closeRoom(room, "O criador fechou a sala.");
        } else {
          room.players = room.players.filter((p) => p !== uid);
          room.confirmed = {};
          room.status = "waiting";
          const s = sessions.get(uid);
          if (s) s.room = null;
          sendTo(uid, { type: "left" });
          dropIfIdle(uid);
          broadcast(room);
        }
        break;
      case "checkout":
      case "placing":
        await cancelWithRefund(room, "Partida cancelada. Os valores pagos foram devolvidos.");
        break;
      case "playing":
        await finish(room, other(room, uid), "abandono");
        detach(room, uid);
        break;
      default:
        detach(room, uid);
    }
  }

  // ---------------------------------------------------------------- fluxo da partida
  async function newMatch(room) {
    room.matchId = await db.createMatch(room.code, room.players[0], room.players[1], room.stake, room.fee);
    room.status = "checkout";
    room.paid = {};
    room.placed = {};
    room.boards = {};
    room.hits = {};
    room.turn = null;
    room.first = null;
    room.result = null;
    room.rematch = {};
    room.confirmed = { [room.players[0]]: true, [room.players[1]]: true };
    setTimer(room, cfg.checkoutMs, () => cancelWithRefund(room, "Tempo de pagamento esgotado. Os valores pagos foram devolvidos."));
    broadcast(room);
  }

  function randomMines(n) {
    const set = new Set();
    while (set.size < n) set.add(randomInt(CELLS));
    return set;
  }

  function startPlacing(room) {
    room.status = "placing";
    room.deadline = now() + cfg.placeMs;
    setTimer(room, cfg.placeMs, () => {
      if (room.status !== "placing") return;
      for (const p of room.players) {
        if (!room.placed[p]) {
          room.boards[p] = randomMines(room.mines);
          room.placed[p] = true;
        }
      }
      startGame(room);
    });
    broadcast(room);
  }

  function startGame(room) {
    room.status = "playing";
    room.first = room.players[randomInt(2)];
    room.turn = room.first;
    room.startedAt = now();
    room.deadline = now() + cfg.animMs + cfg.turnMs;
    room.hits = { [room.players[0]]: new Set(), [room.players[1]]: new Set() };
    setTimer(room, cfg.animMs + cfg.turnMs, () => onTurnTimeout(room));
    broadcast(room);
  }

  async function onTurnTimeout(room) {
    if (room.status !== "playing") return;
    const uid = room.turn;
    const opp = other(room, uid);
    const free = [];
    for (let i = 0; i < CELLS; i++) if (!room.hits[opp].has(i)) free.push(i);
    if (free.length === 0) return finish(room, opp, "tempo");
    await pick(uid, free[randomInt(free.length)], true);
  }

  async function pick(uid, cell, auto = false) {
    const room = roomOf(uid);
    if (!room || room.status !== "playing") return;
    if (room.turn !== uid) return err(uid, "Ainda não é a sua vez.");
    if (!Number.isInteger(cell) || cell < 0 || cell >= CELLS) return;
    const opp = other(room, uid);
    if (room.hits[opp].has(cell)) return err(uid, "Essa casa já foi aberta.");
    if (!auto && now() < room.startedAt + cfg.animMs - 200) return; // ainda no sorteio
    room.hits[opp].add(cell);
    if (room.boards[opp].has(cell)) {
      await finish(room, opp, "mina");
    } else {
      room.turn = opp;
      room.deadline = now() + cfg.turnMs;
      setTimer(room, cfg.turnMs, () => onTurnTimeout(room));
      broadcast(room);
    }
  }

  async function finish(room, winner, reason) {
    if (room.status !== "playing") return;
    room.status = "over";            // trava na hora: evita acertar duas vezes
    clearTimeout(room.timer);
    room.result = { winner, reason };
    room.rematch = {};
    for (const p of room.players) {
      const s = sessions.get(p);
      if (s) clearTimeout(s.dc);
    }
    let ok = false;
    for (let i = 0; i < 3 && !ok; i++) {
      try {
        await db.finishMatch(room.matchId, winner);
        ok = true;
      } catch (e) {
        console.error("finish_match falhou:", e.message);
        await new Promise((r) => setTimeout(r, 300));
      }
    }
    if (!ok) console.error("ATENÇÃO: partida", room.matchId, "não liquidada; será devolvida na próxima inicialização.");
    broadcast(room);
  }

  // ---------------------------------------------------------------- ações dos jogadores
  async function listRooms(uid) {
    const list = [];
    for (const r of rooms.values()) {
      if (r.isPublic && r.status === "waiting") {
        const c = sessions.get(r.creatorId);
        list.push({ id: r.id, name: r.name, creator: c ? c.name : "Jogador", mines: r.mines, stakeCents: r.stake });
      }
    }
    sendTo(uid, { type: "rooms", list });
  }

  async function create(uid, m) {
    if (roomOf(uid)) return err(uid, "Você já está em uma sala.");
    const name = String(m.name || "").trim();
    const code = String(m.code || "").trim().toUpperCase();
    const stake = Number(m.stakeCents);
    const mines = Number(m.mines);
    if (name.length < 3 || name.length > 24) return err(uid, "O nome da sala precisa ter de 3 a 24 letras.");
    if (!CODE_RE.test(code)) return err(uid, "O código precisa ter de 4 a 20 letras ou números.");
    if (!Number.isInteger(stake) || stake < cfg.minStakeCents || stake > cfg.maxStakeCents) {
      return err(uid, `O valor precisa ficar entre ${money(cfg.minStakeCents)} e ${money(cfg.maxStakeCents)}.`);
    }
    if (!Number.isInteger(mines) || mines < 1 || mines > MAX_MINES) return err(uid, "Escolha de 1 a 10 minas.");
    if (rooms.has(code)) return err(uid, "Esse código já está em uso. Escolha outro.");
    const fee = feeOf(stake);
    const p = await db.profile(uid);
    if (!p || p.balance_cents < stake + fee) {
      return err(uid, `Saldo insuficiente. Você precisa de ${money(stake + fee)} (valor + taxa).`);
    }
    if (rooms.has(code)) return err(uid, "Esse código já está em uso. Escolha outro.");
    const room = {
      id: String(++roomSeq), code, name, isPublic: !!m.isPublic, stake, fee, mines,
      creatorId: uid, players: [uid], status: "waiting",
      confirmed: {}, paid: {}, placed: {}, boards: {}, hits: {}, rematch: {},
      turn: null, first: null, startedAt: null, deadline: null, matchId: null, result: null, timer: null,
    };
    rooms.set(code, room);
    sessions.get(uid).room = code;
    broadcast(room);
  }

  function findOpenRoom(uid, codeRaw) {
    const code = String(codeRaw || "").trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) { err(uid, "Sala não encontrada. Confira o código."); return null; }
    if (room.players.includes(uid)) { err(uid, "Você já está nessa sala."); return null; }
    if (room.status !== "waiting" || room.players.length >= 2) { err(uid, "Essa sala já está cheia."); return null; }
    return room;
  }

  async function joinInfo(uid, m) {
    if (roomOf(uid)) return err(uid, "Você já está em uma sala.");
    const room = findOpenRoom(uid, m.code);
    if (!room) return;
    const c = sessions.get(room.creatorId);
    sendTo(uid, {
      type: "room_info", code: room.code, name: room.name, stakeCents: room.stake,
      feeCents: room.fee, mines: room.mines, creator: c ? c.name : "Jogador",
    });
  }

  async function join(uid, m) {
    if (roomOf(uid)) return err(uid, "Você já está em uma sala.");
    const room = findOpenRoom(uid, m.code);
    if (!room) return;
    const p = await db.profile(uid);
    if (!p || p.balance_cents < room.stake + room.fee) {
      return err(uid, `Saldo insuficiente. Você precisa de ${money(room.stake + room.fee)} (valor + taxa).`);
    }
    if (room.status !== "waiting" || room.players.length >= 2) return err(uid, "Essa sala já está cheia.");
    room.players.push(uid);
    room.status = "lobby";
    room.confirmed = {};
    sessions.get(uid).room = room.code;
    broadcast(room);
  }

  async function confirm(uid) {
    const room = roomOf(uid);
    if (!room || room.status !== "lobby" || room.players.length < 2) return;
    room.confirmed[uid] = true;
    if (room.players.every((p) => room.confirmed[p])) {
      room.status = "checkout";            // trava enquanto cria a partida no banco
      try {
        await newMatch(room);
      } catch (e) {
        console.error("newMatch:", e.message);
        room.status = "lobby";
        room.confirmed = {};
        for (const p of room.players) err(p, "Não consegui iniciar o pagamento. Tente de novo.");
        broadcast(room);
      }
    } else {
      broadcast(room);
    }
  }

  async function pay(uid) {
    const room = roomOf(uid);
    if (!room || room.status !== "checkout" || !room.matchId || room.paid[uid]) return;
    const matchId = room.matchId;
    try {
      await db.payMatch(matchId, uid);
    } catch (e) {
      return err(uid, e.userMessage || e.message || "Não foi possível pagar.");
    }
    if (room.matchId !== matchId || room.status !== "checkout") return;
    room.paid[uid] = true;
    if (room.players.every((p) => room.paid[p])) startPlacing(room);
    else broadcast(room);
  }

  function placeMines(uid, m) {
    const room = roomOf(uid);
    if (!room || room.status !== "placing" || room.placed[uid]) return;
    const cells = Array.isArray(m.cells) ? m.cells : [];
    const set = new Set(cells);
    if (cells.length !== room.mines || set.size !== room.mines ||
        ![...set].every((c) => Number.isInteger(c) && c >= 0 && c < CELLS)) {
      return err(uid, `Escolha exatamente ${room.mines} casas diferentes.`);
    }
    room.boards[uid] = set;
    room.placed[uid] = true;
    if (room.players.every((p) => room.placed[p])) startGame(room);
    else broadcast(room);
  }

  async function rematch(uid) {
    const room = roomOf(uid);
    if (!room || room.status !== "over") return;
    if (room.players.length < 2) return err(uid, "O adversário saiu da sala.");
    room.rematch[uid] = true;
    if (room.players.every((p) => room.rematch[p])) {
      room.status = "checkout";
      try {
        await newMatch(room);
      } catch (e) {
        console.error("rematch:", e.message);
        room.status = "over";
        room.rematch = {};
        for (const p of room.players) err(p, "Não consegui iniciar a revanche. Tente de novo.");
        broadcast(room);
      }
    } else {
      broadcast(room);
    }
  }

  async function grantTest(uid) {
    if (!cfg.testMode) return err(uid, "Saldo de teste desativado.");
    const p = await db.profile(uid);
    if (p && p.balance_cents >= cfg.testGrantCents) return err(uid, "Você já tem saldo de teste suficiente.");
    await db.grantTest(uid, cfg.testGrantCents);
    sendTo(uid, { type: "ok", what: "grant" });
  }

  // ---------------------------------------------------------------- entrada e saída de conexões
  async function connect(uid, send) {
    const p = await db.profile(uid);
    if (!p || !p.profile_done || !p.terms_version) {
      send({ type: "error", message: "Complete seu perfil e aceite os termos antes de jogar." });
      return false;
    }
    let s = sessions.get(uid);
    if (s && s.send && s.send !== send) {
      try { s.send({ type: "error", message: "Você entrou em outro aparelho." }); } catch { /* ignore */ }
    }
    if (!s) {
      s = { id: uid, room: null, dc: null };
      sessions.set(uid, s);
    }
    s.name = p.display_name || "Jogador";
    s.avatar = p.avatar_url || "";
    s.send = send;
    clearTimeout(s.dc);
    send({
      type: "hello", you: uid, testMode: cfg.testMode, feePercent: cfg.feePercent,
      minStakeCents: cfg.minStakeCents, maxStakeCents: cfg.maxStakeCents, maxMines: MAX_MINES,
    });
    const room = roomOf(uid);
    if (room) broadcast(room);
    return true;
  }

  function disconnect(uid, send) {
    const s = sessions.get(uid);
    if (!s || s.send !== send) return;
    s.send = null;
    const room = roomOf(uid);
    if (!room) {
      sessions.delete(uid);
      return;
    }
    broadcast(room); // mostra "offline" para o outro
    clearTimeout(s.dc);
    s.dc = setTimeout(() => {
      Promise.resolve(onGraceExpired(uid)).catch((e) => console.error("grace:", e));
    }, cfg.graceMs);
  }

  async function onGraceExpired(uid) {
    const s = sessions.get(uid);
    if (!s || s.send) return;
    await leave(uid);
    dropIfIdle(uid);
  }

  async function message(uid, m) {
    if (!m || typeof m.type !== "string") return;
    try {
      switch (m.type) {
        case "list": return await listRooms(uid);
        case "create": return await create(uid, m);
        case "join_info": return await joinInfo(uid, m);
        case "join": return await join(uid, m);
        case "leave": return await leave(uid);
        case "confirm": return await confirm(uid);
        case "pay": return await pay(uid);
        case "place_mines": return placeMines(uid, m);
        case "pick": return await pick(uid, m.cell);
        case "rematch": return await rematch(uid);
        case "grant_test": return await grantTest(uid);
        case "sync": { const r = roomOf(uid); if (r) sendTo(uid, stateFor(r, uid)); else sendTo(uid, { type: "left" }); return; }
        default: return;
      }
    } catch (e) {
      console.error("erro em", m.type, e);
      err(uid, "Erro no servidor. Tente de novo.");
    }
  }

  async function recover() {
    return db.recover();
  }

  return { connect, disconnect, message, recover, _rooms: rooms, _sessions: sessions, cfg };
}
