import test from "node:test";
import assert from "node:assert/strict";
import { createEngine } from "./engine.js";

// Banco de mentira, com as mesmas regras do SQL (saldo nunca fica negativo, liquidação só uma vez)
function fakeDb(balances) {
  const profiles = {};
  for (const [id, bal] of Object.entries(balances)) {
    profiles[id] = { id, display_name: "J-" + id, avatar_url: "", balance_cents: bal, profile_done: true, terms_version: "1.0", wins: 0, losses: 0 };
  }
  const matches = {};
  let seq = 0;
  return {
    profiles, matches,
    profile: async (id) => profiles[id] || null,
    createMatch: async (code, p1, p2, stake, fee) => {
      const id = "m" + ++seq;
      matches[id] = { id, p1, p2, stake, fee, paid: {}, status: "pending" };
      return id;
    },
    payMatch: async (id, uid) => {
      const m = matches[id];
      if (m.status !== "pending") throw new Error("não está aguardando pagamento");
      if (m.paid[uid]) return m.status;
      if (profiles[uid].balance_cents < m.stake + m.fee) { const e = new Error("Saldo insuficiente."); e.userMessage = "Saldo insuficiente."; throw e; }
      profiles[uid].balance_cents -= m.stake + m.fee;
      m.paid[uid] = true;
      if (m.paid[m.p1] && m.paid[m.p2]) m.status = "paid";
      return m.status;
    },
    finishMatch: async (id, winner) => {
      const m = matches[id];
      if (m.status === "finished") return;
      if (m._failFinish) throw new Error("simulated finish failure");
      if (m.status !== "paid") throw new Error("partida não está em andamento");
      profiles[winner].balance_cents += m.stake * 2;
      profiles[winner].wins++;
      profiles[winner === m.p1 ? m.p2 : m.p1].losses++;
      m.status = "finished";
      m.winner = winner;
    },
    refundMatch: async (id) => {
      const m = matches[id];
      if (!m || (m.status !== "pending" && m.status !== "paid")) return;
      for (const u of [m.p1, m.p2]) if (m.paid[u]) profiles[u].balance_cents += m.stake + m.fee;
      m.status = "refunded";
    },
    recover: async () => 0,
    touchMatch: async () => {},
    markSettlementAttention: async (id, detail) => {
      if (matches[id]) { matches[id].attention = detail; matches[id].attention_required = true; }
    },
    flagMatch: async () => {},
    alerts: [],
    alert: async function (kind, detail) { this.alerts.push({ kind, detail }); },
  };
}

const fast = { turnMs: 400, animMs: 30, placeMs: 400, checkoutMs: 400, graceMs: 200, feePercent: 25 };

function setup(balances = { A: 1000, B: 1000 }, cfg = {}) {
  const db = fakeDb(balances);
  const engine = createEngine({ db, cfg: { ...fast, ...cfg } });
  const inbox = {};
  const users = {};
  for (const id of Object.keys(balances)) {
    inbox[id] = [];
    users[id] = (m) => inbox[id].push(m);
  }
  const last = (id, type) => [...inbox[id]].reverse().find((m) => m.type === type);
  const state = (id) => last(id, "state")?.room;
  const lastError = (id) => last(id, "error")?.message;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  return { db, engine, inbox, users, last, state, lastError, sleep };
}

async function toPlaying(t, mines = [0, 1, 2], minesB = [3, 4, 5]) {
  const { engine, users, state, sleep } = t;
  await engine.connect("A", users.A);
  await engine.connect("B", users.B);
  await engine.message("A", { type: "create", name: "Sala 1", code: "abc123", stakeCents: 200, mines: 3, isPublic: true });
  await engine.message("B", { type: "join", code: "ABC123" });
  await engine.message("A", { type: "confirm" });
  await engine.message("B", { type: "confirm" });
  await engine.message("A", { type: "pay" });
  await engine.message("B", { type: "pay" });
  assert.equal(state("A").status, "placing");
  await engine.message("A", { type: "place_mines", cells: mines });
  await engine.message("B", { type: "place_mines", cells: minesB });
  assert.equal(state("A").status, "playing");
  await sleep(60); // passa a animação do sorteio
}

test("fluxo completo: o vencedor leva 2x o valor e a taxa fica com o app", async () => {
  const t = setup();
  await toPlaying(t);
  const { engine, db, state } = t;
  const first = state("A").first;
  const second = first === "A" ? "B" : "A";
  const secondMines = second === "A" ? [0, 1, 2] : [3, 4, 5];
  // quem começa abre uma casa segura (a do adversário não tem mina nela)
  const safe = [10, 11, 12, 13];
  await engine.message(first, { type: "pick", cell: safe[0] });
  assert.equal(state(first).turn, second);
  // o segundo abre uma mina do tabuleiro do primeiro e perde
  const firstMines = first === "A" ? [0, 1, 2] : [3, 4, 5];
  await engine.message(second, { type: "pick", cell: firstMines[0] });
  assert.equal(state(first).status, "over");
  assert.equal(state(first).result.youWon, true);
  assert.equal(state(second).result.youWon, false);
  // dinheiro: ambos pagaram 2,50 (2,00 + 0,50). Vencedor recebe 4,00.
  assert.equal(db.profiles[first].balance_cents, 1000 - 250 + 400);
  assert.equal(db.profiles[second].balance_cents, 1000 - 250);
  assert.equal(db.profiles[first].wins, 1);
  assert.equal(db.profiles[second].losses, 1);
  void secondMines;
});

test("as minas do adversário nunca aparecem antes do fim", async () => {
  const t = setup();
  await toPlaying(t);
  const s = t.state("A");
  assert.deepEqual(s.myMines.sort(), [0, 1, 2]);
  assert.equal(s.result, null);
  assert.ok(!JSON.stringify(s).includes('"oppMines"'));
  const raw = JSON.stringify(t.inbox.A);
  assert.ok(!raw.includes('"myMines":[3,4,5]'));
});

test("saldo insuficiente impede criar e entrar na sala", async () => {
  const t = setup({ A: 100, B: 1000 });
  await t.engine.connect("A", t.users.A);
  await t.engine.message("A", { type: "create", name: "Sala", code: "ZZZZ", stakeCents: 200, mines: 3, isPublic: false });
  assert.match(t.lastError("A"), /Saldo insuficiente/);
  const t2 = setup({ A: 1000, B: 100 });
  await t2.engine.connect("A", t2.users.A);
  await t2.engine.connect("B", t2.users.B);
  await t2.engine.message("A", { type: "create", name: "Sala", code: "ZZZZ", stakeCents: 200, mines: 3, isPublic: false });
  await t2.engine.message("B", { type: "join", code: "ZZZZ" });
  assert.match(t2.lastError("B"), /Saldo insuficiente/);
});

test("validações: código repetido, minas fora do limite, valor fora do limite", async () => {
  const t = setup();
  await t.engine.connect("A", t.users.A);
  await t.engine.connect("B", t.users.B);
  await t.engine.message("A", { type: "create", name: "Sala", code: "AAAA", stakeCents: 200, mines: 11, isPublic: true });
  assert.match(t.lastError("A"), /1 a 10 minas/);
  await t.engine.message("A", { type: "create", name: "Sala", code: "AAAA", stakeCents: 5, mines: 3, isPublic: true });
  assert.match(t.lastError("A"), /valor/);
  await t.engine.message("A", { type: "create", name: "Sala", code: "AAAA", stakeCents: 200, mines: 3, isPublic: true });
  await t.engine.message("B", { type: "create", name: "Outra", code: "aaaa", stakeCents: 200, mines: 3, isPublic: true });
  assert.match(t.lastError("B"), /já está em uso/);
});

test("lista de salas mostra só as públicas e nunca vaza o código", async () => {
  const t = setup();
  await t.engine.connect("A", t.users.A);
  await t.engine.connect("B", t.users.B);
  await t.engine.message("A", { type: "create", name: "Publica", code: "PUB123", stakeCents: 200, mines: 4, isPublic: true });
  await t.engine.message("B", { type: "list" });
  const list = t.last("B", "rooms").list;
  assert.equal(list.length, 1);
  assert.equal(list[0].name, "Publica");
  assert.equal(list[0].mines, 4);
  assert.ok(!JSON.stringify(list).includes("PUB123"));
});

test("sair no checkout devolve o dinheiro de quem já pagou", async () => {
  const t = setup();
  const { engine, users, db } = t;
  await engine.connect("A", users.A);
  await engine.connect("B", users.B);
  await engine.message("A", { type: "create", name: "Sala", code: "CHK1", stakeCents: 200, mines: 3, isPublic: false });
  await engine.message("B", { type: "join", code: "CHK1" });
  await engine.message("A", { type: "confirm" });
  await engine.message("B", { type: "confirm" });
  await engine.message("A", { type: "pay" });
  assert.equal(db.profiles.A.balance_cents, 750);
  await engine.message("B", { type: "leave" });
  assert.equal(db.profiles.A.balance_cents, 1000);
  assert.equal(db.profiles.B.balance_cents, 1000);
  assert.equal(t.last("A", "room_closed").message.includes("devolvidos"), true);
});

test("tempo de pagamento esgotado devolve tudo", async () => {
  const t = setup({ A: 1000, B: 1000 }, { checkoutMs: 80 });
  const { engine, users, db, sleep } = t;
  await engine.connect("A", users.A);
  await engine.connect("B", users.B);
  await engine.message("A", { type: "create", name: "Sala", code: "TMO1", stakeCents: 200, mines: 3, isPublic: false });
  await engine.message("B", { type: "join", code: "TMO1" });
  await engine.message("A", { type: "confirm" });
  await engine.message("B", { type: "confirm" });
  await engine.message("A", { type: "pay" });
  await sleep(200);
  assert.equal(db.profiles.A.balance_cents, 1000);
  assert.equal(engine._rooms.size, 0);
});

test("abandonar durante a partida dá a vitória ao adversário", async () => {
  const t = setup();
  await toPlaying(t);
  const { engine, db, state } = t;
  await engine.message("A", { type: "leave" });
  assert.equal(state("B").status, "over");
  assert.equal(state("B").result.youWon, true);
  assert.equal(state("B").result.reason, "abandono");
  assert.equal(db.profiles.B.balance_cents, 1000 - 250 + 400);
});

test("cair a conexão e não voltar vale como abandono; voltar a tempo mantém a partida", async () => {
  const t = setup({ A: 1000, B: 1000 }, { graceMs: 120 });
  await toPlaying(t);
  const { engine, users, state, sleep } = t;
  engine.disconnect("A", users.A);
  await sleep(40);
  await engine.connect("A", (m) => t.inbox.A.push(m)); // voltou
  await sleep(150);
  assert.equal(state("B").status, "playing");
  const again = (m) => t.inbox.A.push(m);
  await engine.connect("A", again);
  engine.disconnect("A", again);
  await sleep(250);
  assert.equal(state("B").status, "over");
  assert.equal(state("B").result.reason, "abandono");
});

test("estourar o tempo da vez abre uma casa sozinho", async () => {
  const t = setup({ A: 1000, B: 1000 }, { turnMs: 80 });
  await toPlaying(t);
  const before = t.state("A").turn;
  await t.sleep(160);
  const s = t.state("A");
  assert.ok(s.status === "over" || s.turn !== before || s.myPicks.length + s.hitsOnMe.length > 0);
});

test("não é possível jogar fora da vez nem repetir casa", async () => {
  const t = setup();
  await toPlaying(t);
  const first = t.state("A").first;
  const second = first === "A" ? "B" : "A";
  await t.engine.message(second, { type: "pick", cell: 20 });
  assert.match(t.lastError(second), /sua vez/);
  await t.engine.message(first, { type: "pick", cell: 20 });
  await t.engine.message(second, { type: "pick", cell: 20 });
  await t.engine.message(first, { type: "pick", cell: 20 });
  assert.match(t.lastError(first), /já foi aberta/);
});

test("revanche cobra de novo e recomeça", async () => {
  const t = setup();
  await toPlaying(t);
  const { engine, state, db } = t;
  const first = state("A").first;
  const second = first === "A" ? "B" : "A";
  const firstMines = first === "A" ? [0, 1, 2] : [3, 4, 5];
  await engine.message(first, { type: "pick", cell: 20 });
  await engine.message(second, { type: "pick", cell: firstMines[0] });
  assert.equal(state(first).status, "over");
  await engine.message("A", { type: "rematch" });
  assert.equal(state("B").rematch.opp, true);
  await engine.message("B", { type: "rematch" });
  assert.equal(state("A").status, "checkout");
  await engine.message("A", { type: "pay" });
  await engine.message("B", { type: "pay" });
  assert.equal(state("A").status, "placing");
  assert.ok(Object.values(db.matches).length === 2);
});

test("não existe mais saldo de teste: grant_test é ignorado", async () => {
  const t = setup({ A: 0, B: 0 });
  await t.engine.connect("A", t.users.A);
  await t.engine.message("A", { type: "grant_test" });
  assert.equal(t.db.profiles.A.balance_cents, 0);
  assert.equal(t.last("A", "hello").testMode, undefined);
});

test("depósito: mínimo R$ 10 e nunca credita sem gateway", async () => {
  const t = setup({ A: 0, B: 0 });
  await t.engine.connect("A", t.users.A);
  assert.equal(t.last("A", "hello").minDepositCents, 1000);
  await t.engine.message("A", { type: "deposit", cents: 999 });
  assert.match(t.lastError("A"), /mínimo/);
  await t.engine.message("A", { type: "deposit", cents: "abc" });
  assert.match(t.lastError("A"), /mínimo/);
  await t.engine.message("A", { type: "deposit", cents: 1000 });
  assert.match(t.lastError("A"), /em breve/);
  assert.equal(t.db.profiles.A.balance_cents, 0);
});

test("quem não completou o perfil não entra", async () => {
  const t = setup();
  t.db.profiles.A.profile_done = false;
  const ok = await t.engine.connect("A", t.users.A);
  assert.equal(ok, false);
  assert.match(t.lastError("A"), /perfil/);
});

test("sala pública abre pelo id da lista (sem código); privada não", async () => {
  const t = setup({ A: 1000, B: 1000, C: 1000 });
  await t.engine.connect("A", t.users.A);
  await t.engine.connect("B", t.users.B);
  await t.engine.connect("C", t.users.C);
  await t.engine.message("A", { type: "create", name: "Publica", code: "PUB123", stakeCents: 200, mines: 4, isPublic: true });
  await t.engine.message("C", { type: "create", name: "Privada", code: "PRIV1", stakeCents: 200, mines: 4, isPublic: false });
  await t.engine.message("B", { type: "list" });
  const pub = t.last("B", "rooms").list[0];
  await t.engine.message("B", { type: "join_info", id: pub.id });
  assert.equal(t.last("B", "room_info").name, "Publica");
  await t.engine.message("B", { type: "join", id: pub.id });
  assert.equal(t.state("B").status, "lobby");
  // a sala privada tem id também, mas não pode ser aberta por ele
  const privId = t.state("C").id;
  const t2 = setup({ A: 1000, B: 1000 });
  await t2.engine.connect("A", t2.users.A);
  await t2.engine.connect("B", t2.users.B);
  await t2.engine.message("A", { type: "create", name: "Privada", code: "PRIV1", stakeCents: 200, mines: 4, isPublic: false });
  await t2.engine.message("B", { type: "join_info", id: t2.state("A").id });
  assert.ok(t2.lastError("B"));
  assert.ok(privId);
});

test("conta banida não conecta nem recebe estado do jogo", async () => {
  const t = setup();
  t.db.profiles.A.banned = true;
  const ok = await t.engine.connect("A", t.users.A);
  assert.equal(ok, false);
  assert.match(t.lastError("A"), /bloqueada/);
});

test("limite de criação evita consulta e salas infinitas", async () => {
  const t = setup({ A: 10000 });
  await t.engine.connect("A", t.users.A);
  for (let i = 0; i < 6; i++) {
    await t.engine.message("A", { type: "create", name: "Sala boa", code: "RATE" + i, stakeCents: 200, mines: 3 });
    await t.engine.message("A", { type: "leave" });
  }
  assert.match(t.lastError("A"), /Aguarde/);
});

test("nome de sala remove controles invisíveis", async () => {
  const t = setup();
  await t.engine.connect("A", t.users.A);
  await t.engine.message("A", { type: "create", name: "  Sala\u202E   limpa ", code: "LIMPA", stakeCents: 200, mines: 3 });
  assert.equal(t.state("A").name, "Sala limpa");
});


test("finish_match falhando 3x marca atenção e dispara alerta", async () => {
  const t = setup();
  await toPlaying(t);
  const matchId = t.state("A").id && Object.keys(t.db.matches)[0];
  const mid = Object.keys(t.db.matches)[0];
  t.db.matches[mid]._failFinish = true;
  const first = t.state("A").first;
  const opp = first === "A" ? "B" : "A";
  // acerta mina do adversário → finish
  await t.engine.message(first, { type: "pick", cell: 0 }); // mines A default [0,1,2] if first is B picking A's board
  // Ensure we force finish: pick a known mine on opponent board
  // toPlaying places mines A=[0,1,2] B=[3,4,5]. Whoever is first picks on opp board.
  // If already finished from cell 0, good; else pick until over.
  let guard = 0;
  while (t.state("A").status === "playing" && guard++ < 10) {
    const turn = t.state("A").turn;
    const target = turn === "A" ? 3 : 0;
    await t.engine.message(turn, { type: "pick", cell: target });
  }
  assert.equal(t.state("A").status, "over");
  assert.equal(t.db.matches[mid].attention_required, true);
  assert.ok(t.db.alerts.some((a) => a.kind === "settlement_failed"));
});

test("mesmo par acima do limite por hora é bloqueado", async () => {
  const t = setup({ A: 50000, B: 50000 }, { pairPerHour: 2 });
  await t.engine.connect("A", t.users.A);
  await t.engine.connect("B", t.users.B);
  for (let i = 0; i < 2; i++) {
    await t.engine.message("A", { type: "create", name: "Sala", code: "PAIR" + i, stakeCents: 200, mines: 3 });
    await t.engine.message("B", { type: "join", code: "PAIR" + i });
    await t.engine.message("A", { type: "confirm" });
    await t.engine.message("B", { type: "confirm" });
    // cancela saindo no checkout
    await t.engine.message("A", { type: "leave" });
    await t.engine.message("B", { type: "leave" });
  }
  await t.engine.message("A", { type: "create", name: "Sala", code: "PAIRX", stakeCents: 200, mines: 3 });
  await t.engine.message("B", { type: "join", code: "PAIRX" });
  await t.engine.message("A", { type: "confirm" });
  await t.engine.message("B", { type: "confirm" });
  assert.match(t.lastError("A") || t.lastError("B") || "", /juntos|Aguarde|demais/i);
});
