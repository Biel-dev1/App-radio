import test from "node:test";
import assert from "node:assert/strict";
import { createEngine } from "./engine.js";
import { readFileSync } from "node:fs";

// Mesmo banco de mentira do engine.test.js (reduzido ao necessário)
function fakeDb(balances) {
  const profiles = {};
  for (const [id, bal] of Object.entries(balances)) {
    profiles[id] = { id, display_name: "J-" + id, avatar_url: "", balance_cents: bal, profile_done: true, terms_version: "1.0" };
  }
  const matches = {}; let seq = 0;
  return {
    profiles, matches,
    profile: async (id) => profiles[id] || null,
    createMatch: async (code, p1, p2, stake, fee) => { const id = "m" + ++seq; matches[id] = { id, p1, p2, stake, fee, paid: {}, status: "pending" }; return id; },
    checkPin: async () => "ok",
    payMatch: async (id, uid) => {
      const m = matches[id];
      if (profiles[uid].balance_cents < m.stake + m.fee) throw new Error("sem saldo");
      profiles[uid].balance_cents -= m.stake + m.fee; m.paid[uid] = true;
      if (m.paid[m.p1] && m.paid[m.p2]) m.status = "paid";
    },
    finishMatch: async (id, winner) => { const m = matches[id]; if (m.status === "finished") return; profiles[winner].balance_cents += m.stake * 2; m.status = "finished"; m.winner = winner; },
    refundMatch: async (id) => { const m = matches[id]; for (const u of [m.p1, m.p2]) if (m.paid[u]) profiles[u].balance_cents += m.stake + m.fee; m.status = "refunded"; },
    recover: async () => 0, touchMatch: async () => {}, flagMatch: async () => {},
  };
}
const fast = { houseBotThinkMs: 20, houseBotJitterMs: 20, turnMs: 300, animMs: 10, placeMs: 3000, checkoutMs: 2000, graceMs: 200, feePercent: 25, houseBotUids: ["BOT"], houseBotWaitMs: 30 };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function setup(balances) {
  const db = fakeDb(balances);
  const engine = createEngine({ db, cfg: fast });
  const inbox = { U: [] };
  const send = (m) => inbox.U.push(m);
  const last = (type) => [...inbox.U].reverse().find((m) => m.type === type);
  return { db, engine, inbox, send, last, state: () => last("state")?.room };
}

test("sem humano na fila, o bot (identificado) entra e paga a entrada com o saldo da casa", async () => {
  const t = setup({ U: 1000, BOT: 5000 });
  await t.engine.connect("U", t.send);
  await t.engine.message("U", { type: "find_match", stakeCents: 200, mines: 3 });
  assert.ok(t.last("matchmaking_searching"));
  await sleep(120);
  const st = t.state();
  assert.equal(st.status, "checkout");
  const bot = st.players.find((p) => p.id === "BOT");
  assert.equal(bot.bot, true);
  assert.match(bot.name, /bot|robô/i);
  assert.equal(bot.paid, true);
  assert.equal(t.db.profiles.BOT.balance_cents, 5000 - 250); // entrada + taxa saíram da casa
  assert.equal(t.db.profiles.U.balance_cents, 1000);          // jogador só paga no checkout
});

test("casa sem saldo: o bot NÃO entra e nada é cobrado do jogador", async () => {
  const t = setup({ U: 1000, BOT: 100 });
  await t.engine.connect("U", t.send);
  await t.engine.message("U", { type: "find_match", stakeCents: 200, mines: 3 });
  await sleep(120);
  assert.equal(t.state(), undefined);                // nenhuma partida criada
  assert.equal(Object.keys(t.db.matches).length, 0);
  assert.equal(t.db.profiles.U.balance_cents, 1000);
  assert.equal(t.db.profiles.BOT.balance_cents, 100);
});

test("humano que entra na fila antes do bot cancela a oferta do bot", async () => {
  const t = setup({ U: 1000, V: 1000, BOT: 5000 });
  const inboxV = []; 
  await t.engine.connect("U", t.send);
  await t.engine.connect("V", (m) => inboxV.push(m));
  await t.engine.message("U", { type: "find_match", stakeCents: 200, mines: 3 });
  await t.engine.message("V", { type: "find_match", stakeCents: 200, mines: 3 });
  await sleep(120);
  assert.deepEqual(t.state().players.map((p) => p.id).sort(), ["U", "V"]);
  assert.equal(t.db.profiles.BOT.balance_cents, 5000);
});

test("cancelar a busca cancela o bot", async () => {
  const t = setup({ U: 1000, BOT: 5000 });
  await t.engine.connect("U", t.send);
  await t.engine.message("U", { type: "find_match", stakeCents: 200, mines: 3 });
  await t.engine.message("U", { type: "cancel_match" });
  await sleep(120);
  assert.equal(Object.keys(t.db.matches).length, 0);
});

async function playOne(t) {
  await t.engine.connect("U", t.send);
  await t.engine.message("U", { type: "find_match", stakeCents: 200, mines: 3 });
  await sleep(100);
  await t.engine.message("U", { type: "pay", pin: "123456" });
  await t.engine.message("U", { type: "place_mines", cells: [0, 1, 2] });
  // espera o bot posicionar e a partida começar; depois o jogador abre casas até acabar
  for (let i = 0; i < 400 && t.state()?.status !== "over"; i++) {
    const st = t.state();
    if (st?.status === "playing" && st.turn === "U") {
      const free = [...Array(25).keys()].find((c) => !st.myPicks.includes(c));
      await t.engine.message("U", { type: "pick", cell: free });
    }
    await sleep(15);
  }
  return t.state();
}

test("partida completa contra o bot termina e liquida no banco (quem ganha leva 2x)", async () => {
  const t = setup({ U: 1000, BOT: 5000 });
  const st = await playOne(t);
  assert.equal(st.status, "over");
  const m = Object.values(t.db.matches)[0];
  assert.equal(m.status, "finished");
  assert.ok(["U", "BOT"].includes(m.winner));
  assert.equal(t.db.profiles.U.balance_cents + t.db.profiles.BOT.balance_cents, 6000 - 2 * 50); // só a taxa sai do total
});

test("sem revanche contra o bot", async () => {
  const t = setup({ U: 1000, BOT: 5000 });
  await playOne(t);
  await t.engine.message("U", { type: "rematch" });
  assert.match(t.last("error").message, /bot/i);
});

test("justiça: ~50% de vitória do jogador (sorteio real, sem manipulação)", async () => {
  let wins = 0; const N = 100;
  for (let i = 0; i < N; i++) {
    const db = fakeDb({ U: 100000, BOT: 100000 });
    const engine = createEngine({ db, cfg: { ...fast, houseBotWaitMs: 1, turnMs: 20, animMs: 1, houseBotThinkMs: 1, houseBotJitterMs: 3 } });
    const box = []; const send = (m) => box.push(m);
    await engine.connect("U", send);
    await engine.message("U", { type: "find_match", stakeCents: 200, mines: 3 });
    await sleep(15);
    await engine.message("U", { type: "pay", pin: "123456" });
    await engine.message("U", { type: "place_mines", cells: [0, 1, 2] });
    for (let k = 0; k < 600; k++) {
      const st = [...box].reverse().find((m) => m.type === "state")?.room;
      if (st?.status === "over") break;
      if (st?.status === "playing" && st.turn === "U") {
        const c = [...Array(25).keys()].find((x) => !st.myPicks.includes(x));
        await engine.message("U", { type: "pick", cell: c });
      }
      await sleep(3);
    }
    const m = Object.values(db.matches)[0];
    if (m && m.winner === "U") wins++;
  }
  const rate = wins / N;
  assert.ok(rate > 0.3 && rate < 0.7, `taxa de vitória fora do esperado: ${rate}`);
});

test("o bot nunca lê as minas do jogador (código do botPick só usa casas fechadas)", () => {
  const src = readFileSync(new URL("./engine.js", import.meta.url), "utf8");
  const fn = src.slice(src.indexOf("async function botPick"), src.indexOf("// ----", src.indexOf("async function botPick")));
  assert.ok(!/boards/.test(fn.replace(/\/\/.*$/gm, "")), "botPick não pode acessar room.boards");
});
