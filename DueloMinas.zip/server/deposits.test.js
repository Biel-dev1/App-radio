import { test } from "node:test";
import assert from "node:assert/strict";
import { confirmDeposit, reconcilePending } from "./deposits.js";

const silent = { error() {}, log() {} };

function fakeDb(rows = {}) {
  const credits = [];
  const audits = [];
  return {
    credits, audits,
    async getDeposit(id) { return rows[id] ? { ...rows[id] } : null; },
    async creditDeposit(uid, cents, id) {
      credits.push({ uid, cents, id });
      return { ok: true, duplicate: false };
    },
    async markDepositCredited(id) { if (rows[id]) rows[id].status = "credited"; },
    async pendingDepositsOlderThan() { return Object.keys(rows).filter((k) => rows[k].status === "pending").map((identifier) => ({ identifier })); },
    async audit(action, target, detail) { audits.push({ action, target, detail }); },
  };
}

function fakeSyncPay(txs = {}) {
  return {
    enabled: true,
    async getTransaction(id) { return txs[id] === undefined ? null : txs[id]; },
  };
}

const UID = "11111111-1111-1111-1111-111111111111";

test("depósito desconhecido não credita", async () => {
  const db = fakeDb({});
  const r = await confirmDeposit("x", { db, syncpay: fakeSyncPay(), log: silent });
  assert.equal(r.reason, "unknown");
  assert.equal(db.credits.length, 0);
});

test("webhook forjado com valor maior é ignorado: crédito usa o valor pedido e a SyncPay", async () => {
  // Pedido de R$ 10,00. Alguém manda webhook dizendo R$ 5.000 — o código nem olha o corpo.
  const db = fakeDb({ id1: { user_id: UID, cents: 1000, status: "pending" } });
  const sp = fakeSyncPay({ id1: { status: "completed", amountReais: 10 } });
  const r = await confirmDeposit("id1", { db, syncpay: sp, log: silent });
  assert.equal(r.reason, "credited");
  assert.deepEqual(db.credits, [{ uid: UID, cents: 1000, id: "id1" }]);
});

test("SyncPay diz que ainda está pendente: não credita", async () => {
  const db = fakeDb({ id2: { user_id: UID, cents: 1000, status: "pending" } });
  const r = await confirmDeposit("id2", { db, syncpay: fakeSyncPay({ id2: { status: "pending", amountReais: 10 } }), log: silent });
  assert.equal(r.reason, "status:pending");
  assert.equal(db.credits.length, 0);
});

test("valor divergente na SyncPay: não credita e registra auditoria", async () => {
  const db = fakeDb({ id3: { user_id: UID, cents: 1000, status: "pending" } });
  const r = await confirmDeposit("id3", { db, syncpay: fakeSyncPay({ id3: { status: "completed", amountReais: 50 } }), log: silent });
  assert.equal(r.reason, "amount_mismatch");
  assert.equal(db.credits.length, 0);
  assert.equal(db.audits[0].action, "deposit_amount_mismatch");
});

test("transação inexistente na SyncPay: não credita", async () => {
  const db = fakeDb({ id4: { user_id: UID, cents: 1000, status: "pending" } });
  const r = await confirmDeposit("id4", { db, syncpay: fakeSyncPay({}), log: silent });
  assert.equal(r.reason, "not_found");
});

test("confirmação repetida não credita duas vezes", async () => {
  const db = fakeDb({ id5: { user_id: UID, cents: 1000, status: "pending" } });
  const sp = fakeSyncPay({ id5: { status: "completed", amountReais: 10 } });
  await confirmDeposit("id5", { db, syncpay: sp, log: silent });
  const second = await confirmDeposit("id5", { db, syncpay: sp, log: silent });
  assert.equal(second.reason, "already");
  assert.equal(db.credits.length, 1);
});

test("reconciliação credita pagamento cujo webhook nunca chegou", async () => {
  const db = fakeDb({ id6: { user_id: UID, cents: 2500, status: "pending" } });
  const sp = fakeSyncPay({ id6: { status: "completed", amountReais: 25 } });
  const r = await reconcilePending({ db, syncpay: sp, log: silent });
  assert.deepEqual(r, { checked: 1, credited: 1 });
  assert.equal(db.credits[0].cents, 2500);
});

test("reconciliação sem SyncPay configurada não faz nada", async () => {
  const db = fakeDb({ id7: { user_id: UID, cents: 1000, status: "pending" } });
  const r = await reconcilePending({ db, syncpay: { enabled: false }, log: silent });
  assert.deepEqual(r, { checked: 0 });
});
