import { test } from "node:test";
import assert from "node:assert/strict";
import { confirmDeposit, reconcilePending } from "./deposits.js";

const silent = { error() {}, log() {} };

function fakeDb(rows = {}) {
  const credits = [];
  const audits = [];
  return {
    credits, audits,
    async getDeposit(id) { return rows[id] ? { ...rows[id] } : null; },
    async creditDeposit(uid, cents, id) {
      credits.push({ uid, cents, id });
      return { ok: true, duplicate: false };
    },
    async markDepositCredited(id) { if (rows[id]) rows[id].status = "credited"; },
    async pendingDepositsOlderThan() { return Object.keys(rows).filter((k) => rows[k].status === "pending").map((identifier) => ({ identifier })); },
    async audit(action, target, detail) { audits.push({ action, target, detail }); },
  };
}

function fakeSyntraPay(txs = {}) {
  return {
    enabled: true,
    async getTransaction(id) { return txs[id] === undefined ? null : txs[id]; },
  };
}

const UID = "11111111-1111-1111-1111-111111111111";

test("depósito desconhecido não credita", async () => {
  const db = fakeDb({});
  const r = await confirmDeposit("x", { db, syncpay: fakeSyntraPay(), log: silent });
  assert.equal(r.reason, "unknown");
  assert.equal(db.credits.length, 0);
});

test("webhook forjado com valor maior é ignorado: crédito usa o valor pedido e a SyntraPay", async () => {
  // Pedido de R$ 10,00. Alguém manda webhook dizendo R$ 5.000 — o código nem olha o corpo.
  const db = fakeDb({ id1: { user_id: UID, cents: 1000, status: "pending" } });
  const sp = fakeSyntraPay({ id1: { status: "completed", amountCents: 1000 } });
  const r = await confirmDeposit("id1", { db, syncpay: sp, log: silent });
  assert.equal(r.reason, "credited");
  assert.deepEqual(db.credits, [{ uid: UID, cents: 1000, id: "id1" }]);
});

test("SyntraPay diz que ainda está pendente: não credita", async () => {
  const db = fakeDb({ id2: { user_id: UID, cents: 1000, status: "pending" } });
  const r = await confirmDeposit("id2", { db, syncpay: fakeSyntraPay({ id2: { status: "pending", amountCents: 1000 } }), log: silent });
  assert.equal(r.reason, "status:pending");
  assert.equal(db.credits.length, 0);
});

test("valor divergente na SyntraPay: não credita e registra auditoria", async () => {
  const db = fakeDb({ id3: { user_id: UID, cents: 1000, status: "pending" } });
  const r = await confirmDeposit("id3", { db, syncpay: fakeSyntraPay({ id3: { status: "completed", amountCents: 5000 } }), log: silent });
  assert.equal(r.reason, "amount_mismatch");
  assert.equal(db.credits.length, 0);
  assert.equal(db.audits[0].action, "deposit_amount_mismatch");
});

test("transação inexistente na SyntraPay: não credita", async () => {
  const db = fakeDb({ id4: { user_id: UID, cents: 1000, status: "pending" } });
  const r = await confirmDeposit("id4", { db, syncpay: fakeSyntraPay({}), log: silent });
  assert.equal(r.reason, "not_found");
});

test("confirmação repetida não credita duas vezes", async () => {
  const db = fakeDb({ id5: { user_id: UID, cents: 1000, status: "pending" } });
  const sp = fakeSyntraPay({ id5: { status: "completed", amountCents: 1000 } });
  await confirmDeposit("id5", { db, syncpay: sp, log: silent });
  const second = await confirmDeposit("id5", { db, syncpay: sp, log: silent });
  assert.equal(second.reason, "already");
  assert.equal(db.credits.length, 1);
});

test("reconciliação credita pagamento cujo webhook nunca chegou", async () => {
  const db = fakeDb({ id6: { user_id: UID, cents: 2500, status: "pending" } });
  const sp = fakeSyntraPay({ id6: { status: "completed", amountCents: 2500 } });
  const r = await reconcilePending({ db, syncpay: sp, log: silent });
  assert.deepEqual(r, { checked: 1, credited: 1 });
  assert.equal(db.credits[0].cents, 2500);
});

test("reconciliação sem SyntraPay configurada não faz nada", async () => {
  const db = fakeDb({ id7: { user_id: UID, cents: 1000, status: "pending" } });
  const r = await reconcilePending({ db, syncpay: { enabled: false }, log: silent });
  assert.deepEqual(r, { checked: 0 });
});

test("crédito avisa o app via notify", async () => {
  const db = fakeDb({ id8: { user_id: UID, cents: 1000, status: "pending" } });
  const sp = fakeSyntraPay({ id8: { status: "completed", amountCents: 1000 } });
  const sent = [];
  await confirmDeposit("id8", { db, syncpay: sp, log: silent, notify: (uid, msg) => sent.push({ uid, msg }) });
  assert.deepEqual(sent, [{ uid: UID, msg: { type: "deposit_status", identifier: "id8", status: "credited", cents: 1000 } }]);
});

test("jogador cancelou mas pagou mesmo assim: ainda credita", async () => {
  const db = fakeDb({ id9: { user_id: UID, cents: 1000, status: "cancelled" } });
  const sp = fakeSyntraPay({ id9: { status: "completed", amountCents: 1000 } });
  const r = await confirmDeposit("id9", { db, syncpay: sp, log: silent });
  assert.equal(r.reason, "credited");
  assert.equal(db.credits.length, 1);
});

test("cancelado e ainda não pago: não credita", async () => {
  const db = fakeDb({ id10: { user_id: UID, cents: 1000, status: "cancelled" } });
  const r = await confirmDeposit("id10", { db, syncpay: fakeSyntraPay({ id10: { status: "pending", amountCents: 1000 } }), log: silent });
  assert.equal(r.reason, "status:pending");
  assert.equal(db.credits.length, 0);
});

test("falha ao avisar o app não desfaz o crédito", async () => {
  const db = fakeDb({ id11: { user_id: UID, cents: 1000, status: "pending" } });
  const sp = fakeSyntraPay({ id11: { status: "completed", amountCents: 1000 } });
  const r = await confirmDeposit("id11", { db, syncpay: sp, log: silent, notify: () => { throw new Error("socket fechado"); } });
  assert.equal(r.reason, "credited");
  assert.equal(db.credits.length, 1);
});

test("cobrança vencida na SyntraPay sai da fila (status failed) e não credita", async () => {
  const db = fakeDb({ id12: { user_id: UID, cents: 1000, status: "pending" } });
  db.failed = [];
  db.markDepositFailed = async (id) => { db.failed.push(id); };
  const r = await confirmDeposit("id12", { db, syncpay: fakeSyntraPay({ id12: { status: "expired", amountCents: 1000 } }), log: silent });
  assert.equal(r.reason, "status:expired");
  assert.deepEqual(db.failed, ["id12"]);
  assert.equal(db.credits.length, 0);
});
