import { test } from "node:test";
import assert from "node:assert/strict";
import { createDb } from "./supabase.js";

// Simula o PostgREST: RPC com unique violation responde 409 com code 23505.
test("creditDeposit trata unique violation (23505) como já creditado", async () => {
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, opts) => {
    if (String(url).includes("/rpc/move_balance")) {
      return new Response(JSON.stringify({ code: "23505", message: "duplicate key value violates unique constraint" }),
        { status: 409, headers: { "content-type": "application/json" } });
    }
    return new Response("", { status: 201 });
  };
  try {
    const db = createDb({ url: "https://x.supabase.co", key: "sb_secret_test", alertWebhookUrl: "" });
    const r = await db.creditDeposit("11111111-1111-1111-1111-111111111111", 1000, "id-dup");
    assert.deepEqual(r, { ok: true, balance: null, duplicate: true });
  } finally {
    globalThis.fetch = realFetch;
  }
});

test("erro qualquer do banco continua propagando (não vira 'duplicado')", async () => {
  const realFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({ code: "42501", message: "permission denied" }),
    { status: 403, headers: { "content-type": "application/json" } });
  try {
    const db = createDb({ url: "https://x.supabase.co", key: "sb_secret_test", alertWebhookUrl: "" });
    await assert.rejects(db.creditDeposit("11111111-1111-1111-1111-111111111111", 1000, "id-x"));
  } finally {
    globalThis.fetch = realFetch;
  }
});
