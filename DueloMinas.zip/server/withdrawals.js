// Saques automáticos via SyntraPay.
// Fluxo: jogador pede (request_withdrawal debita e cria 'pending') -> aqui reservamos ('approved'),
// mandamos à SyntraPay e guardamos o id (provider_id). O webhook/consulta fecha como 'paid'
// ou devolve o dinheiro (cancel_withdrawal). Se não der para saber se foi enviado, NUNCA devolvemos
// o saldo: repetimos com a mesma Idempotency-Key (a SyntraPay não paga duas vezes) e alertamos.
import { isPaidStatus, isFailedStatus, normalizePixKey } from "./syntrapay.js";

const RETRY_AFTER_MS = 2 * 60_000;
const GIVE_UP_AFTER_MS = 20 * 3600_000; // a idempotência da SyntraPay vale 24 h

async function send(w, { db, pay, log, notify }) {
  const key = normalizePixKey(w.pix_type, w.pix_key);
  try {
    const r = await pay.cashOut({ amountCents: Number(w.amount_cents), pixKey: key, idempotencyKey: `wd-${w.id}` });
    await db.setWithdrawalProvider(w.id, r.id);
    await db.audit("withdraw_sent", w.user_id, { withdrawal_id: w.id, provider_id: r.id });
    return "sent";
  } catch (e) {
    const msg = String(e && e.message || e).slice(0, 200);
    if (e && e.definite) {
      await db.cancelWithdrawal(w.id, `recusado: ${msg}`);          // devolve o saldo
      await db.setWithdrawalError(w.id, msg);
      await db.alert("withdraw_rejected", { withdrawal_id: w.id, reason: msg });
      if (notify) { try { notify(w.user_id, { type: "profile_updated" }); } catch { /* ignore */ } }
      return "rejected";
    }
    await db.setWithdrawalError(w.id, msg);                         // incerto: tenta de novo depois
    log.error("withdraw retry later", w.id, msg);
    return "retry";
  }
}

export async function processWithdrawals(ctx) {
  const { db, pay, log = console } = ctx;
  if (!pay.enabled) return { claimed: 0 };
  let n = 0;
  for (const w of await db.listPendingWithdrawals(5)) {
    if (await db.claimWithdrawal(w.id)) { n++; await send(w, ctx); }
  }
  const cutoff = new Date(Date.now() - RETRY_AFTER_MS).toISOString();
  for (const w of await db.listStuckWithdrawals(cutoff, 5)) {
    const age = Date.now() - new Date(w.created_at).getTime();
    if (age > GIVE_UP_AFTER_MS) {
      await db.alert("withdraw_needs_manual_review", { withdrawal_id: w.id });
      await db.touchWithdrawal(w.id);
      continue;
    }
    await db.touchWithdrawal(w.id);
    n++;
    await send(w, ctx);
  }
  log.log && n && log.log("saques processados:", n);
  return { claimed: n };
}

/** Fecha um saque conferindo o status direto na SyntraPay (nunca confia no corpo do webhook). */
export async function settleWithdrawal(providerId, { db, pay, log = console, notify = null }) {
  const w = await db.getWithdrawalByProvider(providerId);
  if (!w) return { ok: false, reason: "unknown" };
  if (w.status === "paid" || w.status === "rejected") return { ok: true, reason: "already" };
  const tx = await pay.getWithdrawal(providerId);
  if (!tx) return { ok: false, reason: "not_found" };
  if (isPaidStatus(tx.status)) {
    await db.markWithdrawalPaid(w.id);
    await db.audit("withdraw_paid", w.user_id, { withdrawal_id: w.id });
    return { ok: true, reason: "paid" };
  }
  if (isFailedStatus(tx.status)) {
    await db.cancelWithdrawal(w.id, `falhou na SyntraPay: ${tx.status}`);
    await db.alert("withdraw_failed", { withdrawal_id: w.id, status: tx.status });
    if (notify) { try { notify(w.user_id, { type: "profile_updated" }); } catch (e) { log.error("notify", e && e.message); } }
    return { ok: true, reason: "refunded" };
  }
  return { ok: false, reason: `status:${tx.status}` };
}

export async function reconcileWithdrawals(ctx) {
  const { db, pay, log = console } = ctx;
  if (!pay.enabled) return { checked: 0 };
  const rows = await db.listApprovedWithProvider(20);
  for (const w of rows) {
    try { await settleWithdrawal(w.provider_id, ctx); } catch (e) { log.error("reconcile saque", w.id, e && e.message); }
  }
  return { checked: rows.length };
}
