// Conversa com o Supabase usando a chave SECRETA (fica só no servidor, nunca no app).
export function createDb({ url, key, alertWebhookUrl = process.env.ALERT_WEBHOOK_URL || "" }) {
  const base = url.replace(/\/$/, "");
  const headers = (extra = {}) => ({
    apikey: key,
    ...(key.startsWith("eyJ") ? { Authorization: `Bearer ${key}` } : {}),
    "content-type": "application/json",
    ...extra,
  });

  async function rest(method, path, body, extra) {
    const r = await fetch(base + path, {
      method,
      headers: headers(extra),
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await r.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* resposta vazia */ }
    if (!r.ok) {
      // Nunca propague detalhes do PostgREST/Supabase ao cliente. O chamador só
      // recebe userMessage quando ele foi definido explicitamente por uma função SQL.
      const e = new Error(`Supabase request failed (${r.status})`);
      // código SQLSTATE (ex.: 23505 = unique violation) é seguro de checar, não é detalhe do banco
      if (json && json.code) e.code = String(json.code);
      // mensagens que escrevemos no banco (raise exception) são seguras de mostrar ao jogador
      if (json && json.code === "P0001") e.userMessage = json.message;
      throw e;
    }
    return json;
  }

  return {
    async userFromToken(token) {
      const r = await fetch(base + "/auth/v1/user", {
        headers: { apikey: key, Authorization: `Bearer ${token}` },
      });
      if (!r.ok) return null;
      const u = await r.json();
      if (!u || !u.id) return null;
      return { id: u.id, email: u.email || "" };
    },
    async profile(uid) {
      const rows = await rest("GET",
        `/rest/v1/profiles?select=id,display_name,avatar_url,balance_cents,profile_done,terms_version,verified,banned&id=eq.${encodeURIComponent(uid)}`);
      return rows && rows[0] ? rows[0] : null;
    },
    async createMatch(roomCode, p1, p2, stake, fee) {
      const rows = await rest("POST", "/rest/v1/matches",
        { room_code: roomCode, p1, p2, stake_cents: stake, fee_cents: fee },
        { Prefer: "return=representation" });
      return rows[0].id;
    },
    // Credita depósito de forma idempotente via move_balance (ref único no ledger).
    async creditDeposit(userId, amountCents, providerId) {
      const ref = `syncpay:${providerId}`;
      try {
        const novo = await rest("POST", "/rest/v1/rpc/move_balance", {
          p_user: userId,
          p_type: "deposit",
          p_amount: amountCents,
          p_ref: ref,
        });
        try {
          await rest("POST", "/rest/v1/security_audit", {
            action: "deposit",
            target_id: userId,
            detail: { provider: "syncpay", provider_id: providerId, amount_cents: amountCents },
          });
        } catch (_) { /* audit opcional */ }
        return { ok: true, balance: novo, duplicate: false };
      } catch (e) {
        // unique violation = já creditado
        const msg = String(e && e.message || e);
        if ((e && e.code === "23505") || /23505|duplicate|unique/i.test(msg)) {
          return { ok: true, balance: null, duplicate: true };
        }
        throw e;
      }
    },
    // Depósitos pendentes ficam no banco (sobrevivem a reinício do Render).
    async createDeposit(identifier, userId, cents) {
      await rest("POST", "/rest/v1/deposits", { identifier, user_id: userId, cents, status: "pending" },
        { Prefer: "return=minimal" });
    },
    async getDeposit(identifier) {
      const rows = await rest("GET",
        `/rest/v1/deposits?select=identifier,user_id,cents,status&identifier=eq.${encodeURIComponent(identifier)}`);
      return rows && rows[0] ? rows[0] : null;
    },
    async markDepositCredited(identifier) {
      await rest("PATCH",
        `/rest/v1/deposits?identifier=eq.${encodeURIComponent(identifier)}`,
        { status: "credited", credited_at: new Date().toISOString() },
        { Prefer: "return=minimal" });
    },
    // Inclui 'cancelled': se o jogador desistiu e pagou mesmo assim, ainda precisamos creditar.
    async pendingDepositsOlderThan(isoCutoff) {
      const rows = await rest("GET",
        `/rest/v1/deposits?select=identifier&status=in.(pending,cancelled)&created_at=lt.${encodeURIComponent(isoCutoff)}&limit=50`);
      return rows || [];
    },
    // Só cancela depósito do próprio jogador que ainda está pendente. Retorna true se cancelou.
    async cancelDeposit(identifier, userId) {
      const rows = await rest("PATCH",
        `/rest/v1/deposits?identifier=eq.${encodeURIComponent(identifier)}&user_id=eq.${encodeURIComponent(userId)}&status=eq.pending`,
        { status: "cancelled" },
        { Prefer: "return=representation" });
      return Array.isArray(rows) && rows.length > 0;
    },
    async audit(action, targetId, detail) {
      try {
        await rest("POST", "/rest/v1/security_audit",
          { action, target_id: targetId || null, detail: detail || {} }, { Prefer: "return=minimal" });
      } catch (_) { /* auditoria não pode derrubar o fluxo */ }
    },
    verifyUserPin: (uid, pin) => rest("POST", "/rest/v1/rpc/verify_user_pin", { p_user: uid, p_pin: pin }),
    requestWithdrawal: (uid, amountCents, pixType, pixKey, pin) => rest("POST", "/rest/v1/rpc/request_withdrawal", { p_user: uid, p_amount: amountCents, p_pix_type: pixType, p_pix_key: pixKey, p_pin: pin }),
    payMatch: (matchId, uid) => rest("POST", "/rest/v1/rpc/pay_match", { p_match: matchId, p_user: uid }),
    finishMatch: (matchId, winner) => rest("POST", "/rest/v1/rpc/finish_match", { p_match: matchId, p_winner: winner }),
    refundMatch: (matchId) => rest("POST", "/rest/v1/rpc/refund_match", { p_match: matchId }),
    touchMatch: (matchId, instanceId) => rest("POST", "/rest/v1/rpc/touch_match", { p_match: matchId, p_instance: instanceId }),
    recover: (instanceId, staleBefore) => rest("POST", "/rest/v1/rpc/recover_matches", { p_instance: instanceId, p_stale_before: staleBefore }),
    markSettlementAttention: (matchId, detail) => rest("POST", "/rest/v1/rpc/mark_match_attention", { p_match: matchId, p_detail: detail }),
    flagMatch: (matchId, kind, detail) => rest("POST", "/rest/v1/rpc/flag_match", { p_match: matchId, p_kind: kind, p_detail: detail }),
    // Alerta opcional (Discord/Slack/webhook). Nunca quebra o fluxo se falhar ou não estiver configurado.
    async alert(kind, detail) {
      if (!alertWebhookUrl) return;
      try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 4000);
        await fetch(alertWebhookUrl, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ source: "duelo-de-minas", kind, detail, at: new Date().toISOString() }),
          signal: ctrl.signal,
        });
        clearTimeout(t);
      } catch (e) {
        console.error("alert webhook:", e && e.message ? e.message : e);
      }
    },
  };
}
