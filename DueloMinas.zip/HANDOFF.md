# Handoff de segurança — Duelo de Minas

## Ordem de aplicação (celular)

1. **Supabase → SQL Editor**: rode nesta ordem
   - `sql/01_security_hardening.sql`
   - `sql/02_account_ban_storage.sql`
   Confira os `select`s finais de cada arquivo.
2. Suba o **único** `DueloMinas.zip` na raiz do GitHub (`Biel-dev1/App-radio`).
   Se o workflow da raiz for diferente do que está dentro do zip (`.github/workflows/build-duelo-de-minas.yml`), substitua o da raiz pelo do zip também.
3. **Render → Environment** (só no painel, nunca no chat):
   - Obrigatórias: `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`
   - Opcionais: `INSTANCE_ID`, `ALERT_WEBHOOK_URL` (Discord/Slack/qualquer webhook HTTPS), `PAIR_PER_HOUR` (padrão 12), `FEE_PERCENT`, `MIN_STAKE_CENTS`, `MAX_STAKE_CENTS`, `MAX_CONN_PER_IP`, `MAX_CONN_TOTAL`
4. Faça o **Manual Deploy** no Render (Root Directory vazio; Build/Start já descompactam o zip e usam `server/`).
5. Painéis (uma vez):
   - Supabase Auth: confirmação de e-mail, CAPTCHA, senha 10+ com letras e números, rate limits.
   - GitHub: 2FA, proteção da branch `main`, environment `release` com aprovação para secrets de assinatura.
   - Procure no histórico por `sk_`, `sb_secret_`, `eyJ`, keystore e gire qualquer chave encontrada.

## O que esta versão cobre

- IP de rate-limit pelo **último** valor de `X-Forwarded-For` (proxy do Render).
- Recuperação só de partidas **órfãs** (sem atividade há 3 min + `instance_id`).
- `finish_match` com 3 tentativas; se falhar → `attention_required` + alerta opcional (`ALERT_WEBHOOK_URL`).
- Conta `banned` bloqueia conexão e ações; revalidação a cada 30 s.
- Limites por ação (criar/entrar/pagar) e limite de partidas do **mesmo par** por hora.
- Nomes limpos (controles/RTL + homóglifos cirílicos/gregos).
- Auditoria `security_audit` + `pair_seen`.
- Mensagens de erro ao jogador só com texto nosso.
- `delete_my_account` anonimiza perfil e preserva ledger/partidas; bloqueia se houver partida `pending`/`paid`.
- Funções `ban_user` / `unban_user` (service_role).
- Storage de avatars com limite 1 MB e políticas só na pasta do próprio usuário.
- App: tokens no Keystore (`Vault.kt`), SHA-256 na atualização automática, R8, `allowBackup=false`, `filterTouchesWhenObscured`, servidor fixo no app.
- Workflow: APK de teste **não** vira Release; release só com secret + environment `release`; actions pinadas por SHA.

## Riscos conhecidos (aceitos por enquanto)

- Certificate pinning **não** implementado (risco de travar o app se o certificado mudar). Documentado para depois.
- Play Integrity só planejado (exige Google Play).
- Salas ainda em memória: use **uma** instância no Render até haver armazenamento compartilhado.
- Pair matching bloqueia por hora na memória do processo (reinício zera o contador; a auditoria no banco permanece).
- A migração SQL precisa ser validada contra o schema real se alguma tabela/função antiga tiver nome diferente.
- Atualização por APK externo + SHA-256 é **incompatível com Google Play** e deve ser removida se publicar lá.

## Bot da casa (adversário robô)

Quando ninguém entra na fila em `HOUSE_BOT_WAIT_MS` (padrão 15 s), o jogador pode ser pareado com um **bot identificado** ("Bot da Casa (robô)", campo `bot: true` no estado).
- Sorteio justo: o bot posiciona minas e abre casas ao acaso, sem olhar o tabuleiro do jogador (por simetria, 50% / 50%).
- O bot paga a entrada com o saldo de uma **conta da casa** (um `profiles.id`). Sem saldo ali, o bot não entra e nada é cobrado do jogador.
- Configuração (Render/Botkeep): `HOUSE_BOT_UIDS` = ids das contas da casa, separados por vírgula (cada id = 1 partida simultânea). Vazio = desligado.
- Para repor a banca: crédito via `move_balance` na conta da casa (mesmo caminho dos depósitos).
- Sem revanche contra o bot. Testes: `server/housebot.test.js`.
