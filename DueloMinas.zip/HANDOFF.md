# Handoff de segurança

1. No Supabase, execute `sql/01_security_hardening.sql` e revise os `select`s finais.
2. Suba o novo `DueloMinas.zip` na raiz do GitHub. O Render deve usar `server/` dentro dele.
3. No Render, defina somente no painel: `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, opcionalmente `INSTANCE_ID` e `ALERT_WEBHOOK_URL`. Use uma instância enquanto salas ficam na memória.

O servidor usa o último IP de `X-Forwarded-For`, acrescentado pelo proxy do Render; não confie no primeiro valor. A recuperação só toca partidas sem atividade há 3 minutos.

Atualização por APK externo verifica SHA-256 antes da instalação. Esse caminho não é compatível com Google Play e deve ser removido ao publicar lá.

Riscos conhecidos: a migração precisa ser validada contra o schema real antes de produção (o zip não trouxe o SQL original); pair matching hoje é auditoria, não bloqueio automático; Play Integrity ficou apenas planejado.
