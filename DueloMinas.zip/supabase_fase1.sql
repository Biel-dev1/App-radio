-- =====================================================================
-- Fase 1 (complemento) - rode DEPOIS do supabase_base.sql
-- Supabase -> SQL Editor -> New query -> Run
-- =====================================================================

-- Apagar a própria conta (botão "Apagar conta" do app).
-- Só funciona se não houver saldo nem movimentações financeiras (esses registros precisam ser guardados).
create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public, auth as $$
declare
  uid uuid := auth.uid();
  bal bigint;
  n   integer;
begin
  if uid is null then raise exception 'Você não está logado.'; end if;
  select balance_cents into bal from public.profiles where id = uid;
  if coalesce(bal, 0) > 0 then
    raise exception 'Saque ou zere seu saldo antes de apagar a conta.';
  end if;
  select count(*) into n from public.ledger where user_id = uid;
  if n > 0 then
    raise exception 'Sua conta tem movimentações financeiras e precisa ser encerrada pelo suporte.';
  end if;
  select count(*) into n from public.withdrawals where user_id = uid;
  if n > 0 then
    raise exception 'Sua conta tem saques registrados e precisa ser encerrada pelo suporte.';
  end if;
  delete from auth.users where id = uid;   -- o perfil some junto (on delete cascade)
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- Permitir que a pessoa apague a PRÓPRIA foto (usado ao apagar a conta)
drop policy if exists "avatars: apagar na propria pasta" on storage.objects;
create policy "avatars: apagar na propria pasta" on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
