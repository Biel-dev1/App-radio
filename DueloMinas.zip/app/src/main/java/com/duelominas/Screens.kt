package com.duelominas

import android.graphics.drawable.GradientDrawable
import android.text.InputFilter
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.util.Locale

// ------------------------------------------------------------------ pedaços reutilizáveis

private fun MainActivity.statBox(value: String, name: String): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.gravity = Gravity.CENTER
    val v = txt(value, 22f, cWhite, true)
    v.gravity = Gravity.CENTER
    val n = txt(name, 11.5f, cDim)
    n.gravity = Gravity.CENTER
    c.addView(v)
    c.addView(n)
    return c
}

private fun MainActivity.divider(): View {
    val d = View(this)
    d.setBackgroundColor(0x22FFFFFF)
    return d
}

/** Toque suave: a linha escurece enquanto o dedo está nela (como nas listas do iPhone). */
private fun View.dimOnPress() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.alpha = 0.55f
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
        }
        false
    }
}

/** Quadradinho colorido com ícone, no estilo dos Ajustes do iPhone. */
private fun MainActivity.iconTile(kind: Int, tint: Int): FrameLayout {
    val f = FrameLayout(this)
    val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tint, (tint and 0x00FFFFFF) or 0xB3000000.toInt()))
    g.cornerRadius = dp(9f)
    f.background = g
    f.addView(IconView(this, kind, cWhite), FrameLayout.LayoutParams(dpi(19), dpi(19), Gravity.CENTER))
    return f
}

/** Linha de ajuste: ícone, título, valor opcional à direita e seta. */
private fun MainActivity.settingRow(
    icon: Int, tint: Int, title: String, value: String? = null,
    titleColor: Int = cWhite, chevron: Boolean = true, onClick: () -> Unit
): LinearLayout {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dpi(14), dpi(12), dpi(14), dpi(12))
    row.addView(iconTile(icon, tint), LinearLayout.LayoutParams(dpi(32), dpi(32)))
    val t = txt(title, 16f, titleColor)
    val tlp = LinearLayout.LayoutParams(0, WRAP, 1f)
    tlp.leftMargin = dpi(12)
    row.addView(t, tlp)
    if (value != null) {
        val v = txt(value, 14f, cFaint)
        v.maxLines = 1
        v.ellipsize = TextUtils.TruncateAt.END
        v.maxWidth = dpi(150)
        val vlp = LinearLayout.LayoutParams(WRAP, WRAP)
        vlp.rightMargin = dpi(6)
        row.addView(v, vlp)
    }
    if (chevron) row.addView(IconView(this, ICON_CHEVRON, cFaint), LinearLayout.LayoutParams(dpi(14), dpi(14)))
    row.isClickable = true
    row.setOnClickListener { onClick() }
    row.dimOnPress()
    return row
}

/** Grupo de vidro com linhas separadas por um fio fino (lista "inset" do iPhone). */
private fun MainActivity.group(vararg rows: View): LinearLayout {
    val g = LinearLayout(this)
    g.orientation = LinearLayout.VERTICAL
    g.background = glass(22f)
    for ((i, r) in rows.withIndex()) {
        if (i > 0) {
            val lp = LinearLayout.LayoutParams(MATCH, dpi(1))
            lp.leftMargin = dpi(58)
            g.addView(divider(), lp)
        }
        g.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
    }
    return g
}

private fun MainActivity.sectionLabel(text: String): TextView {
    val l = label(text)
    l.setPadding(dpi(14), 0, 0, 0)
    return l
}

private fun MainActivity.appVersion(): String = try {
    packageManager.getPackageInfo(packageName, 0).versionName ?: ""
} catch (_: Exception) {
    ""
}

// ------------------------------------------------------------------ Lobby

internal fun MainActivity.lobbyScreen(): ScrollView = scaffold("", "") {
    val p = me ?: JSONObject()
    val wins = p.optInt("wins", 0)
    val losses = p.optInt("losses", 0)
    val total = wins + losses

    // topo: foto, saudação e saldo (tocar no saldo abre "Adicionar saldo")
    val top = LinearLayout(this@lobbyScreen)
    top.orientation = LinearLayout.HORIZONTAL
    top.gravity = Gravity.CENTER_VERTICAL
    val av = AvatarView(this@lobbyScreen)
    av.setPerson(p.str("display_name"), p.str("avatar_url"))
    top.addView(av, LinearLayout.LayoutParams(dpi(56), dpi(56)))
    val who = LinearLayout(this@lobbyScreen)
    who.orientation = LinearLayout.VERTICAL
    who.addView(txt(greeting() + ",", 13f, cDim))
    who.addView(nameWithBadge(p.str("display_name").ifEmpty { "Jogador" }, 20f, p.optBoolean("verified")))
    val wlp = LinearLayout.LayoutParams(0, WRAP, 1f)
    wlp.leftMargin = dpi(12)
    top.addView(who, wlp)
    val bal = iconText(ICON_WALLET, money(p.optLong("balance_cents", 0L)), 14f, cWhite, true)
    bal.background = glass(18f)
    bal.setPadding(dpi(12), dpi(8), dpi(14), dpi(8))
    bal.isClickable = true
    bal.setOnClickListener { showDeposit() }
    bal.pressable()
    top.addView(bal)
    put(top, 4)

    // números
    put(card {
        val row = LinearLayout(this@lobbyScreen)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(statBox("$wins", "Vitórias"), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(divider(), LinearLayout.LayoutParams(dpi(1), dpi(34)))
        row.addView(statBox("$losses", "Derrotas"), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(divider(), LinearLayout.LayoutParams(dpi(1), dpi(34)))
        row.addView(statBox(if (total == 0) "–" else "${wins * 100 / total}%", "Aproveitamento"), LinearLayout.LayoutParams(0, WRAP, 1f))
        put(row, 0)
    }, 18)

    // Encontrar Partida (Matchmaking estilo Free Fire)
    put(card {
        put(txt("Encontrar Partida", 20f, cWhite, true), 0)
        put(txt("Escolha o modo e dispute contra outros jogadores online.", 13f, cDim), 4)

        // Seletor de minas
        put(label("QUANTIDADE DE MINAS"), 14)
        var selectedMines = 5
        val minesRow = LinearLayout(this@lobbyScreen)
        minesRow.orientation = LinearLayout.HORIZONTAL
        val mineOptions = listOf(1, 3, 5, 7, 10)
        val mineViews = mutableListOf<TextView>()
        fun updateMinesStyles() {
            for ((idx, m) in mineOptions.withIndex()) {
                val tv = mineViews[idx]
                if (m == selectedMines) {
                    val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7C4DFF.toInt(), 0xFF06B6D4.toInt()))
                    g.cornerRadius = dp(14f)
                    tv.background = g
                } else {
                    tv.background = glass(14f)
                }
            }
        }
        for (m in mineOptions) {
            val tv = txt("$m", 15f, cWhite, true)
            tv.gravity = Gravity.CENTER
            tv.setPadding(dpi(4), dpi(10), dpi(4), dpi(10))
            tv.isClickable = true
            tv.setOnClickListener {
                selectedMines = m
                updateMinesStyles()
            }
            tv.pressable()
            mineViews.add(tv)
            val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
            lp.setMargins(dpi(3), 0, dpi(3), 0)
            minesRow.addView(tv, lp)
        }
        updateMinesStyles()
        put(minesRow, 8)

        // Seletor de valor da partida
        put(label("VALOR DA PARTIDA (R$)"), 16)
        val stakeIn = input("Ex.: 2,00", "2,00")
        stakeIn.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        stakeIn.gravity = Gravity.CENTER
        stakeIn.textSize = 20f
        put(stakeIn, 8)

        val stakeChips = LinearLayout(this@lobbyScreen)
        stakeChips.orientation = LinearLayout.HORIZONTAL
        val quickStakes = listOf(1, 2, 5, 10, 20)
        for ((idx, s) in quickStakes.withIndex()) {
            val tv = txt("R$ $s", 13f, cWhite, true)
            tv.gravity = Gravity.CENTER
            tv.background = glass(12f)
            tv.setPadding(dpi(2), dpi(8), dpi(2), dpi(8))
            tv.isClickable = true
            tv.setOnClickListener {
                stakeIn.setText("$s,00")
                stakeIn.setSelection(stakeIn.text.length)
            }
            tv.pressable()
            val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (idx > 0) lp.leftMargin = dpi(4)
            stakeChips.addView(tv, lp)
        }
        put(stakeChips, 8)

        val prizeInfo = txt("", 12.5f, 0xFF67E8F9.toInt())
        prizeInfo.gravity = Gravity.CENTER
        fun recalcPrize() {
            val c = parseCents(stakeIn.text.toString()) ?: 0L
            if (c > 0) {
                val fee = Game.feeOf(c)
                prizeInfo.text = "Total: ${money(c + fee)} (com taxa)  •  Vencedor leva: ${money(c * 2)}"
            } else {
                prizeInfo.text = "Mínimo R$ 1,00  •  Máximo R$ 500,00"
            }
        }
        recalcPrize()
        stakeIn.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { recalcPrize() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        put(prizeInfo, 10)

        // Botão INICIAR BUSCA (Matchmaking)
        val btnSearch = button("ENCONTRAR PARTIDA") {
            val cents = parseCents(stakeIn.text.toString())
            if (cents == null || cents < Game.minStakeCents || cents > Game.maxStakeCents) {
                toast("O valor precisa ficar entre ${money(Game.minStakeCents)} e ${money(Game.maxStakeCents)}.")
            } else {
                GameUi.startMatchmaking(this@lobbyScreen, cents, selectedMines)
            }
        }
        put(btnSearch, 16)
    }, 14)
}

// ------------------------------------------------------------------ Saldo

/** "Adicionar saldo": pergunta o valor (mínimo definido pelo servidor, R$ 10,00). */
internal fun MainActivity.showDeposit() {
    val minCents = Game.minDepositCents
    val body = LinearLayout(this)
    body.orientation = LinearLayout.VERTICAL

    val amount = input("0,00", "")
    amount.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    amount.filters = arrayOf(InputFilter.LengthFilter(9))
    amount.gravity = Gravity.CENTER
    amount.textSize = 28f
    body.addView(amount, LinearLayout.LayoutParams(MATCH, WRAP))

    val chips = LinearLayout(this)
    chips.orientation = LinearLayout.HORIZONTAL
    val values = listOf(10, 20, 50, 100)
    for ((i, v) in values.withIndex()) {
        val c = txt("R$ $v", 14f, cWhite, true)
        c.gravity = Gravity.CENTER
        c.background = glass(14f)
        c.setPadding(dpi(4), dpi(11), dpi(4), dpi(11))
        c.isClickable = true
        c.setOnClickListener {
            amount.setText("$v,00")
            amount.setSelection(amount.text.length)
        }
        c.pressable()
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        if (i > 0) lp.leftMargin = dpi(8)
        chips.addView(c, lp)
    }
    val clp = LinearLayout.LayoutParams(MATCH, WRAP)
    clp.topMargin = dpi(12)
    body.addView(chips, clp)

    val note = txt("Depósito mínimo: ${money(minCents)}. Após gerar o Pix, pague e o saldo entra sozinho.", 12f, cFaint)
    val nlp = LinearLayout.LayoutParams(MATCH, WRAP)
    nlp.topMargin = dpi(12)
    body.addView(note, nlp)

    val cpf = input("CPF (só números)", "")
    cpf.inputType = InputType.TYPE_CLASS_NUMBER
    cpf.filters = arrayOf(InputFilter.LengthFilter(11))
    val clp2 = LinearLayout.LayoutParams(MATCH, WRAP)
    clp2.topMargin = dpi(12)
    body.addView(cpf, clp2)

    glassDialog(
        title = "Adicionar saldo",
        message = "Quanto você quer adicionar?",
        content = body,
        positive = "Gerar Pix"
    ) {
        val cents = parseCents(amount.text.toString())
        val doc = cpf.text.toString().filter { it.isDigit() }
        when {
            cents == null || cents < minCents -> {
                toast("O depósito mínimo é ${money(minCents)}.")
                false
            }
            doc.length != 11 -> {
                toast("Informe um CPF válido com 11 dígitos.")
                false
            }
            else -> {
                toast("Gerando Pix…")
                if (!Game.send("deposit", "cents" to cents, "cpf" to doc))
                    toast("Aguarde um instante e tente de novo.")
                true
            }
        }
    }
}

// ------------------------------------------------------------------ Saque e Senha de Segurança (6 dígitos)

/** "Sacar saldo": valor (mínimo R$ 20,00) + chave Pix + confirmação com senha de 6 dígitos. */
internal fun MainActivity.showWithdraw() {
    val p = me ?: JSONObject()
    val balCents = p.optLong("balance_cents", 0L)
    val minWithdrawCents = 2000L // R$ 20,00

    if (balCents < minWithdrawCents) {
        toast("O saldo mínimo para saque é de ${money(minWithdrawCents)}.")
        return
    }

    val body = LinearLayout(this)
    body.orientation = LinearLayout.VERTICAL

    val info = txt("Saldo disponível: ${money(balCents)}", 14f, 0xFF4ADE80.toInt(), true)
    body.addView(info)

    val labelVal = label("VALOR DO SAQUE (MÍNIMO R$ 20,00)")
    val lpLv = LinearLayout.LayoutParams(MATCH, WRAP)
    lpLv.topMargin = dpi(14)
    body.addView(labelVal, lpLv)

    val amount = input("20,00", "")
    amount.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    amount.filters = arrayOf(InputFilter.LengthFilter(9))
    amount.gravity = Gravity.CENTER
    amount.textSize = 26f
    val lpAm = LinearLayout.LayoutParams(MATCH, WRAP)
    lpAm.topMargin = dpi(6)
    body.addView(amount, lpAm)

    // Chips de valor
    val chips = LinearLayout(this)
    chips.orientation = LinearLayout.HORIZONTAL
    val values = listOf(20, 50, 100)
    for ((i, v) in values.withIndex()) {
        val c = txt("R$ $v", 13f, cWhite, true)
        c.gravity = Gravity.CENTER
        c.background = glass(14f)
        c.setPadding(dpi(4), dpi(9), dpi(4), dpi(9))
        c.isClickable = true
        c.setOnClickListener {
            amount.setText("$v,00")
            amount.setSelection(amount.text.length)
        }
        c.pressable()
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        if (i > 0) lp.leftMargin = dpi(6)
        chips.addView(c, lp)
    }
    // Botão "Tudo"
    val allChip = txt("Tudo", 13f, 0xFF22D3EE.toInt(), true)
    allChip.gravity = Gravity.CENTER
    allChip.background = glass(14f)
    allChip.setPadding(dpi(4), dpi(9), dpi(4), dpi(9))
    allChip.isClickable = true
    allChip.setOnClickListener {
        val reais = balCents / 100
        val centavos = balCents % 100
        amount.setText(String.format(Locale.US, "%d,%02d", reais, centavos))
        amount.setSelection(amount.text.length)
    }
    allChip.pressable()
    val lpAll = LinearLayout.LayoutParams(0, WRAP, 1f)
    lpAll.leftMargin = dpi(6)
    chips.addView(allChip, lpAll)

    val clp = LinearLayout.LayoutParams(MATCH, WRAP)
    clp.topMargin = dpi(10)
    body.addView(chips, clp)

    // Tipo de chave Pix
    val labelPix = label("TIPO DE CHAVE PIX")
    val lpLp = LinearLayout.LayoutParams(MATCH, WRAP)
    lpLp.topMargin = dpi(14)
    body.addView(labelPix, lpLp)

    var selectedPixType = "cpf"
    val pixTypesRow = LinearLayout(this)
    pixTypesRow.orientation = LinearLayout.HORIZONTAL
    val typeChips = listOf(
        "cpf" to "CPF",
        "email" to "E-mail",
        "phone" to "Celular",
        "random" to "Aleatória"
    )
    val typeViews = mutableListOf<TextView>()
    fun updateTypeStyles() {
        for ((idx, pair) in typeChips.withIndex()) {
            val tv = typeViews[idx]
            if (pair.first == selectedPixType) {
                val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7C4DFF.toInt(), 0xFF06B6D4.toInt()))
                g.cornerRadius = dp(12f)
                tv.background = g
            } else {
                tv.background = glass(12f)
            }
        }
    }

    for (pair in typeChips) {
        val tv = txt(pair.second, 12f, cWhite, true)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dpi(6), dpi(8), dpi(6), dpi(8))
        tv.isClickable = true
        tv.setOnClickListener {
            selectedPixType = pair.first
            updateTypeStyles()
        }
        tv.pressable()
        typeViews.add(tv)
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.setMargins(dpi(2), 0, dpi(2), 0)
        pixTypesRow.addView(tv, lp)
    }
    updateTypeStyles()
    val prLp = LinearLayout.LayoutParams(MATCH, WRAP)
    prLp.topMargin = dpi(6)
    body.addView(pixTypesRow, prLp)

    val pixKeyInput = input("Digite sua chave Pix", "")
    val pkLp = LinearLayout.LayoutParams(MATCH, WRAP)
    pkLp.topMargin = dpi(10)
    body.addView(pixKeyInput, pkLp)

    glassDialog(
        title = "Solicitar Saque",
        content = body,
        positive = "Avançar"
    ) {
        val cents = parseCents(amount.text.toString())
        val key = pixKeyInput.text.toString().trim()
        when {
            cents == null || cents < minWithdrawCents -> {
                toast("O saque mínimo é ${money(minWithdrawCents)}.")
                false
            }
            cents > balCents -> {
                toast("Saldo insuficiente para este valor.")
                false
            }
            key.length < 3 -> {
                toast("Informe uma chave Pix válida.")
                false
            }
            else -> {
                promptPin("Autorizar Saque", "Digite sua senha de 6 dígitos para autorizar o saque de ${money(cents)}:") { pin ->
                    toast("Enviando solicitação de saque…")
                    Game.send("withdraw", "cents" to cents, "pixType" to selectedPixType, "pixKey" to key, "pin" to pin)
                }
                true
            }
        }
    }
}

/**
 * Diálogo para solicitar ou cadastrar a senha de 6 dígitos.
 * [onSuccess] é executado quando o PIN correto é fornecido.
 */
internal fun MainActivity.promptPin(title: String, subtitle: String, onSuccess: (String) -> Unit) {
    val uid = Api.userId
    if (!Vault.hasPin(prefs, uid)) {
        showSetupPinDialog(onSuccess)
    } else {
        showVerifyPinDialog(title, subtitle, onSuccess)
    }
}

private fun MainActivity.showSetupPinDialog(onSuccess: (String) -> Unit) {
    val body = LinearLayout(this)
    body.orientation = LinearLayout.VERTICAL

    val info = txt("Crie uma senha de 6 dígitos para proteger seus saques e partidas.", 13f, cDim)
    body.addView(info)

    val pin1 = input("Digite 6 dígitos", "")
    pin1.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    pin1.filters = arrayOf(InputFilter.LengthFilter(6))
    pin1.gravity = Gravity.CENTER
    pin1.textSize = 22f
    val lp1 = LinearLayout.LayoutParams(MATCH, WRAP)
    lp1.topMargin = dpi(14)
    body.addView(pin1, lp1)

    val pin2 = input("Confirme os 6 dígitos", "")
    pin2.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    pin2.filters = arrayOf(InputFilter.LengthFilter(6))
    pin2.gravity = Gravity.CENTER
    pin2.textSize = 22f
    val lp2 = LinearLayout.LayoutParams(MATCH, WRAP)
    lp2.topMargin = dpi(10)
    body.addView(pin2, lp2)

    var dlg: android.app.Dialog? = null
    dlg = glassDialog(
        title = "Cadastrar senha de 6 dígitos",
        content = body,
        positive = "Salvar e continuar"
    ) {
        val p1 = pin1.text.toString().trim()
        val p2 = pin2.text.toString().trim()
        when {
            p1.length != 6 || !p1.all { it.isDigit() } -> {
                toast("A senha precisa ter exatamente 6 números.")
                false
            }
            p1 != p2 -> {
                toast("As senhas não coincidem.")
                false
            }
            else -> {
                bg(work = { Api.setSecurityPin(p1) }) {
                    Vault.savePin(prefs, Api.userId, p1)
                    toast("Senha de 6 dígitos criada com sucesso!")
                    dlg?.dismiss()
                    onSuccess(p1)
                }
                false
            }
        }
    }
}

private fun MainActivity.showVerifyPinDialog(title: String, subtitle: String, onSuccess: (String) -> Unit) {
    val body = LinearLayout(this)
    body.orientation = LinearLayout.VERTICAL

    val info = txt(subtitle, 13.5f, cDim)
    body.addView(info)

    val pinInput = input("••••••", "")
    pinInput.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    pinInput.filters = arrayOf(InputFilter.LengthFilter(6))
    pinInput.gravity = Gravity.CENTER
    pinInput.textSize = 26f
    pinInput.letterSpacing = 0.3f
    val lp = LinearLayout.LayoutParams(MATCH, WRAP)
    lp.topMargin = dpi(16)
    body.addView(pinInput, lp)

    val errTv = txt("", 12.5f, 0xFFF87171.toInt())
    errTv.gravity = Gravity.CENTER
    val elp = LinearLayout.LayoutParams(MATCH, WRAP)
    elp.topMargin = dpi(8)
    body.addView(errTv, elp)

    var dlg: android.app.Dialog? = null
    dlg = glassDialog(
        title = title,
        content = body,
        positive = "Confirmar"
    ) {
        val entered = pinInput.text.toString().trim()
        if (entered.length != 6) {
            errTv.text = "Digite os 6 dígitos da sua senha."
            false
        } else if (!Vault.verifyPin(prefs, Api.userId, entered)) {
            errTv.text = "Senha incorreta. Tente novamente."
            pinInput.setText("")
            false
        } else {
            dlg?.dismiss()
            onSuccess(entered)
            true
        }
    }
}

internal fun MainActivity.showManageSecurityPin() {
    val uid = Api.userId
    if (!Vault.hasPin(prefs, uid)) {
        showSetupPinDialog {}
    } else {
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL

        val cur = input("Senha atual (6 dígitos)", "")
        cur.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        cur.filters = arrayOf(InputFilter.LengthFilter(6))
        cur.gravity = Gravity.CENTER
        cur.textSize = 20f
        body.addView(cur, LinearLayout.LayoutParams(MATCH, WRAP))

        val n1 = input("Nova senha (6 dígitos)", "")
        n1.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        n1.filters = arrayOf(InputFilter.LengthFilter(6))
        n1.gravity = Gravity.CENTER
        n1.textSize = 20f
        val lp1 = LinearLayout.LayoutParams(MATCH, WRAP)
        lp1.topMargin = dpi(10)
        body.addView(n1, lp1)

        val n2 = input("Repita a nova senha", "")
        n2.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        n2.filters = arrayOf(InputFilter.LengthFilter(6))
        n2.gravity = Gravity.CENTER
        n2.textSize = 20f
        val lp2 = LinearLayout.LayoutParams(MATCH, WRAP)
        lp2.topMargin = dpi(10)
        body.addView(n2, lp2)

        var dlg: android.app.Dialog? = null
        dlg = glassDialog(
            title = "Alterar senha de 6 dígitos",
            content = body,
            positive = "Alterar"
        ) {
            val c = cur.text.toString().trim()
            val a = n1.text.toString().trim()
            val b = n2.text.toString().trim()
            when {
                !Vault.verifyPin(prefs, uid, c) -> {
                    toast("A senha atual está incorreta.")
                    false
                }
                a.length != 6 || !a.all { it.isDigit() } -> {
                    toast("A nova senha precisa ter 6 números.")
                    false
                }
                a != b -> {
                    toast("As novas senhas não coincidem.")
                    false
                }
                a == c -> {
                    toast("A nova senha precisa ser diferente da atual.")
                    false
                }
                else -> {
                    bg(work = { Api.setSecurityPin(a) }) {
                        Vault.savePin(prefs, uid, a)
                        toast("Senha de segurança alterada!")
                        dlg?.dismiss()
                        showTab(3)
                    }
                    false
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Conta: usuário e senha

internal fun MainActivity.showChangeUsername() {
    val p = me ?: JSONObject()
    val e = input("nome_de_usuario", p.str("username"))
    e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    e.filters = arrayOf(
        InputFilter { src, s, en, _, _, _ ->
            val sb = StringBuilder()
            for (i in s until en) {
                val ch = src[i].lowercaseChar()
                if (ch in 'a'..'z' || ch in '0'..'9' || ch == '_') sb.append(ch)
            }
            if (sb.toString() == src.subSequence(s, en).toString()) null else sb.toString()
        },
        InputFilter.LengthFilter(20)
    )
    e.setSelection(e.text.length)
    val body = LinearLayout(this)
    body.orientation = LinearLayout.VERTICAL
    body.addView(e, LinearLayout.LayoutParams(MATCH, WRAP))
    val hint = txt("De 3 a 20 caracteres: letras minúsculas, números e _. Cada nome é único e só dá para trocar a cada 30 dias.", 12f, cFaint)
    val hlp = LinearLayout.LayoutParams(MATCH, WRAP)
    hlp.topMargin = dpi(10)
    body.addView(hint, hlp)

    // verifica na hora se o nome está livre (espera o jogador parar de digitar)
    val status = txt("", 13f, cFaint, true)
    val slp = LinearLayout.LayoutParams(MATCH, WRAP)
    slp.topMargin = dpi(8)
    body.addView(status, 1, slp)
    val handler = android.os.Handler(android.os.Looper.getMainLooper())
    var pending: Runnable? = null
    e.addTextChangedListener(object : android.text.TextWatcher {
        override fun afterTextChanged(s: android.text.Editable?) {
            pending?.let { handler.removeCallbacks(it) }
            val u = s.toString().trim().lowercase()
            if (u == p.str("username") || u.isEmpty()) {
                status.text = ""
                return
            }
            if (!Regex("^[a-z0-9_]{3,20}$").matches(u)) {
                status.text = "Mínimo de 3 caracteres."
                status.setTextColor(cFaint)
                return
            }
            status.text = "Verificando…"
            status.setTextColor(cFaint)
            val r = Runnable {
                bg(onFail = { status.text = "" }, work = { Api.usernameAvailable(u) }) { ok ->
                    if (e.text.toString().trim().lowercase() == u) {
                        status.text = if (ok) "Disponível" else "Já está em uso ou não é permitido"
                        status.setTextColor(if (ok) 0xFF4ADE80.toInt() else 0xFFF87171.toInt())
                    }
                }
            }
            pending = r
            handler.postDelayed(r, 450)
        }
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
    })

    var dlg: android.app.Dialog? = null
    dlg = glassDialog(
        title = "Nome de usuário",
        content = body,
        positive = "Salvar"
    ) {
        val u = e.text.toString().trim().lowercase()
        if (!Regex("^[a-z0-9_]{3,20}$").matches(u)) {
            toast("Use de 3 a 20 letras minúsculas, números ou _.")
        } else if (u == p.str("username")) {
            dlg?.dismiss()
        } else {
            bg(work = { Api.changeUsername(u); Api.profile() }) { np ->
                me = np
                dlg?.dismiss()
                toast("Nome de usuário atualizado!")
                showTab(3)
            }
        }
        false
    }
}

internal fun MainActivity.showChangePassword() {
    fun pass(hint: String): android.widget.EditText {
        val e = input(hint, "")
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        return e
    }
    val cur = pass("Senha atual")
    val n1 = pass("Nova senha (mínimo 8 caracteres)")
    val n2 = pass("Repita a nova senha")
    val body = LinearLayout(this)
    body.orientation = LinearLayout.VERTICAL
    body.addView(cur, LinearLayout.LayoutParams(MATCH, WRAP))
    for (f in listOf(n1, n2)) {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dpi(10)
        body.addView(f, lp)
    }

    var dlg: android.app.Dialog? = null
    dlg = glassDialog(
        title = "Alterar senha",
        content = body,
        positive = "Alterar"
    ) {
        val c = cur.text.toString()
        val a = n1.text.toString()
        val b = n2.text.toString()
        if (c.isEmpty()) {
            toast("Digite sua senha atual.")
        } else if (a.length < 8) {
            toast("A nova senha precisa ter pelo menos 8 caracteres.")
        } else if (a != b) {
            toast("As senhas novas não são iguais.")
        } else if (a == c) {
            toast("A nova senha precisa ser diferente da atual.")
        } else {
            bg(work = { Api.changePassword(c, a) }) {
                dlg?.dismiss()
                toast("Senha alterada!")
            }
        }
        false
    }
}

// ------------------------------------------------------------------ Perfil

internal fun MainActivity.profileScreen(): ScrollView = scaffold("", "") {
    val p = me ?: JSONObject()

    // cabeçalho: foto (com selo de câmera), nome, @usuário e bio
    val frame = FrameLayout(this@profileScreen)
    val av = AvatarView(this@profileScreen)
    av.setPerson(p.str("display_name"), p.str("avatar_url"))
    av.setOnClickListener { pickPhoto(1) }
    profileAvatar = av
    frame.addView(av, FrameLayout.LayoutParams(dpi(104), dpi(104)))
    val cam = FrameLayout(this@profileScreen)
    val camBg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF7C4DFF.toInt(), 0xFF06B6D4.toInt()))
    camBg.shape = GradientDrawable.OVAL
    camBg.setStroke(dpi(2), 0xCCFFFFFF.toInt())
    cam.background = camBg
    cam.addView(IconView(this@profileScreen, ICON_CAMERA, cWhite), FrameLayout.LayoutParams(dpi(17), dpi(17), Gravity.CENTER))
    cam.setOnClickListener { pickPhoto(1) }
    frame.addView(cam, FrameLayout.LayoutParams(dpi(32), dpi(32), Gravity.BOTTOM or Gravity.END))
    put(frame, 6, dpi(104), dpi(104))

    put(nameWithBadge(p.str("display_name").ifEmpty { "Jogador" }, 24f, p.optBoolean("verified"), center = true), 12)
    val user = txt("@" + p.str("username"), 13f, cDim)
    user.gravity = Gravity.CENTER
    put(user, 2)
    val bio = p.str("bio")
    if (bio.isNotEmpty()) {
        val b = txt(bio, 14f, cDim)
        b.gravity = Gravity.CENTER
        put(b, 8)
    }

    // carteira
    put(card {
        put(label("SALDO DISPONÍVEL"), 0)
        put(txt(money(p.optLong("balance_cents", 0L)), 34f, cWhite, true), 4)
        val row = LinearLayout(this@profileScreen)
        row.orientation = LinearLayout.HORIZONTAL
        val add = button("Adicionar saldo") { showDeposit() }
        val sacar = button("Sacar", false) { showWithdraw() }
        val l1 = LinearLayout.LayoutParams(0, WRAP, 1.3f)
        l1.rightMargin = dpi(6)
        val l2 = LinearLayout.LayoutParams(0, WRAP, 1f)
        l2.leftMargin = dpi(6)
        row.addView(add, l1)
        row.addView(sacar, l2)
        put(row, 16)
    }, 18)

    // conta
    put(sectionLabel("CONTA"), 24)
    val hasPin = Vault.hasPin(prefs, Api.userId)
    val pinLabel = if (hasPin) "Alterar senha de 6 dígitos" else "Cadastrar senha de 6 dígitos"
    val pinDesc = if (hasPin) "Saques e partidas (ativa)" else "Proteja saques e partidas"
    put(group(
        settingRow(ICON_EDIT, 0xFF7C4DFF.toInt(), "Editar perfil", "Nome, bio e foto") { showEditProfile() },
        settingRow(ICON_AT, 0xFF0EA5E9.toInt(), "Nome de usuário", "@" + p.str("username")) { showChangeUsername() },
        settingRow(ICON_LOCK, 0xFFF59E0B.toInt(), "Alterar senha da conta") { showChangePassword() },
        settingRow(ICON_LOCK, 0xFF10B981.toInt(), pinLabel, pinDesc) { showManageSecurityPin() }
    ), 8)

    // aplicativo
    put(sectionLabel("APLICATIVO"), 22)
    put(group(
        settingRow(ICON_DOC, 0xFF64748B.toInt(), "Termos de uso") { showTermsDialog() },
        settingRow(ICON_DOWNLOAD, 0xFF22C55E.toInt(), "Atualizações", "v" + appVersion()) { AppUpdate.check(this@profileScreen) }
    ), 8)

    // sessão
    put(sectionLabel("SESSÃO"), 22)
    put(group(
        settingRow(ICON_LOGOUT, 0xFF64748B.toInt(), "Sair da conta") { logout() },
        settingRow(ICON_TRASH, 0xFFEF4444.toInt(), "Apagar minha conta", null, 0xFFF87171.toInt()) { confirmDelete() }
    ), 8)
}

internal fun MainActivity.showEditProfile() {
    val p = me ?: JSONObject()
    val v = scaffold("Editar perfil", "Como os outros jogadores veem você.") {
        val frame = FrameLayout(this@showEditProfile)
        val av = AvatarView(this@showEditProfile)
        av.setPerson(p.str("display_name"), p.str("avatar_url"))
        av.setOnClickListener { pickPhoto(1) }
        profileAvatar = av
        frame.addView(av, FrameLayout.LayoutParams(dpi(104), dpi(104)))
        val cam = FrameLayout(this@showEditProfile)
        val camBg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF7C4DFF.toInt(), 0xFF06B6D4.toInt()))
        camBg.shape = GradientDrawable.OVAL
        camBg.setStroke(dpi(2), 0xCCFFFFFF.toInt())
        cam.background = camBg
        cam.addView(IconView(this@showEditProfile, ICON_CAMERA, cWhite), FrameLayout.LayoutParams(dpi(17), dpi(17), Gravity.CENTER))
        cam.setOnClickListener { pickPhoto(1) }
        frame.addView(cam, FrameLayout.LayoutParams(dpi(32), dpi(32), Gravity.BOTTOM or Gravity.END))
        put(frame, 0, dpi(104), dpi(104))
        val change = txt("Toque na foto para trocar. Pode ser JPG, PNG ou GIF animado (até 5 MB).", 12f, cFaint)
        change.gravity = Gravity.CENTER
        put(change, 10)
        put(card {
            put(label("NOME DE EXIBIÇÃO"), 0)
            val nameIn = input("Seu nome", p.str("display_name"))
            nameIn.filters = arrayOf(InputFilter.LengthFilter(20))
            put(nameIn, 8)
            put(label("BIO"), 16)
            val bioIn = input("Fale um pouco sobre você", p.str("bio"))
            bioIn.setSingleLine(false)
            bioIn.minLines = 3
            bioIn.gravity = Gravity.TOP or Gravity.START
            bioIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            bioIn.filters = arrayOf(InputFilter.LengthFilter(200))
            put(bioIn, 8)
            lateinit var save: TextView
            save = button("Salvar alterações") {
                val n = nameIn.text.toString().trim()
                if (n.length < 3) {
                    toast("O nome precisa ter pelo menos 3 letras.")
                } else {
                    busy(save, true)
                    bg(onFail = { busy(save, false) }, work = {
                        val f = JSONObject()
                        f.put("display_name", n)
                        f.put("bio", bioIn.text.toString().trim())
                        Api.updateProfile(f)
                        Api.profile()
                    }) { np ->
                        me = np
                        toast("Perfil salvo!")
                        goTab(3)
                    }
                }
            }
            put(save, 18)
        }, 14)
        put(button("Voltar", false) { goTab(3) }, 12)
    }
    setScreen(v, true)
}
