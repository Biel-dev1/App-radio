package com.duelominas

import android.app.AlertDialog
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject

// ------------------------------------------------------------------ pedaços reutilizáveis

private fun MainActivity.statBox(value: String, name: String): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.gravity = Gravity.CENTER
    val v = txt(value, 22f, cWhite, true)
    v.gravity = Gravity.CENTER
    val n = txt(name, 11.5f, cDim)
    n.gravity = Gravity.CENTER
    c.addView(v)
    c.addView(n)
    return c
}

private fun MainActivity.divider(): View {
    val d = View(this)
    d.setBackgroundColor(0x22FFFFFF)
    return d
}

/** Linha de menu: ícone + título (+ subtítulo) + seta. */
private fun MainActivity.menuRow(icon: String, title: String, subtitle: String?, color: Int = cWhite, onClick: () -> Unit): LinearLayout {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dpi(16), dpi(15), dpi(16), dpi(15))
    val ic = txt(icon, 20f)
    ic.gravity = Gravity.CENTER
    row.addView(ic, LinearLayout.LayoutParams(dpi(34), WRAP))
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.addView(txt(title, 16f, color, true))
    if (subtitle != null) col.addView(txt(subtitle, 12.5f, cDim))
    val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
    lp.leftMargin = dpi(8)
    row.addView(col, lp)
    row.addView(txt("›", 22f, cFaint))
    row.isClickable = true
    row.setOnClickListener { onClick() }
    row.pressable()
    return row
}

// ------------------------------------------------------------------ Lobby

internal fun MainActivity.lobbyScreen(): ScrollView = scaffold("", "") {
    val p = me ?: JSONObject()
    val wins = p.optInt("wins", 0)
    val losses = p.optInt("losses", 0)
    val total = wins + losses

    // topo: foto, saudação e saldo
    val top = LinearLayout(this@lobbyScreen)
    top.orientation = LinearLayout.HORIZONTAL
    top.gravity = Gravity.CENTER_VERTICAL
    val av = AvatarView(this@lobbyScreen)
    av.setPerson(p.str("display_name"), p.str("avatar_url"))
    top.addView(av, LinearLayout.LayoutParams(dpi(56), dpi(56)))
    val who = LinearLayout(this@lobbyScreen)
    who.orientation = LinearLayout.VERTICAL
    who.addView(txt(greeting() + ",", 13f, cDim))
    who.addView(txt(p.str("display_name").ifEmpty { "Jogador" }, 20f, cWhite, true))
    val wlp = LinearLayout.LayoutParams(0, WRAP, 1f)
    wlp.leftMargin = dpi(12)
    top.addView(who, wlp)
    val bal = txt(money(p.optLong("balance_cents", 0L)), 14f, cWhite, true)
    bal.background = glass(18f)
    bal.setPadding(dpi(14), dpi(8), dpi(14), dpi(8))
    top.addView(bal)
    put(top, 4)

    // números
    put(card {
        val row = LinearLayout(this@lobbyScreen)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(statBox("$wins", "Vitórias"), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(divider(), LinearLayout.LayoutParams(dpi(1), dpi(34)))
        row.addView(statBox("$losses", "Derrotas"), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(divider(), LinearLayout.LayoutParams(dpi(1), dpi(34)))
        row.addView(statBox(if (total == 0) "–" else "${wins * 100 / total}%", "Aproveitamento"), LinearLayout.LayoutParams(0, WRAP, 1f))
        put(row, 0)
    }, 18)

    // jogar
    put(card {
        put(txt("Pronto para um duelo?", 18f, cWhite, true), 0)
        put(txt("Crie uma sala ou entre na de um amigo com o código.", 13f, cDim), 4)
        put(button("Criar sala") { showCreateRoom() }, 16)
        put(button("Entrar com código", false) { askJoinCode() }, 10)
    }, 14)

    // salas públicas (resumo)
    val head = LinearLayout(this@lobbyScreen)
    head.orientation = LinearLayout.HORIZONTAL
    head.gravity = Gravity.CENTER_VERTICAL
    head.addView(label("SALAS PÚBLICAS AGORA"), LinearLayout.LayoutParams(0, WRAP, 1f))
    val all = txt("Ver todas ›", 13f, 0xFF22D3EE.toInt(), true)
    all.setPadding(dpi(8), dpi(6), 0, dpi(6))
    all.setOnClickListener { goTab(1) }
    head.addView(all)
    put(head, 22)
    val box = LinearLayout(this@lobbyScreen)
    box.orientation = LinearLayout.VERTICAL
    put(box, 8)
    GameUi.lobbyBox = box
    renderRoomItems(box, 3)
    GameUi.startRefresher()

    val st = txt(if (Game.connected) "Servidor de jogo conectado" else "Conectando ao servidor de jogo…", 11.5f, cFaint)
    st.gravity = Gravity.CENTER
    put(st, 10)
}

// ------------------------------------------------------------------ Perfil

internal fun MainActivity.profileScreen(): ScrollView = scaffold("", "") {
    val p = me ?: JSONObject()
    val av = AvatarView(this@profileScreen)
    av.setPerson(p.str("display_name"), p.str("avatar_url"))
    av.setOnClickListener { pickPhoto(1) }
    profileAvatar = av
    put(av, 6, dpi(104), dpi(104))
    val name = txt(p.str("display_name").ifEmpty { "Jogador" }, 24f, cWhite, true)
    name.gravity = Gravity.CENTER
    put(name, 12)
    val user = txt("@" + p.str("username"), 13f, cDim)
    user.gravity = Gravity.CENTER
    put(user, 2)
    val bio = p.str("bio")
    if (bio.isNotEmpty()) {
        val b = txt(bio, 14f, cDim)
        b.gravity = Gravity.CENTER
        put(b, 8)
    }

    // saldo
    put(card {
        put(label("SALDO"), 0)
        put(txt(money(p.optLong("balance_cents", 0L)), 32f, cWhite, true), 4)
        put(txt("Saldo de teste: ainda não vale dinheiro.", 12f, cFaint), 2)
        val row = LinearLayout(this@profileScreen)
        row.orientation = LinearLayout.HORIZONTAL
        val sacar = button("Sacar", false) { toast("O saque será liberado em breve.") }
        sacar.alpha = 0.6f
        if (Game.testMode) {
            val add = button("+ Saldo de teste") {
                if (!Game.send("grant_test")) toast("Sem conexão com o servidor de jogo.")
            }
            val l1 = LinearLayout.LayoutParams(0, WRAP, 1f)
            l1.rightMargin = dpi(6)
            val l2 = LinearLayout.LayoutParams(0, WRAP, 1f)
            l2.leftMargin = dpi(6)
            row.addView(add, l1)
            row.addView(sacar, l2)
        } else {
            row.addView(sacar, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        put(row, 16)
    }, 18)

    // menu
    val menu = LinearLayout(this@profileScreen)
    menu.orientation = LinearLayout.VERTICAL
    menu.background = glass(24f)
    menu.addView(menuRow("✏️", "Editar perfil", "Nome, bio e foto") { showEditProfile() })
    menu.addView(divider(), LinearLayout.LayoutParams(MATCH, dpi(1)))
    menu.addView(menuRow("📄", "Termos de uso", null) { showTermsDialog() })
    menu.addView(divider(), LinearLayout.LayoutParams(MATCH, dpi(1)))
    menu.addView(menuRow("🛰️", "Servidor do jogo", if (Game.connected) "Conectado ✅" else "Desconectado") { showServerDialog() })
    menu.addView(divider(), LinearLayout.LayoutParams(MATCH, dpi(1)))
    menu.addView(menuRow("⬆️", "Atualizar aplicativo", "Verificar e instalar uma nova versão") { AppUpdater.check(this@profileScreen) })
    menu.addView(divider(), LinearLayout.LayoutParams(MATCH, dpi(1)))
    menu.addView(menuRow("🚪", "Sair da conta", null) { logout() })
    put(menu, 16)

    val del = txt("Apagar minha conta", 13f, 0xFFF87171.toInt(), true)
    del.gravity = Gravity.CENTER
    del.setPadding(dpi(12), dpi(14), dpi(12), dpi(14))
    del.setOnClickListener { confirmDelete() }
    put(del, 12)
}

internal fun MainActivity.showServerDialog() {
    val cur = prefs.getString("game_server", Game.DEFAULT_SERVER) ?: Game.DEFAULT_SERVER
    val e = input("wss://...", cur)
    e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
    e.setPadding(dpi(20), dpi(14), dpi(20), dpi(14))
    val box = LinearLayout(this)
    box.setPadding(dpi(20), dpi(8), dpi(20), 0)
    box.addView(e, LinearLayout.LayoutParams(MATCH, WRAP))
    AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
        .setTitle("Servidor do jogo")
        .setMessage("Avançado. Só mude se souber o endereço do seu servidor.")
        .setView(box)
        .setNegativeButton("Cancelar", null)
        .setPositiveButton("Salvar") { _, _ ->
            var u = e.text.toString().trim()
            if (u.startsWith("https://")) u = "wss://" + u.removePrefix("https://")
            if (u.startsWith("http://")) u = "ws://" + u.removePrefix("http://")
            if (!u.startsWith("wss://") && !u.startsWith("ws://")) {
                toast("O endereço precisa começar com wss://")
            } else {
                prefs.edit().putString("game_server", u).apply()
                Game.stop()
                Game.start(u)
                toast("Servidor salvo. Reconectando…")
            }
        }
        .show()
}

internal fun MainActivity.showEditProfile() {
    val p = me ?: JSONObject()
    val v = scaffold("Editar perfil", "Como os outros jogadores veem você.") {
        val av = AvatarView(this@showEditProfile)
        av.setPerson(p.str("display_name"), p.str("avatar_url"))
        av.setOnClickListener { pickPhoto(1) }
        profileAvatar = av
        put(av, 0, dpi(104), dpi(104))
        val change = txt("Toque na foto para trocar", 12f, cFaint)
        change.gravity = Gravity.CENTER
        put(change, 8)
        put(card {
            put(label("NOME DE EXIBIÇÃO"), 0)
            val nameIn = input("Seu nome", p.str("display_name"))
            nameIn.filters = arrayOf(InputFilter.LengthFilter(20))
            put(nameIn, 8)
            put(label("BIO"), 16)
            val bioIn = input("Fale um pouco sobre você", p.str("bio"))
            bioIn.setSingleLine(false)
            bioIn.minLines = 3
            bioIn.gravity = Gravity.TOP or Gravity.START
            bioIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            bioIn.filters = arrayOf(InputFilter.LengthFilter(200))
            put(bioIn, 8)
            lateinit var save: TextView
            save = button("Salvar alterações") {
                val n = nameIn.text.toString().trim()
                if (n.length < 3) {
                    toast("O nome precisa ter pelo menos 3 letras.")
                } else {
                    busy(save, true)
                    bg(onFail = { busy(save, false) }, work = {
                        val f = JSONObject()
                        f.put("display_name", n)
                        f.put("bio", bioIn.text.toString().trim())
                        Api.updateProfile(f)
                        Api.profile()
                    }) { np ->
                        me = np
                        toast("Perfil salvo!")
                        goTab(3)
                    }
                }
            }
            put(save, 18)
        }, 14)
        put(button("Voltar", false) { goTab(3) }, 12)
    }
    setScreen(v, true)
}
