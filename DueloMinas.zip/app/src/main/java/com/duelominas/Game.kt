package com.duelominas

import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.min

/** Conexão em tempo real com o servidor de jogo. Todos os eventos chegam na thread principal. */
object Game {
    const val DEFAULT_SERVER = "wss://duelo-minas-server.onrender.com"

    /** Sala atual (null = fora de sala). É o último "state" enviado pelo servidor. */
    var state: JSONObject? = null
    var connected = false
    var testMode = false
    var feePercent = 25.0
    var minStakeCents = 100L
    var maxStakeCents = 50000L
    var maxMines = 10
    var serverOffset = 0L   // relógio do servidor menos o do celular

    var listener: ((JSONObject) -> Unit)? = null

    private var ws: WebSocket? = null
    private var url = ""
    private var wanted = false
    private var attempt = 0
    private val ui = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    fun start(serverUrl: String) {
        if (wanted && serverUrl == url && ws != null) return
        stop()
        url = serverUrl
        wanted = true
        attempt = 0
        open()
    }

    fun stop() {
        wanted = false
        try { ws?.close(1000, "sair") } catch (_: Exception) {}
        ws = null
        connected = false
        state = null
    }

    fun feeOf(stakeCents: Long): Long = Math.round(stakeCents * feePercent / 100.0)

    private fun open() {
        if (!wanted) return
        val socket = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                thread {
                    try {
                        val tok = Api.token()
                        webSocket.send(JSONObject().put("type", "auth").put("token", tok).toString())
                    } catch (e: Exception) {
                        webSocket.close(1000, "auth")
                    }
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                ui.post { handle(webSocket, text) }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                lost(webSocket)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                lost(webSocket)
            }
        })
        ws = socket
    }

    private fun lost(w: WebSocket) {
        ui.post {
            if (w === ws) {
                connected = false
                listener?.invoke(JSONObject().put("type", "disconnected"))
                if (wanted) {
                    attempt++
                    ui.postDelayed({ open() }, min(15000L, 1500L * attempt))
                }
            }
        }
    }

    private fun handle(w: WebSocket, text: String) {
        if (w !== ws) return
        val o = try { JSONObject(text) } catch (e: Exception) { return }
        when (o.optString("type")) {
            "hello" -> {
                connected = true
                attempt = 0
                testMode = o.optBoolean("testMode")
                feePercent = o.optDouble("feePercent", 25.0)
                minStakeCents = o.optLong("minStakeCents", 100L)
                maxStakeCents = o.optLong("maxStakeCents", 50000L)
                maxMines = o.optInt("maxMines", 10)
            }
            "state" -> {
                val r = o.optJSONObject("room")
                state = r
                if (r != null) serverOffset = r.optLong("serverNow") - System.currentTimeMillis()
            }
            "room_closed", "left" -> state = null
        }
        listener?.invoke(o)
    }

    /** Devolve false se ainda não estiver conectado. */
    fun send(type: String, vararg extras: Pair<String, Any?>): Boolean {
        val socket = ws
        if (socket == null || !connected) return false
        val o = JSONObject().put("type", type)
        for ((k, v) in extras) o.put(k, v)
        return socket.send(o.toString())
    }
}
