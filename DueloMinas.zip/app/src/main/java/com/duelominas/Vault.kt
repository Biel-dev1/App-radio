package com.duelominas

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Guarda tokens cifrados com uma chave que fica dentro do Keystore do Android (não sai do aparelho). */
object Vault {
    private const val ALIAS = "duelo_session_key"
    private const val PROVIDER = "AndroidKeyStore"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER)
        ks.load(null)
        val existing = ks.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    /** Devolve o texto cifrado (base64) ou null se o Keystore falhar. */
    fun seal(plain: String): String? = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
    } catch (_: Exception) {
        null
    }

    /** Devolve o texto original ou null se estiver ausente/adulterado/ilegível. */
    fun open(sealed: String?): String? {
        if (sealed.isNullOrEmpty()) return null
        return try {
            val all = Base64.decode(sealed, Base64.NO_WRAP)
            if (all.size <= 12) return null
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
            String(c.doFinal(all, 12, all.size - 12), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }

    /** Verifica se o usuário já tem uma senha de segurança de 6 dígitos cadastrada. */
    fun hasPin(prefs: android.content.SharedPreferences, userId: String?): Boolean {
        val key = if (userId.isNullOrEmpty()) "s_pin" else "s_pin_$userId"
        val sealed = prefs.getString(key, null) ?: return false
        val pin = open(sealed)
        return !pin.isNullOrEmpty() && pin.length == 6
    }

    /** Salva a senha de 6 dígitos cifrada no Keystore. */
    fun savePin(prefs: android.content.SharedPreferences, userId: String?, pin: String): Boolean {
        if (pin.length != 6 || !pin.all { it.isDigit() }) return false
        val sealed = seal(pin) ?: return false
        val key = if (userId.isNullOrEmpty()) "s_pin" else "s_pin_$userId"
        prefs.edit().putString(key, sealed).apply()
        return true
    }

    /** Confere se a senha de 6 dígitos informada está correta. */
    fun verifyPin(prefs: android.content.SharedPreferences, userId: String?, enteredPin: String): Boolean {
        val key = if (userId.isNullOrEmpty()) "s_pin" else "s_pin_$userId"
        val sealed = prefs.getString(key, null) ?: return false
        val stored = open(sealed) ?: return false
        return stored == enteredPin
    }
}
