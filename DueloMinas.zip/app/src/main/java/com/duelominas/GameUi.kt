package com.duelominas

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Estado das telas de jogo (sala, partida, lista de salas). */
object GameUi {
    var inRoomScreen = false
    var wizardOpen = false
    var activity: MainActivity? = null

    var roomsBox: LinearLayout? = null
    var lobbyBox: LinearLayout? = null
    var lastRooms: JSONArray = JSONArray()
    var lastStatus = ""
    var lastTurn = ""
    var tickFn: (() -> Unit)? = null
    var animDone = false
    var joinCode = ""
    var searchingMatchDialog: android.app.Dialog? = null

    fun startMatchmaking(a: MainActivity, stakeCents: Long, mines: Int) {
        if (!Game.connected) {
            a.toast("Conectando ao servidor… tente em instantes.")
            Game.start()
            return
        }
        val saldo = a.me?.optLong("balance_cents", 0L) ?: 0L
        val fee = Game.feeOf(stakeCents)
        if (saldo < stakeCents + fee) {
            a.toast("Saldo insuficiente (${a.money(saldo)}). Adicione saldo para buscar partida.")
            a.showDeposit()
            return
        }
        a.showSearchingMatchDialog(stakeCents, mines)
        Game.send("find_match", "stakeCents" to stakeCents, "mines" to mines)
    }

    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            tickFn?.invoke()
            ui.postDelayed(this, 250)
        }
    }
    private val refresher = object : Runnable {
        override fun run() {
            if ((roomsBox != null || lobbyBox != null) && !inRoomScreen) {
                Game.send("list")
                ui.postDelayed(this, 5000)
            }
        }
    }

    fun startTicker() {
        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    fun stopTicker() {
        ui.removeCallbacks(ticker)
        ui.removeCallbacks(refresher)
        tickFn = null
        roomsBox = null
        lobbyBox = null
        wizardOpen = false
    }

    fun startRefresher() {
        ui.removeCallbacks(refresher)
        ui.post(refresher)
    }

    fun attach(a: MainActivity) {
        activity = a
        Game.listener = { o -> onEvent(a, o) }
        Game.start()
    }

    fun detach() {
        stopTicker()
        inRoomScreen = false
        activity?.dismissSearchingMatchDialog()
        Game.listener = null
        Game.stop()
        lastStatus = ""
    }

    fun confirmLeave(a: MainActivity) {
        val st = Game.state
        val status = st?.optString("status") ?: ""
        val msg = when (status) {
            "playing" -> "Se você sair agora, perde a partida e o valor apostado."
            "checkout", "placing" -> "Se você sair agora, a partida é cancelada e o valor pago volta para o seu saldo."
            else -> "Deseja sair da sala?"
        }
        a.glassDialog(
            title = "Sair da sala?",
            message = msg,
            positive = "Sair",
            negative = "Ficar",
            danger = true
        ) {
            Game.send("leave")
            true
        }
    }

    private fun refreshProfile(a: MainActivity, thenTab: Int = -1) {
        a.bg(work = { Api.profile() }) { p ->
            a.me = p
            if (thenTab >= 0) a.showTab(thenTab)
        }
    }

    fun onEvent(a: MainActivity, o: JSONObject) {
        when (o.optString("type")) {
            "hello" -> {
                Game.send("sync")
                Game.send("list")
            }
            "state" -> {
                a.dismissSearchingMatchDialog()
                a.renderRoom()
            }
            "matchmaking_searching" -> {
                val stake = o.optLong("stakeCents")
                val mines = o.optInt("mines")
                a.showSearchingMatchDialog(stake, mines)
            }
            "matchmaking_cancelled" -> {
                a.dismissSearchingMatchDialog()
            }
            "withdraw_success" -> {
                val cents = o.optLong("cents")
                a.toast("Pedido de saque de ${a.money(cents)} enviado com sucesso!")
                refreshProfile(a)
            }
            "profile_updated" -> {
                refreshProfile(a)
            }
            "rooms" -> {
                lastRooms = o.optJSONArray("list") ?: JSONArray()
                a.renderRoomItems(roomsBox, 100)
                a.renderRoomItems(lobbyBox, 3)
            }
            "room_info" -> a.showJoinConfirm(o)
            "room_closed" -> {
                inRoomScreen = false
                a.toast(o.optString("message", "A sala foi encerrada."))
                refreshProfile(a, 0)
            }
            "left" -> {
                if (inRoomScreen) {
                    inRoomScreen = false
                    lastStatus = ""
                    refreshProfile(a, 0)
                }
            }
            "error" -> a.toast(o.optString("message", "Algo deu errado."))
            "pix_deposit" -> {
                val code = o.optString("pixCode", "")
                val cents = o.optLong("cents", 0L)
                val identifier = o.optString("identifier", "")
                if (code.isBlank()) {
                    a.toast("Não veio o código Pix.")
                } else {
                    a.runOnUiThread { a.showPixDeposit(identifier, code, cents) }
                }
            }
            "deposit_status" -> {
                if (o.optString("status") == "credited") {
                    val id = o.optString("identifier")
                    a.runOnUiThread { depositCreditListener?.invoke(id) }
                    refreshProfile(a)
                }
            }
            "disconnected" -> { /* silencioso: reconecta sozinho */ }
        }
    }
}

// ------------------------------------------------------------------ Matchmaking (Procurando adversário)

internal fun MainActivity.showSearchingMatchDialog(stakeCents: Long, mines: Int) {
    dismissSearchingMatchDialog()
    val dlg = android.app.Dialog(this)
    dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
    dlg.setCancelable(false)

    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.gravity = Gravity.CENTER_HORIZONTAL
    box.setPadding(dpi(24), dpi(28), dpi(24), dpi(24))
    box.background = GlassDrawable(dp(28f), dp(1f), 1f, 0xF2141436.toInt())

    box.addView(txt("Procurando adversário", 21f, cWhite, true))
    val sub = txt("$mines Minas  •  Aposta: ${money(stakeCents)}", 14f, 0xFF22D3EE.toInt(), true)
    sub.setPadding(0, dpi(6), 0, 0)
    box.addView(sub)

    val timerTv = txt("00:00", 28f, cWhite, true)
    timerTv.gravity = Gravity.CENTER
    val timerLp = LinearLayout.LayoutParams(WRAP, WRAP)
    timerLp.topMargin = dpi(20)
    box.addView(timerTv, timerLp)

    val statusTv = txt("Buscando jogadores online…", 13f, cDim)
    statusTv.gravity = Gravity.CENTER
    val statusLp = LinearLayout.LayoutParams(WRAP, WRAP)
    statusLp.topMargin = dpi(8)
    box.addView(statusTv, statusLp)

    val cancel = button("Cancelar busca", false) {
        Game.send("cancel_match")
        dlg.dismiss()
        GameUi.searchingMatchDialog = null
    }
    val cancelLp = LinearLayout.LayoutParams(MATCH, WRAP)
    cancelLp.topMargin = dpi(22)
    box.addView(cancel, cancelLp)

    val startSec = System.currentTimeMillis()
    val handler = Handler(Looper.getMainLooper())
    val timerRunnable = object : Runnable {
        override fun run() {
            if (GameUi.searchingMatchDialog === dlg && dlg.isShowing) {
                val elapsed = (System.currentTimeMillis() - startSec) / 1000
                val m = elapsed / 60
                val s = elapsed % 60
                timerTv.text = String.format(Locale.getDefault(), "%02d:%02d", m, s)
                handler.postDelayed(this, 1000)
            }
        }
    }
    handler.post(timerRunnable)

    dlg.setContentView(box)
    val w = dlg.window
    if (w != null) {
        w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        w.setDimAmount(0.7f)
        val width = min(resources.displayMetrics.widthPixels - dpi(40), dpi(360))
        w.setLayout(width, android.view.WindowManager.LayoutParams.WRAP_CONTENT)
    }
    dlg.show()
    GameUi.searchingMatchDialog = dlg
}

internal fun MainActivity.dismissSearchingMatchDialog() {
    try {
        GameUi.searchingMatchDialog?.dismiss()
    } catch (_: Exception) {}
    GameUi.searchingMatchDialog = null
}

// ------------------------------------------------------------------ depósito Pix

/** Quem espera o crédito do depósito que está na tela agora (chamado quando o servidor avisa). */
private var depositCreditListener: ((String) -> Unit)? = null

/** QR code em preto/branco gerado localmente (ZXing). Retorna null se falhar. */
private fun qrBitmap(text: String, sizePx: Int): android.graphics.Bitmap? = try {
    val m = com.google.zxing.qrcode.QRCodeWriter()
        .encode(text, com.google.zxing.BarcodeFormat.QR_CODE, sizePx, sizePx)
    val w = m.width
    val h = m.height
    val px = IntArray(w * h)
    for (y in 0 until h) {
        for (x in 0 until w) {
            px[y * w + x] = if (m.get(x, y)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        }
    }
    android.graphics.Bitmap.createBitmap(px, w, h, android.graphics.Bitmap.Config.ARGB_8888)
} catch (e: Exception) {
    null
}

/**
 * Tela do depósito: QR + código copiável + "Finalizar".
 * Quando o servidor confirma o pagamento, a tela troca para um check animado e fecha sozinha.
 */
internal fun MainActivity.showPixDeposit(identifier: String, pixCode: String, cents: Long) {
    val dlg = android.app.Dialog(this)
    dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
    dlg.setCancelable(false) // só sai pelo "Finalizar" ou pela confirmação

    val card = android.widget.FrameLayout(this)
    card.background = GlassDrawable(dp(28f), dp(1f), 1f, 0xF2141436.toInt())
    card.setPadding(dpi(22), dpi(24), dpi(22), dpi(20))

    // ---- estado 1: aguardando pagamento
    val pending = android.widget.LinearLayout(this)
    pending.orientation = android.widget.LinearLayout.VERTICAL
    pending.gravity = android.view.Gravity.CENTER_HORIZONTAL
    pending.addView(txt("Depósito Pix", 21f, cWhite, true))
    val valor = txt("Valor: ${money(cents)}", 16f, cWhite, true)
    valor.setPadding(0, dpi(4), 0, 0)
    pending.addView(valor)

    val qrSize = dpi(220)
    val qrBox = android.widget.FrameLayout(this)
    qrBox.background = GradientDrawable().apply {
        setColor(0xFFFFFFFF.toInt())
        cornerRadius = dp(16f)
    }
    qrBox.setPadding(dpi(12), dpi(12), dpi(12), dpi(12))
    val qr = android.widget.ImageView(this)
    qr.setImageBitmap(qrBitmap(pixCode, qrSize))
    qrBox.addView(qr, android.widget.FrameLayout.LayoutParams(qrSize, qrSize))
    val qrLp = android.widget.LinearLayout.LayoutParams(WRAP, WRAP)
    qrLp.topMargin = dpi(16)
    pending.addView(qrBox, qrLp)

    val waiting = txt("Aguardando o pagamento…", 14f, cDim)
    waiting.gravity = android.view.Gravity.CENTER
    waiting.setPadding(0, dpi(14), 0, 0)
    pending.addView(waiting)

    val codeBox = txt(pixCode, 11f, cDim, false)
    codeBox.setTextIsSelectable(true)
    codeBox.setPadding(dpi(8), dpi(10), dpi(8), dpi(10))
    codeBox.background = glass(12f)
    val codeLp = android.widget.LinearLayout.LayoutParams(MATCH, WRAP)
    codeLp.topMargin = dpi(14)
    pending.addView(codeBox, codeLp)

    val copy = button("Copiar código", true) {
        val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("pix", pixCode))
        toast("Código Pix copiado.")
    }
    val copyLp = android.widget.LinearLayout.LayoutParams(MATCH, WRAP)
    copyLp.topMargin = dpi(14)
    pending.addView(copy, copyLp)

    val finish = button("Finalizar", false) {
        Game.send("deposit_cancel", "identifier" to identifier)
        dlg.dismiss()
        toast("Pix cancelado. Se você pagar mesmo assim, o saldo entra automaticamente.")
    }
    val finishLp = android.widget.LinearLayout.LayoutParams(MATCH, WRAP)
    finishLp.topMargin = dpi(8)
    pending.addView(finish, finishLp)

    // ---- estado 2: confirmado (check animado, sem emoji)
    val done = android.widget.LinearLayout(this)
    done.orientation = android.widget.LinearLayout.VERTICAL
    done.gravity = android.view.Gravity.CENTER_HORIZONTAL
    done.visibility = android.view.View.GONE

    val circle = android.widget.FrameLayout(this)
    circle.background = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(0x3334D399)
    }
    circle.addView(
        IconView(this, ICON_CHECK, 0xFF34D399.toInt()),
        android.widget.FrameLayout.LayoutParams(dpi(64), dpi(64), android.view.Gravity.CENTER)
    )
    circle.scaleX = 0f
    circle.scaleY = 0f
    val circleLp = android.widget.LinearLayout.LayoutParams(dpi(120), dpi(120))
    circleLp.topMargin = dpi(24)
    circleLp.bottomMargin = dpi(8)
    done.addView(circle, circleLp)

    val doneTitle = txt("Depósito confirmado!", 20f, cWhite, true)
    doneTitle.gravity = android.view.Gravity.CENTER
    doneTitle.alpha = 0f
    done.addView(doneTitle)

    val doneSub = txt("Seu saldo já foi atualizado.", 14f, cDim)
    doneSub.gravity = android.view.Gravity.CENTER
    doneSub.alpha = 0f
    doneSub.setPadding(0, dpi(6), 0, dpi(12))
    done.addView(doneSub)

    val stage = android.widget.FrameLayout(this)
    stage.addView(pending, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
    stage.addView(done, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
    card.addView(stage, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))

    // pulsa o texto de espera enquanto aguarda
    val pulse = android.animation.ObjectAnimator.ofFloat(waiting, "alpha", 1f, 0.35f).apply {
        duration = 1100L
        repeatCount = android.animation.ObjectAnimator.INFINITE
        repeatMode = android.animation.ObjectAnimator.REVERSE
    }
    pulse.start()

    val onCredited: (String) -> Unit = { id ->
        if (id == identifier) {
            depositCreditListener = null
            pulse.cancel()
            pending.animate().alpha(0f).setDuration(250L).withEndAction {
                pending.visibility = android.view.View.GONE
                done.visibility = android.view.View.VISIBLE
                circle.animate().scaleX(1f).scaleY(1f).setDuration(650L)
                    .setInterpolator(android.view.animation.OvershootInterpolator(2f)).start()
                doneTitle.animate().alpha(1f).setStartDelay(300L).setDuration(400L).start()
                doneSub.animate().alpha(1f).setStartDelay(420L).setDuration(400L).start()
                Handler(Looper.getMainLooper()).postDelayed({
                    if (dlg.isShowing) dlg.dismiss()
                }, 2200L)
            }.start()
        }
    }
    depositCreditListener = onCredited
    dlg.setOnDismissListener {
        pulse.cancel()
        if (depositCreditListener === onCredited) depositCreditListener = null
    }

    dlg.setContentView(card)
    val w = dlg.window
    if (w != null) {
        w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        w.setDimAmount(0.65f)
        val width = kotlin.math.min(resources.displayMetrics.widthPixels - dpi(40), dpi(380))
        w.setLayout(width, android.view.WindowManager.LayoutParams.WRAP_CONTENT)
    }
    dlg.show()
}

// ------------------------------------------------------------------ utilitários

private fun secondsLeft(deadline: Long): Long {
    val now = System.currentTimeMillis() + Game.serverOffset
    return max(0L, (deadline - now + 999) / 1000)
}

private fun JSONArray.toSet(): Set<Int> {
    val s = HashSet<Int>()
    for (i in 0 until length()) s.add(optInt(i))
    return s
}

internal fun parseCents(text: String): Long? {
    val t = text.trim().replace("R$", "").replace(" ", "").replace(",", ".")
    if (t.isEmpty()) return null
    val v = t.toDoubleOrNull() ?: return null
    return Math.round(v * 100.0)
}

private fun randomCode(): String {
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    val r = java.util.Random()
    return (1..6).map { chars[r.nextInt(chars.length)] }.joinToString("")
}

private fun cell(a: MainActivity, size: Int, fill: Int, stroke: Int): TextView {
    val t = CellView(a)
    t.gravity = Gravity.CENTER
    t.textSize = 18f
    t.setTextColor(cWhite)
    val g = GradientDrawable()
    g.cornerRadius = a.dp(12f)
    g.setColor(fill)
    g.setStroke(a.dpi(1), stroke)
    t.background = g
    val lp = LinearLayout.LayoutParams(size, size)
    lp.setMargins(a.dpi(3), a.dpi(3), a.dpi(3), a.dpi(3))
    t.layoutParams = lp
    return t
}

private fun style(t: TextView, a: MainActivity, fill: Int, stroke: Int, text: String = "", icon: Int = -1) {
    val g = GradientDrawable()
    g.cornerRadius = a.dp(12f)
    g.setColor(fill)
    g.setStroke(a.dpi(1), stroke)
    t.background = g
    t.text = text
    if (t is CellView) {
        t.icon = icon
        t.invalidate()
    }
}

private const val FILL_IDLE = 0x33FFFFFF
private const val STROKE_IDLE = 0x55FFFFFF
private const val FILL_OK = 0x5522C55E
private const val FILL_BOMB = 0x77EF4444
private const val FILL_SEL = 0x667C4DFF

/** Tabuleiro 5x5. `bind` pinta cada casa; `onTap` (opcional) trata o toque. */
private fun MainActivity.board(
    sizePx: Int,
    bind: (TextView, Int) -> Unit,
    onTap: ((Int, TextView) -> Unit)?
): LinearLayout {
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.gravity = Gravity.CENTER_HORIZONTAL
    val cs = sizePx / 5 - dpi(6)
    var idx = 0
    for (r in 0 until 5) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (c in 0 until 5) {
            val i = idx++
            val t = cell(this, cs, FILL_IDLE, STROKE_IDLE)
            bind(t, i)
            if (onTap != null) {
                t.isClickable = true
                t.setOnClickListener { onTap(i, t) }
                t.pressable()
            }
            row.addView(t)
        }
        col.addView(row)
    }
    return col
}

private fun MainActivity.boardSize(maxDp: Int = 340): Int =
    min(resources.displayMetrics.widthPixels - dpi(40), dpi(maxDp))

// ------------------------------------------------------------------ criar sala

internal fun MainActivity.showCreateRoom() {
    if (!Game.connected) {
        // silencioso: servidor acordando
        return
    }
    var mines = 5
    val v = scaffold("Criar sala", "Monte seu x1 em poucos toques.") {
        put(card {
            put(label("NOME DA SALA"), 0)
            val nameIn = input("Ex.: Duelo dos amigos", "")
            nameIn.filters = arrayOf(InputFilter.LengthFilter(24))
            put(nameIn, 8)

            put(txt("Só entra quem tiver o código da sala.", 12f, cFaint), 8)

            put(label("VALOR DO X1 (R$)"), 18)
            val stakeIn = input("Ex.: 2,00", "")
            stakeIn.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            put(stakeIn, 8)
            val calc = txt("", 13f, cDim)
            put(calc, 8)
            fun recalc() {
                val c = parseCents(stakeIn.text.toString())
                calc.text = if (c == null || c <= 0) {
                    "Mínimo ${money(Game.minStakeCents)} · máximo ${money(Game.maxStakeCents)}"
                } else {
                    val fee = Game.feeOf(c)
                    "Cada jogador paga ${money(c + fee)} (${money(c)} + taxa de ${money(fee)}). O vencedor leva ${money(c * 2)}."
                }
            }
            recalc()
            stakeIn.addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { recalc() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })

            val codeLabel = put(label("CÓDIGO DA SALA"), 18)
            val codeRow = LinearLayout(this@showCreateRoom)
            codeRow.orientation = LinearLayout.HORIZONTAL
            val codeIn = input("4 a 20 letras ou números", randomCode())
            codeIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            codeIn.filters = arrayOf(InputFilter.LengthFilter(20), InputFilter.AllCaps())
            val gen = button("Gerar", false) { codeIn.setText(randomCode()) }
            gen.setPadding(dpi(18), dpi(14), dpi(18), dpi(14))
            codeRow.addView(codeIn, LinearLayout.LayoutParams(0, WRAP, 1f))
            val glp = LinearLayout.LayoutParams(WRAP, WRAP)
            glp.leftMargin = dpi(8)
            codeRow.addView(gen, glp)
            put(codeRow, 8)
            codeLabel.visibility = View.GONE
            codeRow.visibility = View.GONE
            val custom = txt("Personalizar código", 13f, 0xFFA78BFA.toInt(), true)
            custom.setPadding(0, dpi(12), 0, dpi(4))
            custom.isClickable = true
            custom.setOnClickListener {
                codeLabel.visibility = View.VISIBLE
                codeRow.visibility = View.VISIBLE
                custom.visibility = View.GONE
            }
            put(custom, 8)
            put(txt("O código é gerado sozinho. Você poderá copiá-lo na sala.", 12f, cFaint), 4)

            put(label("MINAS POR JOGADOR"), 18)
            val mRow = LinearLayout(this@showCreateRoom)
            mRow.orientation = LinearLayout.HORIZONTAL
            mRow.gravity = Gravity.CENTER_VERTICAL
            val minus = button("−", false) {}
            val plus = button("+", false) {}
            val num = txt("$mines", 26f, cWhite, true)
            num.gravity = Gravity.CENTER
            minus.setOnClickListener { if (mines > 1) { mines--; num.text = "$mines" } }
            plus.setOnClickListener { if (mines < Game.maxMines) { mines++; num.text = "$mines" } }
            val bw = dpi(64)
            mRow.addView(minus, LinearLayout.LayoutParams(bw, WRAP))
            mRow.addView(num, LinearLayout.LayoutParams(0, WRAP, 1f))
            mRow.addView(plus, LinearLayout.LayoutParams(bw, WRAP))
            put(mRow, 8)
            put(txt("O tabuleiro tem 25 casas. Quanto mais minas, mais arriscado.", 12f, cFaint), 8)

            lateinit var go: TextView
            go = button("Criar sala") {
                val name = nameIn.text.toString().trim()
                val cents = parseCents(stakeIn.text.toString())
                val code = codeIn.text.toString().trim().uppercase(Locale.ROOT)
                when {
                    name.length < 3 -> toast("Dê um nome para a sala (mínimo 3 letras).")
                    cents == null || cents < Game.minStakeCents || cents > Game.maxStakeCents ->
                        toast("O valor precisa estar entre ${money(Game.minStakeCents)} e ${money(Game.maxStakeCents)}.")
                    code.length < 4 -> toast("O código precisa ter pelo menos 4 caracteres.")
                    else -> {
                        Game.send(
                            "create",
                            "name" to name, "code" to code, "stakeCents" to cents,
                            "mines" to mines, "isPublic" to false
                        )
                    }
                }
            }
            put(go, 22)
        }, 0)
        put(button("Voltar", false) { showTab(0) }, 12)
    }
    GameUi.stopTicker()
    GameUi.wizardOpen = true
    setScreen(v, false)
}

// ------------------------------------------------------------------ entrar por código

internal fun MainActivity.askJoinCode(prefill: String = "") {
    if (!Game.connected) {
        // silencioso: servidor acordando
        return
    }
    val e = input("CÓDIGO", prefill)
    e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    e.filters = arrayOf(
        InputFilter { src, s, en, _, _, _ ->
            val sb = StringBuilder()
            for (i in s until en) if (src[i].isLetterOrDigit()) sb.append(src[i])
            if (sb.length == en - s) null else sb.toString()
        },
        InputFilter.AllCaps(),
        InputFilter.LengthFilter(20)
    )
    e.gravity = Gravity.CENTER
    e.textSize = 24f
    e.letterSpacing = 0.18f
    e.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    e.imeOptions = EditorInfo.IME_ACTION_DONE
    e.setPadding(dpi(16), dpi(16), dpi(16), dpi(16))
    e.setSelection(e.text.length)

    val paste = txt("Colar código copiado", 13f, 0xFFA78BFA.toInt(), true)
    paste.gravity = Gravity.CENTER
    paste.setPadding(dpi(12), dpi(12), dpi(12), dpi(4))
    paste.setOnClickListener {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val raw = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).text?.toString() ?: "" else ""
        val clean = raw.filter { it.isLetterOrDigit() }.uppercase(Locale.ROOT).take(20)
        if (clean.isEmpty()) toast("Nada para colar.") else { e.setText(clean); e.setSelection(clean.length) }
    }

    val body = LinearLayout(this)
    body.orientation = LinearLayout.VERTICAL
    body.addView(e, LinearLayout.LayoutParams(MATCH, WRAP))
    body.addView(paste, LinearLayout.LayoutParams(MATCH, WRAP))

    fun submit(): Boolean {
        val code = e.text.toString().trim().uppercase(Locale.ROOT)
        if (code.length < 4) {
            toast("Digite o código completo (4 a 20 letras ou números).")
            return false
        }
        GameUi.joinCode = code
        Game.send("join_info", "code" to code)
        return true
    }

    val dlg = glassDialog(
        title = "Entrar em uma sala",
        message = "Digite o código que seu adversário te passou.",
        content = body,
        positive = "Continuar"
    ) { submit() }
    e.setOnEditorActionListener { _, _, _ ->
        if (submit()) dlg.dismiss()
        true
    }
    e.requestFocus()
}

internal fun MainActivity.showJoinConfirm(o: JSONObject) {
    val stake = o.optLong("stakeCents")
    val fee = o.optLong("feeCents")

    val body = LinearLayout(this)
    body.orientation = LinearLayout.VERTICAL
    fun row(k: String, v: String, bold: Boolean = false) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.addView(txt(k, 14f, cDim), LinearLayout.LayoutParams(0, WRAP, 1f))
        r.addView(txt(v, 14f, cWhite, bold))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dpi(8)
        body.addView(r, lp)
    }
    row("Sala", o.optString("name"), true)
    row("Criada por", o.optString("creator"))
    row("Minas", o.optInt("mines").toString())
    row("Aposta", money(stake))
    row("Taxa", money(fee))
    row("Total a pagar", money(stake + fee), true)
    row("Quem vencer leva", money(stake * 2), true)

    glassDialog(
        title = "Entrar na sala?",
        content = body,
        positive = "Entrar",
        negative = "Não"
    ) {
        Game.send("join", "code" to o.optString("code", GameUi.joinCode))
        true
    }
}

// ------------------------------------------------------------------ lista de salas (aba Salas)

internal fun MainActivity.buildRoomList(): ScrollView {
    val v = scaffold("Amigos", "Jogue um x1 com um amigo: crie uma sala ou entre com o código.") {
        put(iconText(ICON_WALLET, "Saldo: " + money(me?.optLong("balance_cents", 0L) ?: 0L), 14f, cWhite, true), 0)
        put(card {
            put(txt("Criar sala", 20f, cWhite, true), 0)
            put(txt("Defina nome, valor e minas. Depois é só passar o código para seu adversário.", 13f, cDim), 4)
            put(button("Criar sala") { showCreateRoom() }, 14)
        }, 0)
        put(card {
            put(txt("Entrar em uma sala", 20f, cWhite, true), 0)
            put(txt("Recebeu um código de um amigo? Digite aqui para entrar.", 13f, cDim), 4)
            put(button("Entrar com código", false) { askJoinCode() }, 14)
        }, 14)
    }
    GameUi.stopTicker()
    return v
}

/** Desenha as salas públicas em `box` (no máximo `limit`). Salas públicas entram direto, sem código. */
internal fun MainActivity.renderRoomItems(box: LinearLayout?, limit: Int) {
    if (box == null) return
    box.removeAllViews()
    val list = GameUi.lastRooms
    if (list.length() == 0) {
        val t = txt(if (Game.connected) "Nenhuma sala pública aberta agora." else "Carregando salas…", 14f, cDim)
        t.gravity = Gravity.CENTER
        t.setPadding(0, dpi(18), 0, dpi(18))
        box.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
        return
    }
    for (i in 0 until min(limit, list.length())) {
        val r = list.getJSONObject(i)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
        row.background = glass(20f)
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(txt(r.optString("name"), 16f, cWhite, true))
        left.addView(iconText(ICON_BOMB, "${r.optInt("mines")} minas  ·  por ${r.optString("creator")}", 12.5f, cDim))
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(txt(money(r.optLong("stakeCents")), 17f, cWhite, true))
        row.isClickable = true
        row.setOnClickListener {
            if (!Game.connected) { /* silencioso */ }
            else Game.send("join_info", "id" to r.optString("id"))
        }
        row.pressable()
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dpi(10)
        box.addView(row, lp)
    }
}

// ------------------------------------------------------------------ sala / partida

internal fun MainActivity.renderRoom() {
    val st = Game.state
    if (st == null) return
    GameUi.inRoomScreen = true
    GameUi.wizardOpen = false
    GameUi.roomsBox = null
    GameUi.lobbyBox = null
    val status = st.optString("status")
    val turn = if (st.isNull("turn")) "" else st.optString("turn")
    val animate = status != GameUi.lastStatus
    if (animate) GameUi.animDone = false
    GameUi.lastStatus = status
    GameUi.lastTurn = turn
    GameUi.tickFn = null
    val v = when (status) {
        "waiting" -> roomWaiting(st)
        "lobby" -> roomLobby(st)
        "checkout" -> roomCheckout(st)
        "placing" -> roomPlacing(st)
        "playing" -> roomPlaying(st)
        else -> roomOver(st)
    }
    setScreen(v, false, animate)
    GameUi.startTicker()
}

private fun playersOf(st: JSONObject): List<JSONObject> {
    val a = st.optJSONArray("players") ?: JSONArray()
    return (0 until a.length()).map { a.getJSONObject(it) }
}

private fun LinearLayout.header(a: MainActivity, st: JSONObject, sub: String) {
    with(a) {
        put(txt(st.optString("name"), 26f, cWhite, true), 0)
        put(txt(sub, 14f, cDim), 4)
        val line = "${st.optInt("mines")} minas  ·  Valor ${money(st.optLong("stakeCents"))}  ·  Taxa ${money(st.optLong("feeCents"))}"
        put(iconText(ICON_BOMB, line, 13f, cDim), 8)
    }
}

private fun LinearLayout.leaveButton(a: MainActivity, label: String = "Sair da sala") {
    with(a) { put(button(label, false) { GameUi.confirmLeave(a) }, 12) }
}

private fun MainActivity.roomWaiting(st: JSONObject): ScrollView = scaffold("", "") {
    header(this@roomWaiting, st, "Aguardando um adversário…")
    put(card {
        put(label("CÓDIGO DA SALA"), 0)
        val code = txt(st.optString("code"), 36f, cWhite, true)
        code.letterSpacing = 0.15f
        code.gravity = Gravity.CENTER
        put(code, 10)
        put(txt("Só entra quem tiver o código da sala.", 12f, cFaint), 10)
        put(button("Copiar código", false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("codigo", st.optString("code")))
            toast("Código copiado!")
        }, 14)
    }, 18)
    val dots = txt("Procurando…", 14f, cDim)
    dots.gravity = Gravity.CENTER
    put(dots, 18)
    GameUi.tickFn = {
        val n = ((System.currentTimeMillis() / 500) % 4).toInt()
        dots.text = "Aguardando adversário" + ".".repeat(n)
    }
    leaveButton(this@roomWaiting)
}

private fun MainActivity.playerChip(p: JSONObject, extra: String, ok: Boolean): LinearLayout {
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.gravity = Gravity.CENTER_HORIZONTAL
    val av = AvatarView(this)
    av.setPerson(p.optString("name"), p.optString("avatar"))
    box.addView(av, LinearLayout.LayoutParams(dpi(84), dpi(84)))
    val n = nameWithBadge(p.optString("name"), 15f, p.optBoolean("verified"), center = true)
    n.setPadding(0, dpi(8), 0, 0)
    box.addView(n)
    val s = txt(extra, 12f, if (ok) 0xFF4ADE80.toInt() else cDim)
    s.gravity = Gravity.CENTER
    box.addView(s)
    return box
}

private fun MainActivity.vsRow(st: JSONObject, extra: (JSONObject) -> Pair<String, Boolean>): LinearLayout {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    val ps = playersOf(st)
    for ((i, p) in ps.withIndex()) {
        if (i == 1) {
            val vs = txt("VS", 18f, cDim, true)
            vs.gravity = Gravity.CENTER
            row.addView(vs, LinearLayout.LayoutParams(dpi(44), WRAP))
        }
        val (t, ok) = extra(p)
        row.addView(playerChip(p, t, ok), LinearLayout.LayoutParams(0, WRAP, 1f))
    }
    return row
}

private fun MainActivity.roomLobby(st: JSONObject): ScrollView = scaffold("", "") {
    val you = st.optString("you")
    header(this@roomLobby, st, "Sala completa! Confirmem para começar.")
    put(card {
        put(vsRow(st) { p ->
            if (p.optBoolean("confirmed")) Pair("Confirmou", true) else Pair("Aguardando…", false)
        }, 0)
    }, 18)
    val me = playersOf(st).firstOrNull { it.optString("id") == you }
    if (me != null && me.optBoolean("confirmed")) {
        val t = txt("Aguardando o adversário confirmar a partida…", 14f, cDim)
        t.gravity = Gravity.CENTER
        put(t, 20)
    } else {
        put(button("Confirmar partida") { Game.send("confirm") }, 20)
    }
    leaveButton(this@roomLobby)
}

private fun MainActivity.roomCheckout(st: JSONObject): ScrollView = scaffold("", "") {
    val you = st.optString("you")
    val stake = st.optLong("stakeCents")
    val fee = st.optLong("feeCents")
    header(this@roomCheckout, st, "Pagamento da partida")
    put(card {
        put(txt("Valor do x1: ${money(stake)}", 15f, cWhite), 0)
        put(txt("Taxa do app: ${money(fee)}", 15f, cWhite), 8)
        put(txt("Total: ${money(stake + fee)}", 22f, cWhite, true), 14)
        put(txt("O vencedor leva ${money(stake * 2)}. Se a partida for cancelada antes de começar, o valor volta para o seu saldo.", 12f, cFaint), 10)
    }, 18)
    val saldo = (me?.optLong("balance_cents", 0L) ?: 0L)
    put(txt("Seu saldo: ${money(saldo)}", 13f, cDim), 12)
    val mine = playersOf(st).firstOrNull { it.optString("id") == you }
    val timer = txt("", 13f, cDim)
    timer.gravity = Gravity.CENTER
    if (mine != null && mine.optBoolean("paid")) {
        put(iconText(ICON_CHECK, "Pagamento feito. Aguardando o adversário pagar…", 14f, 0xFF4ADE80.toInt(), center = true), 18)
    } else {
        lateinit var pay: TextView
        pay = button("Pagar ${money(stake + fee)}") {
            promptPin("Confirmar pagamento", "Digite sua senha de 6 dígitos para autorizar o pagamento de ${money(stake + fee)}:") { pin ->
                busy(pay, true)
                Game.send("pay", "pin" to pin)
            }
        }
        put(pay, 18)
    }
    put(timer, 12)
    val dl = st.optLong("deadline")
    GameUi.tickFn = { if (dl > 0) timer.text = "Tempo para pagar: ${secondsLeft(dl)}s" }
    leaveButton(this@roomCheckout, "Cancelar e sair")
}

private fun MainActivity.roomPlacing(st: JSONObject): ScrollView = scaffold("", "") {
    val you = st.optString("you")
    val need = st.optInt("mines")
    val mine = playersOf(st).firstOrNull { it.optString("id") == you }
    val placed = mine != null && mine.optBoolean("placed")
    put(txt("Esconda suas minas", 26f, cWhite, true), 0)
    val timer = txt("", 13f, cDim)
    if (placed) {
        put(iconText(ICON_CHECK, "Minas escondidas", 14f, 0xFF4ADE80.toInt()), 4)
        val boardSize = boardSize()
        val own = st.optJSONArray("myMines")?.toSet() ?: emptySet()
        put(board(boardSize, { t, i -> if (i in own) style(t, this@roomPlacing, FILL_BOMB, STROKE_IDLE, icon = ICON_BOMB) }, null), 16, boardSize)
        val t = txt("Aguardando o adversário terminar a configuração das minas", 14f, cDim)
        t.gravity = Gravity.CENTER
        put(t, 18)
    } else {
        put(txt("Escolha $need casa(s) do SEU tabuleiro. O adversário vai tentar adivinhar onde elas estão.", 14f, cDim), 4)
        val selected = HashSet<Int>()
        val counter = txt("0 / $need", 16f, cWhite, true)
        counter.gravity = Gravity.CENTER
        lateinit var go: TextView
        val boardSize = boardSize()
        put(board(boardSize, { _, _ -> }, { i, t ->
            if (selected.contains(i)) {
                selected.remove(i)
                style(t, this@roomPlacing, FILL_IDLE, STROKE_IDLE, "")
            } else if (selected.size < need) {
                selected.add(i)
                style(t, this@roomPlacing, FILL_SEL, STROKE_IDLE, icon = ICON_BOMB)
            }
            counter.text = "${selected.size} / $need"
            go.alpha = if (selected.size == need) 1f else 0.5f
        }), 16, boardSize)
        put(counter, 12)
        go = button("Confirmar minas") {
            if (selected.size != need) {
                toast("Escolha exatamente $need casa(s).")
            } else {
                busy(go, true)
                val arr = JSONArray()
                for (c in selected) arr.put(c)
                Game.send("place_mines", "cells" to arr)
            }
        }
        go.alpha = 0.5f
        put(go, 12)
        put(button("Escolher aleatório", false) { toast("Se o tempo acabar, escolhemos por você.") }, 10)
    }
    timer.gravity = Gravity.CENTER
    put(timer, 12)
    val dl = st.optLong("deadline")
    GameUi.tickFn = { if (dl > 0) timer.text = "Tempo: ${secondsLeft(dl)}s" }
    leaveButton(this@roomPlacing, "Cancelar e sair")
}

private const val ANIM_MS = 3500L

private fun MainActivity.roomPlaying(st: JSONObject): ScrollView {
    val you = st.optString("you")
    val startedAt = st.optLong("startedAt")
    val startedLocal = startedAt
    val inAnim = !GameUi.animDone && startedLocal > 0 &&
        (System.currentTimeMillis() + Game.serverOffset) < startedLocal + ANIM_MS
    val ps = playersOf(st)
    val opp = ps.firstOrNull { it.optString("id") != you }

    if (inAnim) {
        return scaffold("", "") {
            val title = txt("Sorteando quem começa…", 22f, cWhite, true)
            title.gravity = Gravity.CENTER
            put(title, 100)
            val who = txt("", 30f, cWhite, true)
            who.gravity = Gravity.CENTER
            put(who, 30)
            val first = st.optString("first")
            val firstName = ps.firstOrNull { it.optString("id") == first }?.optString("name") ?: ""
            GameUi.tickFn = {
                val now = System.currentTimeMillis() + Game.serverOffset
                val end = startedLocal + ANIM_MS
                if (now >= end) {
                    GameUi.animDone = true
                    renderRoom()
                } else if (now >= end - 900) {
                    who.text = if (first == you) "Você começa!" else "$firstName começa"
                    title.text = "Sorteado!"
                } else {
                    who.text = ps[((now / 140) % max(1, ps.size)).toInt()].optString("name")
                }
            }
        }
    }

    val turn = if (st.isNull("turn")) "" else st.optString("turn")
    val myTurn = turn == you
    val picks = st.optJSONArray("myPicks")?.toSet() ?: emptySet()
    val hits = st.optJSONArray("hitsOnMe")?.toSet() ?: emptySet()
    val mines = st.optJSONArray("myMines")?.toSet() ?: emptySet()
    val dl = st.optLong("deadline")

    return scaffold("", "") {
        put(txt(st.optString("name"), 20f, cWhite, true), 0)
        val banner = txt(if (myTurn) "Sua vez! Abra uma casa do tabuleiro do adversário." else "Vez de ${opp?.optString("name") ?: "adversário"}…", 15f, if (myTurn) 0xFF4ADE80.toInt() else cDim, true)
        put(banner, 6)
        val timer = txt("", 26f, cWhite, true)
        timer.gravity = Gravity.CENTER
        put(timer, 8)
        GameUi.tickFn = {
            if (dl > 0) {
                val s = secondsLeft(dl)
                timer.text = "${s}s"
                timer.setTextColor(if (s <= 5) 0xFFF87171.toInt() else cWhite)
            }
        }

        put(label("TABULEIRO DE ${opp?.optString("name")?.uppercase(Locale.ROOT) ?: "ADVERSÁRIO"}"), 12)
        val size = boardSize()
        put(board(size, { t, i ->
            if (i in picks) style(t, this@roomPlaying, FILL_OK, STROKE_IDLE, icon = ICON_CHECK)
        }, if (myTurn) { i, t ->
            if (i !in picks) {
                if (Game.send("pick", "cell" to i)) {
                    t.text = "…"
                }
            }
        } else null), 8, size)

        put(label("SEU TABULEIRO"), 18)
        val small = min(size, dpi(220))
        put(board(small, { t, i ->
            t.textSize = 12f
            val bomb = i in mines
            val hit = i in hits
            when {
                bomb && hit -> style(t, this@roomPlaying, FILL_BOMB, STROKE_IDLE, icon = ICON_BLAST)
                bomb -> style(t, this@roomPlaying, FILL_SEL, STROKE_IDLE, icon = ICON_BOMB)
                hit -> style(t, this@roomPlaying, FILL_OK, STROKE_IDLE, icon = ICON_CHECK)
            }
        }, null), 8, small)
        leaveButton(this@roomPlaying, "Desistir e sair")
    }
}

private fun MainActivity.roomOver(st: JSONObject): ScrollView = scaffold("", "") {
    val res = st.optJSONObject("result")
    val won = res?.optBoolean("youWon") ?: false
    val reason = res?.optString("reason") ?: ""
    val rm = st.optJSONObject("rematch")
    val left = st.optBoolean("opponentLeft")
    val tone = if (won) 0xFF4ADE80.toInt() else 0xFFF87171.toInt()
    put(IconView(this@roomOver, if (won) ICON_TROPHY else ICON_X, tone), 30, dpi(64), dpi(64))
    val title = txt(if (won) "Você ganhou!" else "Você perdeu", 32f, tone, true)
    title.gravity = Gravity.CENTER
    put(title, 12)
    val why = when (reason) {
        "mina" -> if (won) "O adversário abriu uma mina." else "Você abriu uma mina."
        "tempo" -> "O tempo/casas acabaram."
        "abandono" -> if (won) "O adversário saiu da partida." else "Você saiu da partida."
        else -> ""
    }
    if (why.isNotEmpty()) {
        val w = txt(why, 14f, cDim)
        w.gravity = Gravity.CENTER
        put(w, 8)
    }
    val prize = txt(if (won) "+ ${money(res?.optLong("prizeCents") ?: 0L)} no seu saldo" else "- ${money(st.optLong("stakeCents") + st.optLong("feeCents"))}", 20f, cWhite, true)
    prize.gravity = Gravity.CENTER
    put(prize, 14)

    val opp = res?.optJSONArray("oppMines")?.toSet() ?: emptySet()
    val picks = st.optJSONArray("myPicks")?.toSet() ?: emptySet()
    if (opp.isNotEmpty()) {
        put(label("MINAS DO ADVERSÁRIO"), 22)
        val size = min(boardSize(), dpi(240))
        put(board(size, { t, i ->
            t.textSize = 14f
            if (i in opp) style(t, this@roomOver, FILL_BOMB, STROKE_IDLE, icon = ICON_BOMB)
            else if (i in picks) style(t, this@roomOver, FILL_OK, STROKE_IDLE, icon = ICON_CHECK)
        }, null), 8, size)
    }

    val rematchNote = when {
        left -> "O adversário saiu da sala."
        rm != null && rm.optBoolean("you") -> "Revanche pedida. Aguardando o adversário…"
        rm != null && rm.optBoolean("opp") -> "O adversário pediu revanche!"
        else -> ""
    }
    if (rematchNote.isNotEmpty()) {
        val n = txt(rematchNote, 13f, cDim)
        n.gravity = Gravity.CENTER
        put(n, 16)
    }
    if (!left && !(rm != null && rm.optBoolean("you"))) {
        put(button("Pedir revanche") { Game.send("rematch") }, 20)
    }
    put(button(if (won) "Terminar partida" else "Voltar para o Lobby", false) { Game.send("leave") }, 12)
}
