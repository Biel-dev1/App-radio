package com.duelominas

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

const val MATCH = -1
const val WRAP = -2

val cWhite = 0xFFFFFFFF.toInt()
val cDim = 0xB3FFFFFF.toInt()
val cFaint = 0x80FFFFFF.toInt()

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

const val ICON_GRID = 0
const val ICON_MIC = 1
const val ICON_BT = 2
const val ICON_PROFILE = 3
const val ICON_CHAT = 4
const val ICON_HOME = 5
const val ICON_TROPHY = 6

/** Efeito de toque: o botão "afunda" um pouquinho ao ser pressionado. */
fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
        }
        false
    }
}

/** Desenha um ícone de traço dentro de uma caixa de 24x24 unidades centrada em (cx, cy). */
fun drawIcon(c: Canvas, kind: Int, cx: Float, cy: Float, u: Float, p: Paint) {
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    p.strokeJoin = Paint.Join.ROUND
    p.strokeWidth = 1.8f
    p.shader = null
    c.save()
    c.translate(cx, cy)
    c.scale(u, u)
    when (kind) {
        ICON_GRID -> {
            c.drawRoundRect(RectF(-9f, -9f, -1.5f, -1.5f), 2.5f, 2.5f, p)
            c.drawRoundRect(RectF(1.5f, -9f, 9f, -1.5f), 2.5f, 2.5f, p)
            c.drawRoundRect(RectF(-9f, 1.5f, -1.5f, 9f), 2.5f, 2.5f, p)
            c.drawRoundRect(RectF(1.5f, 1.5f, 9f, 9f), 2.5f, 2.5f, p)
        }
        ICON_MIC -> {
            c.drawRoundRect(RectF(-3.5f, -10f, 3.5f, 3f), 3.5f, 3.5f, p)
            val arc = Path()
            arc.addArc(RectF(-7f, -5f, 7f, 9f), 0f, 180f)
            c.drawPath(arc, p)
            c.drawLine(0f, 9f, 0f, 12f, p)
        }
        ICON_BT -> {
            val path = Path()
            path.moveTo(-5f, -5f)
            path.lineTo(5f, 5f)
            path.lineTo(0f, 10f)
            path.lineTo(0f, -10f)
            path.lineTo(5f, -5f)
            path.lineTo(-5f, 5f)
            c.drawPath(path, p)
        }
        ICON_PROFILE -> {
            c.drawCircle(0f, -4.5f, 4.2f, p)
            val body = Path()
            body.addArc(RectF(-8.5f, 3f, 8.5f, 20f), 180f, 180f)
            c.drawPath(body, p)
        }
        ICON_HOME -> {
            val roof = Path()
            roof.moveTo(-9.5f, 0f)
            roof.lineTo(0f, -9f)
            roof.lineTo(9.5f, 0f)
            c.drawPath(roof, p)
            val body = Path()
            body.moveTo(-6.5f, -2.5f)
            body.lineTo(-6.5f, 9f)
            body.lineTo(6.5f, 9f)
            body.lineTo(6.5f, -2.5f)
            c.drawPath(body, p)
        }
        ICON_TROPHY -> {
            c.drawRoundRect(RectF(-10f, 1f, -3.5f, 9f), 1.5f, 1.5f, p)
            c.drawRoundRect(RectF(-3.5f, -8f, 3.5f, 9f), 1.5f, 1.5f, p)
            c.drawRoundRect(RectF(3.5f, 4f, 10f, 9f), 1.5f, 1.5f, p)
        }
        else -> {
            c.drawRoundRect(RectF(-9.5f, -8.5f, 9.5f, 5f), 4f, 4f, p)
            val tail = Path()
            tail.moveTo(-3.5f, 5f)
            tail.lineTo(-3.5f, 10f)
            tail.lineTo(2f, 5f)
            c.drawPath(tail, p)
        }
    }
    c.restore()
}

/** Fundo de "vidro": gradiente translúcido + brilho + borda que reflete a luz. */
class GlassDrawable(
    private val radius: Float,
    private val strokePx: Float,
    private val strength: Float = 1f,
    private val base: Int = 0x33000000
) : Drawable() {
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        basePaint.color = base
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = strokePx
    }

    private fun a(v: Int): Int = ((v * strength).toInt().coerceIn(0, 255) shl 24) or 0x00FFFFFF

    override fun onBoundsChange(bounds: Rect) {
        rect.set(bounds)
        rect.inset(strokePx, strokePx)
        val l = bounds.left.toFloat()
        val t = bounds.top.toFloat()
        val r = bounds.right.toFloat()
        val b = bounds.bottom.toFloat()
        fill.shader = LinearGradient(0f, t, 0f, b, a(0x42), a(0x0E), Shader.TileMode.CLAMP)
        stroke.shader = LinearGradient(
            l, t, r, b,
            intArrayOf(a(0xB8), a(0x14), a(0x14), a(0x78)),
            floatArrayOf(0f, 0.4f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        canvas.drawRoundRect(rect, radius, radius, basePaint)
        canvas.drawRoundRect(rect, radius, radius, fill)
        canvas.drawRoundRect(rect, radius, radius, stroke)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Fundo escuro com manchas de cor que flutuam devagar (dá o que "refratar" no vidro). */
class AuroraBackground(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 22000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    private fun blob(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        p.shader = RadialGradient(
            cx, cy, r,
            (color and 0x00FFFFFF) or 0x80000000.toInt(), color and 0x00FFFFFF,
            Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r, p)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val a = 2f * PI.toFloat() * t
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF0A0F2C.toInt(), 0xFF140B2E.toInt(), 0xFF0A1A2C.toInt()),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, p)
        blob(canvas, w * (0.22f + 0.12f * sin(a)), h * (0.16f + 0.05f * cos(a)), w * 0.75f, 0xFF7C4DFF.toInt())
        blob(canvas, w * (0.85f + 0.08f * cos(a)), h * (0.45f + 0.07f * sin(a)), w * 0.70f, 0xFF06B6D4.toInt())
        blob(canvas, w * (0.25f + 0.10f * cos(a + 1.5f)), h * (0.85f + 0.05f * sin(a + 1f)), w * 0.80f, 0xFFEC4899.toInt())
    }
}

/**
 * Barra flutuante estilo "Liquid Glass": encosta o dedo e a bolha de vidro cresce, gruda no dedo,
 * acompanha o arrasto com física de mola (estica na velocidade e balança ao parar) e amplia o ícone.
 */
class GlassNavBar(
    ctx: Context,
    private val tabs: List<Pair<Int, String>>,
    private val onSelect: (Int) -> Unit
) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val pad = d * 8f
    private val bg = GlassDrawable(d * 34f, d * 1.2f, 1.2f, 0x73101030)
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = d * 10.5f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()
    private val clip = Path()

    var selected = 0
        private set

    // estado da física
    private var bx = 0f
    private var bv = 0f
    private var target = 0f
    private var pressAmt = 0f
    private var lastNs = 0L
    private var dragging = false
    private var fingerX = 0f
    private var hover = -1

    private fun tabW(): Float = (width - 2f * pad) / tabs.size
    private fun centerX(i: Int): Float = pad + tabW() * (i + 0.5f)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        bg.setBounds(0, 0, w, h)
        bx = centerX(selected)
        target = bx
        bv = 0f
    }

    fun select(i: Int, animate: Boolean) {
        selected = i
        if (!dragging) target = centerX(i)
        if (!animate || width == 0) {
            bx = target
            bv = 0f
        }
        invalidate()
    }

    private fun step(dt: Float) {
        val k = if (dragging) 900f else 420f
        val c = if (dragging) 52f else 24f
        val sub = 2
        val h = dt / sub
        for (n in 0 until sub) {
            val a = k * (target - bx) - c * bv
            bv += a * h
            bx += bv * h
        }
        val goal = if (dragging) 1f else 0f
        pressAmt += (goal - pressAmt) * min(1f, dt * 14f)
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else min(0.032f, (now - lastNs) / 1e9f)
        lastNs = now
        if (dragging) target = fingerX.coerceIn(centerX(0), centerX(tabs.size - 1))
        step(dt)

        bg.draw(canvas)
        val tw = tabW()
        val h = height.toFloat()

        val maxStretch = tw * 0.35f
        val stretch = min(maxStretch, abs(bv) * 0.035f)
        val squash = 1f - 0.12f * (stretch / maxStretch)
        val hw = (tw * 0.5f - d * 3f + stretch) * (1f + 0.16f * pressAmt)
        val hh = min(h / 2f - d * 1.5f, (h / 2f - d * 6f) * (1f + 0.2f * pressAmt) * squash)
        rect.set(bx - hw, h / 2f - hh, bx + hw, h / 2f + hh)

        // corpo de vidro da bolha
        bp.style = Paint.Style.FILL
        bp.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, 0x66A78BFA, 0x3322D3EE, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, hh, hh, bp)
        bp.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, 0x4DFFFFFF, 0x0DFFFFFF, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, hh, hh, bp)

        // brilho que segue o dedo (reflexo da luz no vidro)
        clip.reset()
        clip.addRoundRect(rect, hh, hh, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        val gx = if (dragging) fingerX.coerceIn(rect.left, rect.right) else bx - hw * 0.35f
        val gy = if (dragging) h / 2f else rect.top + hh * 0.45f
        bp.shader = RadialGradient(gx, gy, hw * (0.9f + 0.5f * pressAmt), 0x66FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, hh, hh, bp)
        canvas.restore()

        // borda iluminada
        bp.style = Paint.Style.STROKE
        bp.strokeWidth = d * (1.2f + 0.5f * pressAmt)
        bp.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, 0xDDFFFFFF.toInt(), 0x33FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, hh, hh, bp)

        // ícones e rótulos; os que ficam sob a bolha são ampliados (efeito lente)
        for (i in tabs.indices) {
            val ix = centerX(i)
            val k = (1f - abs(ix - bx) / tw).coerceIn(0f, 1f)
            val alpha = (0xA0 + (0xFF - 0xA0) * k).toInt()
            val col = (alpha shl 24) or 0x00FFFFFF
            ip.color = col
            val zoom = 1f + 0.32f * pressAmt * k
            drawIcon(canvas, tabs[i].first, ix, h * 0.40f - d * (1.5f + 1.5f * pressAmt) * k, d * 0.92f * zoom, ip)
            tp.color = col
            canvas.drawText(tabs[i].second, ix, h - d * 13f, tp)
        }

        val moving = abs(target - bx) > 0.4f || abs(bv) > 4f || abs(pressAmt - (if (dragging) 1f else 0f)) > 0.01f
        if (moving) postInvalidateOnAnimation() else lastNs = 0L
    }

    private fun indexAt(x: Float): Int = ((x - pad) / tabW()).toInt().coerceIn(0, tabs.size - 1)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                fingerX = e.x
                hover = indexAt(e.x)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                fingerX = e.x
                val i = indexAt(e.x)
                if (i != hover) {
                    hover = i
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                val i = indexAt(e.x)
                if (i != selected) {
                    selected = i
                    onSelect(i)
                }
                target = centerX(selected)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                target = centerX(selected)
                invalidate()
            }
        }
        return true
    }
}
