package com.duelominas

import android.content.SharedPreferences
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, val userMessage: String) : Exception(userMessage)

/** Lê texto de um campo JSON tratando null como vazio (o org.json do Android devolve "null"). */
fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key, "")

/**
 * Conversa com o Supabase (login, perfil, fotos e ranking).
 * A chave abaixo é a "publishable": ela é pública por design e vai no app.
 * Quem protege os dados são as regras do banco (RLS), nunca a chave.
 * NUNCA coloque aqui a chave secret / service_role.
 */
object Api {
    const val URL = "https://zrvzrxbkviurspuotdzi.supabase.co"
    const val KEY = "sb_publishable_rZ2k0xRnjtXDZGhlS0K-Ng_HBqCgmnI"

    private val JSON = "application/json".toMediaType()
    private val http = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS).build()
    private var prefs: SharedPreferences? = null

    @Volatile var access: String? = null
    @Volatile private var refresh: String? = null
    @Volatile private var expiresAt = 0L
    @Volatile var userId: String? = null
    @Volatile var email: String? = null

    private class Raw(val code: Int, val body: String)

    fun init(p: SharedPreferences) {
        prefs = p
        access = Vault.open(p.getString("s_access", null))
        refresh = Vault.open(p.getString("s_refresh", null))
        p.edit().remove("access").remove("refresh").apply()   // apaga tokens antigos em texto puro
        expiresAt = p.getLong("exp", 0L)
        userId = p.getString("uid", null)
        email = p.getString("email", null)
    }

    /** Token válido para o servidor de jogo (renova se precisar). Chame fora da thread principal. */
    fun token(): String {
        ensureFresh()
        return access ?: throw ApiException(401, "Sessão expirada. Entre de novo.")
    }

    fun hasSession(): Boolean = refresh != null && userId != null

    private fun saveSession(o: JSONObject) {
        access = o.optString("access_token")
        refresh = o.optString("refresh_token")
        expiresAt = System.currentTimeMillis() + o.optLong("expires_in", 3600L) * 1000L
        val u = o.optJSONObject("user")
        if (u != null) {
            userId = u.optString("id")
            email = u.str("email")
        }
        prefs?.edit()
            ?.putString("s_access", access?.let { Vault.seal(it) })
            ?.putString("s_refresh", refresh?.let { Vault.seal(it) })
            ?.putLong("exp", expiresAt)?.putString("uid", userId)?.putString("email", email)
            ?.apply()
    }

    private fun clearSession() {
        access = null; refresh = null; expiresAt = 0L; userId = null; email = null
        prefs?.edit()?.remove("s_access")?.remove("s_refresh")?.remove("access")?.remove("refresh")?.remove("exp")?.remove("uid")?.remove("email")?.apply()
    }

    private fun exec(method: String, path: String, body: RequestBody?, bearer: String?, extra: Map<String, String> = emptyMap()): Raw {
        val b = Request.Builder().url(URL + path).header("apikey", KEY)
        if (bearer != null) b.header("Authorization", "Bearer $bearer")
        for ((k, v) in extra) b.header(k, v)
        b.method(method, body)
        http.newCall(b.build()).execute().use { r ->
            return Raw(r.code, r.body?.string() ?: "")
        }
    }

    private fun fail(r: Raw): ApiException {
        var msg = ""
        var code = ""
        try {
            val o = JSONObject(r.body)
            msg = o.str("msg").ifEmpty { o.str("message") }.ifEmpty { o.str("error_description") }.ifEmpty { o.str("error") }
            code = o.str("error_code").ifEmpty { o.str("code") }
        } catch (_: Exception) {
        }
        val low = (msg + " " + code).lowercase()
        val text = when {
            "invalid login" in low || "invalid_credentials" in low -> "E-mail ou senha incorretos."
            "already registered" in low || "user_already_exists" in low || "already been registered" in low -> "Esse e-mail já tem conta. Toque em Entrar."
            "same_password" in low || "different from the old" in low -> "A nova senha precisa ser diferente da atual."
            "weak_password" in low || "password should be" in low -> "Senha fraca. Use pelo menos 8 caracteres."
            "email_not_confirmed" in low || "not confirmed" in low -> "Confirme seu e-mail para entrar (veja sua caixa de entrada)."
            "rate limit" in low || "over_email_send_rate_limit" in low || "over_request_rate_limit" in low -> "Muitas tentativas. Espere um pouco e tente de novo."
            "email_address_invalid" in low || ("invalid" in low && "email" in low) -> "E-mail inválido."
            code == "P0001" && msg.isNotEmpty() -> msg
            r.code == 401 -> "Sessão expirada. Entre de novo."
            else -> "Algo deu errado (código ${r.code}${if (msg.isNotEmpty()) ": $msg" else ""}). Tente de novo."
        }
        return ApiException(r.code, text)
    }

    private fun refreshNow(): Boolean {
        synchronized(this) {
            val rt = refresh ?: return false
            val r = exec("POST", "/auth/v1/token?grant_type=refresh_token",
                JSONObject().put("refresh_token", rt).toString().toRequestBody(JSON), null)
            if (r.code in 200..299) {
                saveSession(JSONObject(r.body))
                return true
            }
            if (r.code in 400..499) clearSession()
            return false
        }
    }

    private fun ensureFresh() {
        if (access == null || System.currentTimeMillis() > expiresAt - 60_000L) {
            if (!refreshNow()) throw ApiException(401, "Sessão expirada. Entre de novo.")
        }
    }

    private fun call(
        method: String, path: String, json: String? = null,
        extra: Map<String, String> = emptyMap(), bytes: ByteArray? = null, mime: String = ""
    ): Raw {
        ensureFresh()
        fun go(): Raw {
            val body: RequestBody? = when {
                bytes != null -> bytes.toRequestBody(mime.toMediaType())
                json != null -> json.toRequestBody(JSON)
                method == "GET" || method == "DELETE" -> null
                else -> "".toRequestBody(JSON)
            }
            return exec(method, path, body, access, extra)
        }
        var r = go()
        if (r.code == 401 && refreshNow()) r = go()
        if (r.code !in 200..299) throw fail(r)
        return r
    }

    // ------------------------------------------------------------ login
    /** true = já entrou; false = precisa confirmar o e-mail antes. */
    fun signUp(email: String, pass: String): Boolean {
        val r = exec("POST", "/auth/v1/signup",
            JSONObject().put("email", email).put("password", pass).toString().toRequestBody(JSON), null)
        if (r.code !in 200..299) throw fail(r)
        val o = JSONObject(r.body)
        if (o.has("access_token")) {
            saveSession(o)
            return true
        }
        return false
    }

    fun signIn(email: String, pass: String) {
        val r = exec("POST", "/auth/v1/token?grant_type=password",
            JSONObject().put("email", email).put("password", pass).toString().toRequestBody(JSON), null)
        if (r.code !in 200..299) throw fail(r)
        saveSession(JSONObject(r.body))
    }

    fun signOut() {
        try {
            exec("POST", "/auth/v1/logout", "".toRequestBody(JSON), access)
        } catch (_: Exception) {
        }
        clearSession()
    }

    // ------------------------------------------------------------ perfil
    fun profile(): JSONObject {
        val r = call("GET", "/rest/v1/profiles?select=*&id=eq.$userId")
        val a = JSONArray(r.body)
        if (a.length() == 0) throw ApiException(404, "Perfil não encontrado. Tente sair e entrar de novo.")
        return a.getJSONObject(0)
    }

    fun updateProfile(fields: JSONObject) {
        call("PATCH", "/rest/v1/profiles?id=eq.$userId", fields.toString(), mapOf("Prefer" to "return=minimal"))
    }

    fun acceptTerms(version: String) {
        call("POST", "/rest/v1/rpc/accept_terms", JSONObject().put("p_version", version).toString())
    }

    fun ranking(): JSONArray =
        JSONArray(call("GET", "/rest/v1/ranking?select=*&order=position.asc,display_name.asc&limit=10").body)

    /** true se o @usuário está livre (formato válido, não reservado e de mais ninguém). */
    fun usernameAvailable(username: String): Boolean =
        call("POST", "/rest/v1/rpc/username_available", JSONObject().put("p_username", username).toString()).body.trim() == "true"

    /** IDs das contas verificadas (selo azul). */
    fun verifiedIds(): Set<String> {
        val a = JSONArray(call("POST", "/rest/v1/rpc/verified_ids", "{}").body)
        val out = HashSet<String>()
        for (i in 0 until a.length()) {
            val v = a.opt(i)
            out.add(if (v is JSONObject) v.str("verified_ids").ifEmpty { v.str("id") } else v.toString())
        }
        return out
    }

    /** Troca o @usuário (o banco valida formato e se já está em uso). */
    fun changeUsername(username: String) {
        call("POST", "/rest/v1/rpc/change_username", JSONObject().put("p_username", username).toString())
    }

    /** Confere a senha atual e troca pela nova. */
    fun changePassword(current: String, newPass: String) {
        val mail = email ?: throw ApiException(401, "Sessão expirada. Entre de novo.")
        try {
            signIn(mail, current)
        } catch (e: ApiException) {
            if (e.code == 400) throw ApiException(400, "A senha atual está incorreta.")
            throw e
        }
        call("PUT", "/auth/v1/user", JSONObject().put("password", newPass).toString())
    }

    // ------------------------------------------------------------ foto
    /** Envia a foto (JPG) ou o GIF animado. Só existe um arquivo de avatar por jogador. */
    fun uploadAvatar(bytes: ByteArray, gif: Boolean = false): String {
        val ext = if (gif) "gif" else "jpg"
        call("POST", "/storage/v1/object/avatars/$userId/avatar.$ext", bytes = bytes,
            mime = if (gif) "image/gif" else "image/jpeg", extra = mapOf("x-upsert" to "true"))
        try {
            call("DELETE", "/storage/v1/object/avatars/$userId/avatar.${if (gif) "jpg" else "gif"}")
        } catch (_: Exception) {
        }
        return "$URL/storage/v1/object/public/avatars/$userId/avatar.$ext?v=${System.currentTimeMillis()}"
    }

    fun deleteAvatar() {
        for (ext in listOf("jpg", "gif")) {
            try {
                call("DELETE", "/storage/v1/object/avatars/$userId/avatar.$ext")
            } catch (_: Exception) {
            }
        }
    }

    // ------------------------------------------------------------ conta
    fun deleteAccount() {
        call("POST", "/rest/v1/rpc/delete_my_account", "{}")
        clearSession()
    }
}
