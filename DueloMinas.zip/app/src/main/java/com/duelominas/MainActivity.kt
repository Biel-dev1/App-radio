package com.duelominas

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Calendar
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.min

const val TERMS_VERSION = "1.0"

const val TERMS_TEXT = "Versão 1.0\n\n" +
    "1. Quem pode usar\n" +
    "O Duelo de Minas é só para maiores de 18 anos. Ao criar sua conta você declara ter 18 anos ou mais e que as informações que fornecer são verdadeiras. Podemos pedir comprovação de idade e de identidade a qualquer momento.\n\n" +
    "2. O que é o app\n" +
    "Uma plataforma onde jogadores disputam partidas entre si (x1) de campo minado. O app oferece o ambiente da partida; a disputa é entre os próprios usuários.\n\n" +
    "3. Risco de perda\n" +
    "As partidas podem envolver valores em dinheiro e você pode perder o valor apostado. Não existe garantia de ganho, e o resultado depende, em parte, de sorte. Jogue apenas com dinheiro que você pode perder.\n\n" +
    "4. Responsabilidade\n" +
    "O app não se responsabiliza pelo resultado dos confrontos x1 entre jogadores nem pelas perdas decorrentes das escolhas de cada um. Isso não exclui as responsabilidades que a lei não permite excluir, como falhas técnicas comprovadas ou cobranças indevidas.\n\n" +
    "5. Conduta\n" +
    "É proibido trapacear, usar programas automáticos, manter várias contas ou ofender outros jogadores. Contas podem ser suspensas, e valores podem ser retidos em caso de fraude, conforme a lei.\n\n" +
    "6. Pagamentos e saques\n" +
    "A taxa do app é informada antes de cada partida. Saques dependem de verificação de identidade e de aprovação, e podem levar um tempo para serem processados.\n\n" +
    "7. Jogo responsável\n" +
    "Se sentir que está perdendo o controle, pare de jogar e procure ajuda. O CVV (telefone 188) atende 24 horas, de graça.\n\n" +
    "8. Seus dados\n" +
    "Guardamos e-mail, nome de exibição, foto, bio e dados de partidas e saldo para o app funcionar. Podemos pedir CPF e documento para verificação. Você pode apagar sua conta no app, respeitando a guarda de registros financeiros exigida por lei.\n\n" +
    "9. Mudanças\n" +
    "Podemos atualizar estes termos. Quando isso acontecer, vamos pedir um novo aceite."

class MainActivity : Activity() {
    private companion object {
        const val REQ_PHOTO = 41
        const val NAV_HEIGHT_DP = 68
    }

    internal lateinit var prefs: SharedPreferences
    private lateinit var host: FrameLayout
    private lateinit var nav: GlassNavBar

    internal var me: JSONObject? = null
    internal var scroll: ScrollView? = null
    private var navVisible = false
    private var insetTop = 0
    private var insetBottom = 0
    private var imeHeight = 0

    private var photoPurpose = 0              // 0 = configuração inicial, 1 = trocar foto no perfil
    private var pendingPhoto: ByteArray? = null
    private var setupAvatar: AvatarView? = null
    private var profileAvatar: AvatarView? = null

    // ------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("duelo", MODE_PRIVATE)
        Api.init(prefs)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        if (Build.VERSION.SDK_INT >= 29) window.setNavigationBarContrastEnforced(false)

        val root = FrameLayout(this)
        root.addView(AuroraBackground(this), FrameLayout.LayoutParams(MATCH, MATCH))
        host = FrameLayout(this)
        root.addView(host, FrameLayout.LayoutParams(MATCH, MATCH))

        nav = GlassNavBar(
            this,
            listOf(
                ICON_HOME to "Lobby",
                ICON_GRID to "Salas",
                ICON_TROPHY to "Ranking",
                ICON_PROFILE to "Perfil"
            )
        ) { i -> showTab(i) }
        val navLp = FrameLayout.LayoutParams(MATCH, dpi(NAV_HEIGHT_DP))
        navLp.gravity = Gravity.BOTTOM
        navLp.leftMargin = dpi(14)
        navLp.rightMargin = dpi(14)
        navLp.bottomMargin = dpi(14)
        nav.visibility = View.GONE
        root.addView(nav, navLp)
        setContentView(root)

        root.setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = ins.getInsets(WindowInsets.Type.systemBars())
                val ime = ins.getInsets(WindowInsets.Type.ime())
                insetTop = bars.top
                insetBottom = bars.bottom
                imeHeight = ime.bottom
            } else {
                @Suppress("DEPRECATION")
                val b = ins.systemWindowInsetBottom
                @Suppress("DEPRECATION")
                insetTop = ins.systemWindowInsetTop
                if (b > dpi(180)) { imeHeight = b; insetBottom = 0 } else { imeHeight = 0; insetBottom = b }
            }
            applyInsets()
            ins
        }

        showSplash(null)
        startSession()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (GameUi.inRoomScreen) {
            GameUi.confirmLeave(this)
        } else if (GameUi.wizardOpen) {
            showTab(0)
        } else if (navVisible && nav.selected != 0) {
            nav.select(0, true)
            showTab(0)
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private fun applyInsets() {
        val keyboard = imeHeight > 0
        val navBottom = dpi(14) + insetBottom
        val lp = nav.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = navBottom
        nav.layoutParams = lp
        nav.visibility = if (navVisible && !keyboard) View.VISIBLE else View.GONE
        val bottom = when {
            keyboard -> imeHeight + dpi(16)
            navVisible -> navBottom + dpi(NAV_HEIGHT_DP) + dpi(24)
            else -> insetBottom + dpi(24)
        }
        scroll?.setPadding(dpi(20), insetTop + dpi(14), dpi(20), bottom)
    }

    // ------------------------------------------------------------ trabalho em segundo plano

    internal fun <T> bg(onFail: (Exception) -> Unit = {}, work: () -> T, ok: (T) -> Unit) {
        thread {
            try {
                val r = work()
                runOnUiThread { ok(r) }
            } catch (e: ApiException) {
                runOnUiThread { toast(e.userMessage); onFail(e) }
            } catch (e: Exception) {
                runOnUiThread { toast("Sem conexão. Tente de novo."); onFail(e) }
            }
        }
    }

    internal fun busy(b: TextView, on: Boolean) {
        if (on) {
            b.tag = b.text
            b.text = "Aguarde…"
            b.isEnabled = false
            b.alpha = 0.6f
        } else {
            val old = b.tag as? CharSequence
            if (old != null) b.text = old
            b.isEnabled = true
            b.alpha = 1f
        }
    }

    // ------------------------------------------------------------ rotas

    private fun startSession() {
        if (!Api.hasSession()) {
            showAuth()
            return
        }
        bg(onFail = { e ->
            if (e is ApiException && e.code == 401) showAuth() else showSplash("Sem conexão. Toque aqui para tentar de novo.")
        }, work = { Api.profile() }) { p ->
            me = p
            route()
        }
    }

    private fun route() {
        val p = me
        if (p == null) {
            showAuth()
        } else if (p.str("terms_version") != TERMS_VERSION) {
            showTerms()
        } else if (!p.optBoolean("profile_done")) {
            showSetup()
        } else {
            showMain()
        }
    }

    private fun logout() {
        GameUi.detach()
        bg(work = { Api.signOut() }) {
            me = null
            showAuth()
        }
    }

    internal fun setScreen(view: ScrollView, withNav: Boolean, animate: Boolean = true) {
        scroll = view
        navVisible = withNav
        host.removeAllViews()
        if (animate) {
            view.alpha = 0f
            view.translationY = dp(16f)
        }
        host.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
        if (animate) view.animate().alpha(1f).translationY(0f).setDuration(260).start()
        applyInsets()
    }

    // ------------------------------------------------------------ abertura

    private fun showSplash(message: String?) {
        val v = scaffold("", "") {
            val logo = TextView(this@MainActivity)
            logo.text = "💣"
            logo.textSize = 64f
            logo.gravity = Gravity.CENTER
            put(logo, 120)
            val t = txt("Duelo de Minas", 28f, cWhite, true)
            t.gravity = Gravity.CENTER
            put(t, 12)
            if (message != null) {
                val m = txt(message, 14f, cDim)
                m.gravity = Gravity.CENTER
                m.setOnClickListener { showSplash(null); startSession() }
                put(m, 16)
            }
        }
        setScreen(v, false)
    }

    // ------------------------------------------------------------ login e criar conta

    private fun showAuth() {
        GameUi.detach()
        var signup = false
        val v = scaffold("", "") {
            val logo = TextView(this@MainActivity)
            logo.text = "💣"
            logo.textSize = 56f
            logo.gravity = Gravity.CENTER
            put(logo, 30)
            val title = txt("Duelo de Minas", 30f, cWhite, true)
            title.gravity = Gravity.CENTER
            put(title, 6)
            val sub = txt("Entre ou crie sua conta para jogar.", 14f, cDim)
            sub.gravity = Gravity.CENTER
            put(sub, 4)

            val tabs = LinearLayout(this@MainActivity)
            tabs.orientation = LinearLayout.HORIZONTAL
            val tLogin = tabPill("Entrar")
            val tSign = tabPill("Criar conta")
            tabs.addView(tLogin, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dpi(6) })
            tabs.addView(tSign, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dpi(6) })
            put(tabs, 26)

            val email = input("E-mail", "")
            email.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            put(email, 14)
            val pass = input("Senha (mínimo 8 caracteres)", "")
            pass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            put(pass, 10)
            val pass2 = input("Repita a senha", "")
            pass2.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            pass2.visibility = View.GONE
            put(pass2, 10)

            lateinit var submit: TextView
            fun refresh() {
                pass2.visibility = if (signup) View.VISIBLE else View.GONE
                styleTab(tLogin, !signup)
                styleTab(tSign, signup)
                submit.text = if (signup) "Criar conta" else "Entrar"
            }
            submit = button("Entrar") {
                val e = email.text.toString().trim()
                val p1 = pass.text.toString()
                if (!e.contains("@") || !e.contains(".")) {
                    toast("Digite um e-mail válido.")
                } else if (p1.length < 8) {
                    toast("A senha precisa ter pelo menos 8 caracteres.")
                } else if (signup && p1 != pass2.text.toString()) {
                    toast("As senhas não são iguais.")
                } else {
                    busy(submit, true)
                    if (signup) {
                        bg(onFail = { busy(submit, false) }, work = { Api.signUp(e, p1) }) { entered ->
                            busy(submit, false)
                            if (entered) {
                                startSession()
                            } else {
                                toast("Conta criada! Confirme seu e-mail e depois toque em Entrar.")
                                signup = false
                                refresh()
                            }
                        }
                    } else {
                        bg(onFail = { busy(submit, false) }, work = { Api.signIn(e, p1) }) {
                            startSession()
                        }
                    }
                }
            }
            put(submit, 18)
            tLogin.setOnClickListener { signup = false; refresh() }
            tSign.setOnClickListener { signup = true; refresh() }
            refresh()

            val notice = SpannableString("Ao continuar, você concorda com os Termos de Uso e confirma ter 18 anos ou mais.")
            val start = notice.indexOf("Termos de Uso")
            notice.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) { showTermsDialog() }
                override fun updateDrawState(ds: TextPaint) {
                    ds.color = 0xFF67E8F9.toInt()
                    ds.isUnderlineText = true
                }
            }, start, start + "Termos de Uso".length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            val nt = txt("", 12.5f, cFaint)
            nt.text = notice
            nt.movementMethod = LinkMovementMethod.getInstance()
            nt.highlightColor = Color.TRANSPARENT
            nt.gravity = Gravity.CENTER
            put(nt, 16)
        }
        setScreen(v, false)
    }

    private fun tabPill(label: String): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setTextColor(cWhite)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setPadding(dpi(12), dpi(12), dpi(12), dpi(12))
        t.isClickable = true
        t.pressable()
        return t
    }

    private fun styleTab(t: TextView, selected: Boolean) {
        if (selected) {
            val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7C4DFF.toInt(), 0xFF06B6D4.toInt()))
            g.cornerRadius = dp(16f)
            t.background = g
        } else {
            t.background = glass(16f)
        }
    }

    private fun showTermsDialog() {
        val body = TextView(this)
        body.text = TERMS_TEXT
        body.textSize = 14f
        body.setTextColor(cWhite)
        body.setPadding(dpi(20), dpi(12), dpi(20), dpi(12))
        val sv = ScrollView(this)
        sv.addView(body)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Termos de Uso")
            .setView(sv)
            .setPositiveButton("Fechar", null)
            .show()
    }

    // ------------------------------------------------------------ termos (depois de criar a conta)

    private fun showTerms() {
        val v = scaffold("Termos de Uso", "Leia com atenção antes de continuar.") {
            put(card { put(txt(TERMS_TEXT, 13.5f, cDim), 0) }, 0)
            val c18 = CheckBox(this@MainActivity)
            c18.text = "Tenho 18 anos ou mais."
            c18.setTextColor(cWhite)
            val cOk = CheckBox(this@MainActivity)
            cOk.text = "Li e aceito os Termos de Uso. Sei que posso perder dinheiro e que o app não se responsabiliza pelo resultado das partidas entre jogadores."
            cOk.setTextColor(cWhite)
            put(c18, 16)
            put(cOk, 4)
            lateinit var go: TextView
            go = button("Aceitar e continuar") {
                if (!c18.isChecked || !cOk.isChecked) {
                    toast("Marque as duas opções para continuar.")
                } else {
                    busy(go, true)
                    bg(onFail = { busy(go, false) }, work = { Api.acceptTerms(TERMS_VERSION); Api.profile() }) { p ->
                        me = p
                        route()
                    }
                }
            }
            put(go, 16)
            put(button("Sair da conta", false) { logout() }, 10)
        }
        setScreen(v, false)
    }

    // ------------------------------------------------------------ configuração de perfil (obrigatória)

    private fun showSetup() {
        pendingPhoto = null
        val v = scaffold("Seu perfil", "Antes de jogar, conte quem você é.") {
            val av = AvatarView(this@MainActivity)
            av.setPerson("?", null)
            av.setOnClickListener { pickPhoto(0) }
            setupAvatar = av
            put(av, 4, dpi(120), dpi(120))
            val hint = txt("Toque para escolher sua foto", 13f, cDim)
            hint.gravity = Gravity.CENTER
            put(hint, 8)

            put(card {
                put(label("NOME DE EXIBIÇÃO"), 0)
                val nameIn = input("Como você quer ser chamado", "")
                nameIn.filters = arrayOf(InputFilter.LengthFilter(20))
                put(nameIn, 8)
                put(label("PAÍS"), 16)
                val country = txt("🇧🇷  Brasil", 16f, cWhite)
                country.background = glass(16f, 0.7f)
                country.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
                put(country, 8)
                put(label("BIO"), 16)
                val bioIn = input("Fale um pouco sobre você", "")
                bioIn.setSingleLine(false)
                bioIn.minLines = 3
                bioIn.gravity = Gravity.TOP or Gravity.START
                bioIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                bioIn.filters = arrayOf(InputFilter.LengthFilter(200))
                put(bioIn, 8)

                lateinit var done: TextView
                done = button("Concluir") {
                    val photo = pendingPhoto
                    val n = nameIn.text.toString().trim()
                    if (photo == null) {
                        toast("Escolha uma foto de perfil.")
                    } else if (n.length < 3) {
                        toast("O nome precisa ter pelo menos 3 letras.")
                    } else {
                        busy(done, true)
                        val bio = bioIn.text.toString().trim()
                        bg(onFail = { busy(done, false) }, work = {
                            val url = Api.uploadAvatar(photo)
                            val f = JSONObject()
                            f.put("display_name", n)
                            f.put("bio", bio)
                            f.put("country", "BR")
                            f.put("avatar_url", url)
                            f.put("profile_done", true)
                            Api.updateProfile(f)
                            Api.profile()
                        }) { p ->
                            me = p
                            route()
                        }
                    }
                }
                put(done, 20)
            }, 18)
        }
        setScreen(v, false)
    }

    // ------------------------------------------------------------ foto

    private fun pickPhoto(purpose: Int) {
        photoPurpose = purpose
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "Escolher foto"), REQ_PHOTO)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != REQ_PHOTO || resultCode != RESULT_OK || uri == null) return
        val purpose = photoPurpose
        bg(work = { decodePhoto(uri) }) { pair ->
            val bytes = pair.first
            val bmp = pair.second
            if (purpose == 0) {
                pendingPhoto = bytes
                setupAvatar?.setBitmapDirect(bmp)
            } else {
                profileAvatar?.setBitmapDirect(bmp)
                bg(work = {
                    val url = Api.uploadAvatar(bytes)
                    Api.updateProfile(JSONObject().put("avatar_url", url))
                    Api.profile()
                }) { p ->
                    me = p
                    toast("Foto atualizada!")
                }
            }
        }
    }

    private fun decodePhoto(uri: Uri): Pair<ByteArray, Bitmap> {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (bounds.outWidth / (s * 2) >= 1024 && bounds.outHeight / (s * 2) >= 1024) s *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = s
        var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw ApiException(0, "Não consegui abrir essa foto.")
        val orientation = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            } ?: 1
        } catch (e: Exception) {
            1
        }
        val deg = when (orientation) {
            6 -> 90f
            3 -> 180f
            8 -> 270f
            else -> 0f
        }
        if (deg != 0f) {
            val m = Matrix()
            m.postRotate(deg)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val side = min(bmp.width, bmp.height)
        val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val out = Bitmap.createScaledBitmap(square, 512, 512, true)
        val baos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 85, baos)
        return Pair(baos.toByteArray(), out)
    }

    // ------------------------------------------------------------ app principal

    internal fun showMain() {
        GameUi.attach(this)
        nav.select(0, false)
        showTab(0)
    }

    internal fun showTab(i: Int) {
        GameUi.stopTicker()
        GameUi.inRoomScreen = false
        setupAvatar = null
        profileAvatar = null
        val v = when (i) {
            0 -> buildLobby()
            1 -> buildRooms()
            2 -> buildRanking()
            else -> buildProfile()
        }
        setScreen(v, true)
    }

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            h < 12 -> "Bom dia"
            h < 18 -> "Boa tarde"
            else -> "Boa noite"
        }
    }

    internal fun money(cents: Long): String =
        String.format(Locale.forLanguageTag("pt-BR"), "R$ %.2f", cents / 100.0)

    private fun flag(cc: String): String {
        if (cc.length != 2) return ""
        return cc.uppercase().map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")
    }

    private fun buildLobby(): ScrollView = scaffold("", "") {
        val p = me ?: JSONObject()
        val av = AvatarView(this@MainActivity)
        av.setPerson(p.str("display_name"), p.str("avatar_url"))
        put(av, 22, dpi(130), dpi(130))
        val hi = txt(greeting() + ",", 16f, cDim)
        hi.gravity = Gravity.CENTER
        put(hi, 14)
        val name = txt(p.str("display_name").ifEmpty { "Jogador" }, 30f, cWhite, true)
        name.gravity = Gravity.CENTER
        put(name, 2)
        val bal = txt("Saldo de teste: " + money(p.optLong("balance_cents", 0L)), 13f, cWhite)
        bal.background = glass(18f)
        bal.setPadding(dpi(16), dpi(8), dpi(16), dpi(8))
        put(bal, 12, WRAP)
        put(button("Criar sala") { showCreateRoom() }, 30)
        put(button("Entrar em sala por código", false) { askJoinCode() }, 12)
        val note = txt(if (Game.connected) "Conectado ao servidor de jogo ✅" else "Conectando ao servidor de jogo…", 12f, cFaint)
        note.gravity = Gravity.CENTER
        put(note, 16)
    }

    private fun buildRooms(): ScrollView = buildRoomList()

    private fun buildRanking(): ScrollView {
        var box: LinearLayout? = null
        val v = scaffold("Ranking", "Os melhores do Duelo de Minas.") {
            val b = LinearLayout(this@MainActivity)
            b.orientation = LinearLayout.VERTICAL
            box = b
            put(b, 0)
            b.addView(txt("Carregando…", 14f, cDim))
        }
        bg(onFail = {
            box?.removeAllViews()
            box?.addView(txt("Não foi possível carregar o ranking.", 14f, cDim))
        }, work = { Api.ranking() }) { arr ->
            renderRanking(box, arr)
        }
        return v
    }

    private fun renderRanking(box: LinearLayout?, arr: JSONArray) {
        if (box == null) return
        box.removeAllViews()
        if (arr.length() == 0) {
            box.addView(txt("Ninguém no ranking ainda. Seja o primeiro!", 14f, cDim))
            return
        }
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val pos = o.optInt("position", i + 1)
            val mine = o.str("id") == Api.userId
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dpi(14), dpi(10), dpi(14), dpi(10))
            if (mine) {
                val g = GradientDrawable()
                g.cornerRadius = dp(20f)
                g.setColor(0x337C4DFF)
                g.setStroke(dpi(2), 0xFF22D3EE.toInt())
                row.background = g
            } else {
                row.background = glass(20f)
            }
            val medal = when (pos) {
                1 -> "🥇"
                2 -> "🥈"
                3 -> "🥉"
                else -> "$pos"
            }
            val posTv = txt(medal, if (pos <= 3) 22f else 16f, cWhite, true)
            posTv.gravity = Gravity.CENTER
            row.addView(posTv, LinearLayout.LayoutParams(dpi(40), WRAP))
            val av = AvatarView(this)
            av.setPerson(o.str("display_name"), o.str("avatar_url"))
            row.addView(av, LinearLayout.LayoutParams(dpi(46), dpi(46)))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(txt(o.str("display_name").ifEmpty { "Jogador" }, 16f, cWhite, true))
            col.addView(txt(flag(o.str("country")) + " " + (if (o.str("country") == "BR") "Brasil" else o.str("country")), 12f, cDim))
            val colLp = LinearLayout.LayoutParams(0, WRAP, 1f)
            colLp.leftMargin = dpi(12)
            row.addView(col, colLp)
            val wins = o.optInt("wins", 0)
            row.addView(txt("$wins " + (if (wins == 1) "win" else "wins"), 15f, cWhite, true))
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dpi(if (i == 0) 0 else 8)
            box.addView(row, lp)
        }
    }

    private fun buildProfile(): ScrollView = scaffold("", "") {
        val p = me ?: JSONObject()
        val av = AvatarView(this@MainActivity)
        av.setPerson(p.str("display_name"), p.str("avatar_url"))
        av.setOnClickListener { pickPhoto(1) }
        profileAvatar = av
        put(av, 10, dpi(120), dpi(120))
        val title = txt(p.str("display_name").ifEmpty { "Jogador" }, 26f, cWhite, true)
        title.gravity = Gravity.CENTER
        put(title, 12)
        val bal = txt("Saldo: " + money(p.optLong("balance_cents", 0L)), 15f, cWhite, true)
        bal.background = glass(18f)
        bal.setPadding(dpi(18), dpi(8), dpi(18), dpi(8))
        put(bal, 10, WRAP)
        val bal2 = txt("Saldo de teste: ainda não vale dinheiro.", 11.5f, cFaint)
        bal2.gravity = Gravity.CENTER
        put(bal2, 6)

        profileExtras(this)

        put(card {
            put(label("NOME DE EXIBIÇÃO"), 0)
            val nameIn = input("Seu nome", p.str("display_name"))
            nameIn.filters = arrayOf(InputFilter.LengthFilter(20))
            put(nameIn, 8)
            put(label("USUÁRIO"), 16)
            val user = txt("@" + p.str("username"), 16f, cDim)
            user.background = glass(16f, 0.5f)
            user.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
            put(user, 8)
            put(label("BIO"), 16)
            val bioIn = input("Fale um pouco sobre você", p.str("bio"))
            bioIn.setSingleLine(false)
            bioIn.minLines = 3
            bioIn.gravity = Gravity.TOP or Gravity.START
            bioIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            bioIn.filters = arrayOf(InputFilter.LengthFilter(200))
            put(bioIn, 8)
            lateinit var save: TextView
            save = button("Salvar alterações") {
                val n = nameIn.text.toString().trim()
                if (n.length < 3) {
                    toast("O nome precisa ter pelo menos 3 letras.")
                } else {
                    busy(save, true)
                    bg(onFail = { busy(save, false) }, work = {
                        val f = JSONObject()
                        f.put("display_name", n)
                        f.put("bio", bioIn.text.toString().trim())
                        Api.updateProfile(f)
                        Api.profile()
                    }) { np ->
                        me = np
                        busy(save, false)
                        toast("Perfil salvo!")
                        title.text = np.str("display_name")
                    }
                }
            }
            put(save, 18)
        }, 18)

        put(button("Alterar foto", false) { pickPhoto(1) }, 14)
        val withdraw = button("Sacar (em breve)", false) { toast("O saque será liberado em breve.") }
        withdraw.alpha = 0.6f
        put(withdraw, 10)
        put(button("Sair da conta", false) { logout() }, 10)
        val del = button("Apagar conta", false) { confirmDelete() }
        del.setTextColor(0xFFF87171.toInt())
        put(del, 10)
        val foot = txt("Sua senha não pode ser alterada por enquanto.", 12f, cFaint)
        foot.gravity = Gravity.CENTER
        put(foot, 14)
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Apagar conta?")
            .setMessage("Isso apaga seu perfil e sua foto e não dá para desfazer. Contas com saldo ou movimentações financeiras não podem ser apagadas por aqui.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Apagar") { _, _ ->
                bg(work = { Api.deleteAvatar(); Api.deleteAccount() }) {
                    me = null
                    toast("Conta apagada.")
                    showAuth()
                }
            }
            .show()
    }

    // ------------------------------------------------------------ componentes visuais

    internal fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    internal fun glass(radiusDp: Float, strength: Float = 1f) = GlassDrawable(dp(radiusDp), dp(1f), strength)

    internal fun txt(s: String, sp: Float, color: Int = cWhite, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        t.typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        return t
    }

    internal fun label(s: String): TextView {
        val t = txt(s, 11f, cDim, true)
        t.letterSpacing = 0.14f
        return t
    }

    internal fun LinearLayout.put(v: View, topDp: Int = 12, w: Int = MATCH, h: Int = WRAP): View {
        val lp = LinearLayout.LayoutParams(w, h)
        lp.topMargin = dpi(topDp)
        if (w != MATCH) lp.gravity = Gravity.CENTER_HORIZONTAL
        addView(v, lp)
        return v
    }

    internal fun scaffold(title: String, subtitle: String, build: LinearLayout.() -> Unit): ScrollView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        if (title.isNotEmpty()) {
            col.addView(txt(title, 32f, cWhite, true))
            val sub = txt(subtitle, 14f, cDim)
            sub.setPadding(0, dpi(4), 0, dpi(18))
            col.addView(sub)
        }
        col.build()
        val sv = ScrollView(this)
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        sv.isVerticalScrollBarEnabled = false
        sv.clipToPadding = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        return sv
    }

    internal fun card(build: LinearLayout.() -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dpi(18), dpi(18), dpi(18), dpi(18))
        c.background = glass(24f)
        c.build()
        return c
    }

    internal fun button(label: String, primary: Boolean = true, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.textSize = 16f
        b.setTextColor(cWhite)
        b.gravity = Gravity.CENTER
        b.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        b.setPadding(dpi(16), dpi(16), dpi(16), dpi(16))
        if (primary) {
            val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7C4DFF.toInt(), 0xFF06B6D4.toInt()))
            g.cornerRadius = dp(18f)
            b.background = g
        } else {
            b.background = glass(18f)
        }
        b.isClickable = true
        b.setOnClickListener { onClick() }
        b.pressable()
        return b
    }

    internal fun input(placeholder: String, value: String): EditText {
        val e = EditText(this)
        e.setText(value)
        e.hint = placeholder
        e.setTextColor(cWhite)
        e.setHintTextColor(cFaint)
        e.textSize = 16f
        e.setSingleLine(true)
        e.background = glass(16f, 0.7f)
        e.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
        return e
    }
}
