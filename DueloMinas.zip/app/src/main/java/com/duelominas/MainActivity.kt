package com.duelominas

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Calendar
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.min

/** Foto escolhida: JPG já recortado (bmp) ou GIF original (bytes). */
internal class Picked(val bytes: ByteArray, val bmp: Bitmap?, val gif: Boolean)

const val TERMS_VERSION = "1.0"

const val TERMS_TEXT = "Versão 1.0\n\n" +
    "1. Quem pode usar\n" +
    "O Duelo de Minas é só para maiores de 18 anos. Ao criar sua conta você declara ter 18 anos ou mais e que as informações que fornecer são verdadeiras. Podemos pedir comprovação de idade e de identidade a qualquer momento.\n\n" +
    "2. O que é o app\n" +
    "Uma plataforma onde jogadores disputam partidas entre si (x1) de campo minado. O app oferece o ambiente da partida; a disputa é entre os próprios usuários.\n\n" +
    "3. Risco de perda\n" +
    "As partidas podem envolver valores em dinheiro e você pode perder o valor apostado. Não existe garantia de ganho, e o resultado depende, em parte, de sorte. Jogue apenas com dinheiro que você pode perder.\n\n" +
    "4. Responsabilidade\n" +
    "O app não se responsabiliza pelo resultado dos confrontos x1 entre jogadores nem pelas perdas decorrentes das escolhas de cada um. Isso não exclui as responsabilidades que a lei não permite excluir, como falhas técnicas comprovadas ou cobranças indevidas.\n\n" +
    "5. Conduta\n" +
    "É proibido trapacear, usar programas automáticos, manter várias contas ou ofender outros jogadores. Contas podem ser suspensas, e valores podem ser retidos em caso de fraude, conforme a lei.\n\n" +
    "6. Pagamentos e saques\n" +
    "A taxa do app é informada antes de cada partida. Saques dependem de verificação de identidade e de aprovação, e podem levar um tempo para serem processados.\n\n" +
    "7. Jogo responsável\n" +
    "Se sentir que está perdendo o controle, pare de jogar e procure ajuda. O CVV (telefone 188) atende 24 horas, de graça.\n\n" +
    "8. Seus dados\n" +
    "Guardamos e-mail, nome de exibição, foto, bio e dados de partidas e saldo para o app funcionar. Podemos pedir CPF e documento para verificação. Você pode apagar sua conta no app, respeitando a guarda de registros financeiros exigida por lei.\n\n" +
    "9. Mudanças\n" +
    "Podemos atualizar estes termos. Quando isso acontecer, vamos pedir um novo aceite."

class MainActivity : Activity() {
    private companion object {
        const val REQ_PHOTO = 41
        const val NAV_HEIGHT_DP = 62
        const val NAV_WIDTH_DP = 276
        /** true = bloqueia print/gravação de tela e esconde o app na lista de recentes (proteção do saldo). */
        const val SECURE_SCREEN = true
    }

    internal lateinit var prefs: SharedPreferences
    private lateinit var host: FrameLayout
    private lateinit var nav: GlassNavBar

    internal var me: JSONObject? = null
    internal var scroll: ScrollView? = null
    private var navVisible = false
    private var insetTop = 0
    private var insetBottom = 0
    private var imeHeight = 0

    private var photoPurpose = 0              // 0 = configuração inicial, 1 = trocar foto no perfil
    private var pendingPhoto: ByteArray? = null
    private var pendingGif = false
    private var setupAvatar: AvatarView? = null
    internal var profileAvatar: AvatarView? = null

    // ------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("duelo", MODE_PRIVATE)
        prefs.edit().remove("game_server").apply()   // servidor agora é fixo no app
        Api.init(prefs)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        if (Build.VERSION.SDK_INT >= 29) window.setNavigationBarContrastEnforced(false)

        val root = FrameLayout(this)
        root.addView(AuroraBackground(this), FrameLayout.LayoutParams(MATCH, MATCH))
        host = FrameLayout(this)
        root.addView(host, FrameLayout.LayoutParams(MATCH, MATCH))

        nav = GlassNavBar(
            this,
            listOf(
                ICON_HOME to "Lobby",
                ICON_GRID to "Amigos",
                ICON_TROPHY to "Ranking",
                ICON_PROFILE to "Perfil"
            )
        ) { i -> showTab(i) }
        val navW = min(dpi(NAV_WIDTH_DP), resources.displayMetrics.widthPixels - dpi(28))
        val navLp = FrameLayout.LayoutParams(navW, dpi(NAV_HEIGHT_DP))
        navLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        navLp.bottomMargin = dpi(14)
        nav.visibility = View.GONE
        root.addView(nav, navLp)
        setContentView(root)

        root.setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = ins.getInsets(WindowInsets.Type.systemBars())
                val ime = ins.getInsets(WindowInsets.Type.ime())
                insetTop = bars.top
                insetBottom = bars.bottom
                imeHeight = ime.bottom
            } else {
                @Suppress("DEPRECATION")
                val b = ins.systemWindowInsetBottom
                @Suppress("DEPRECATION")
                insetTop = ins.systemWindowInsetTop
                if (b > dpi(180)) { imeHeight = b; insetBottom = 0 } else { imeHeight = 0; insetBottom = b }
            }
            applyInsets()
            ins
        }

        showSplash(null)
        startSession()
        AppUpdate.checkOnLaunch(this)   // ao abrir, confere sozinho se há versão nova
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (GameUi.inRoomScreen) {
            GameUi.confirmLeave(this)
        } else if (GameUi.wizardOpen) {
            showTab(0)
        } else if (navVisible && nav.selected != 0) {
            nav.select(0, true)
            showTab(0)
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private fun applyInsets() {
        val keyboard = imeHeight > 0
        val navBottom = dpi(14) + insetBottom
        val lp = nav.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = navBottom
        nav.layoutParams = lp
        nav.visibility = if (navVisible && !keyboard) View.VISIBLE else View.GONE
        val bottom = when {
            keyboard -> imeHeight + dpi(16)
            navVisible -> navBottom + dpi(NAV_HEIGHT_DP) + dpi(24)
            else -> insetBottom + dpi(24)
        }
        scroll?.setPadding(dpi(20), insetTop + dpi(14), dpi(20), bottom)
    }

    // ------------------------------------------------------------ trabalho em segundo plano

    internal fun <T> bg(onFail: (Exception) -> Unit = {}, work: () -> T, ok: (T) -> Unit) {
        thread {
            try {
                val r = work()
                runOnUiThread { ok(r) }
            } catch (e: ApiException) {
                runOnUiThread { toast(e.userMessage); onFail(e) }
            } catch (e: Exception) {
                runOnUiThread { toast("Sem conexão. Tente de novo."); onFail(e) }
            }
        }
    }

    internal fun busy(b: TextView, on: Boolean) {
        if (on) {
            b.tag = b.text
            b.text = "Aguarde…"
            b.isEnabled = false
            b.alpha = 0.6f
        } else {
            val old = b.tag as? CharSequence
            if (old != null) b.text = old
            b.isEnabled = true
            b.alpha = 1f
        }
    }

    // ------------------------------------------------------------ rotas

    private fun startSession() {
        if (!Api.hasSession()) {
            showAuth()
            return
        }
        bg(onFail = { e ->
            if (e is ApiException && e.code == 401) showAuth() else showSplash("Sem conexão. Toque aqui para tentar de novo.")
        }, work = { Api.profile() }) { p ->
            me = p
            route()
        }
    }

    private fun route() {
        val p = me
        if (p == null) {
            showAuth()
        } else if (p.str("terms_version") != TERMS_VERSION) {
            showTerms()
        } else if (!p.optBoolean("profile_done")) {
            showSetup()
        } else {
            showMain()
        }
    }

    internal fun logout() {
        GameUi.detach()
        bg(work = { Api.signOut() }) {
            me = null
            showAuth()
        }
    }

    /** true se a tela/diálogo tem campo de senha (login, senha de 6 dígitos, confirmar exclusão...). */
    internal fun hasPasswordField(v: View?): Boolean {
        if (v is EditText) {
            val cls = v.inputType and InputType.TYPE_MASK_CLASS
            val va = v.inputType and InputType.TYPE_MASK_VARIATION
            return (cls == InputType.TYPE_CLASS_TEXT && (va == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                va == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || va == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
                (cls == InputType.TYPE_CLASS_NUMBER && va == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        }
        if (v is android.view.ViewGroup) {
            for (i in 0 until v.childCount) if (hasPasswordField(v.getChildAt(i))) return true
        }
        return false
    }

    /** Bloqueia print/gravação só quando há senha na tela. */
    internal fun setSecure(w: android.view.Window?, on: Boolean) {
        if (w == null || !SECURE_SCREEN) return
        if (on) w.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        else w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
    }

    internal fun setScreen(view: ScrollView, withNav: Boolean, animate: Boolean = true) {
        setSecure(window, hasPasswordField(view))
        scroll = view
        navVisible = withNav
        host.removeAllViews()
        if (animate) {
            view.alpha = 0f
            view.translationY = dp(16f)
        }
        host.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
        if (animate) view.animate().alpha(1f).translationY(0f).setDuration(260).start()
        applyInsets()
    }

    // ------------------------------------------------------------ abertura

    private fun showSplash(message: String?) {
        val v = scaffold("", "") {
            put(logoBadge(96), 120, dpi(96), dpi(96))
            val t = txt("Duelo de Minas", 28f, cWhite, true)
            t.gravity = Gravity.CENTER
            put(t, 12)
            if (message != null) {
                val m = txt(message, 14f, cDim)
                m.gravity = Gravity.CENTER
                m.setOnClickListener { showSplash(null); startSession() }
                put(m, 16)
            }
        }
        setScreen(v, false)
    }

    // ------------------------------------------------------------ login e criar conta

    private fun showAuth() {
        GameUi.detach()
        var signup = false
        val v = scaffold("", "") {
            put(logoBadge(84), 30, dpi(84), dpi(84))
            val title = txt("Duelo de Minas", 30f, cWhite, true)
            title.gravity = Gravity.CENTER
            put(title, 6)
            val sub = txt("Entre ou crie sua conta para jogar.", 14f, cDim)
            sub.gravity = Gravity.CENTER
            put(sub, 4)

            val tabs = LinearLayout(this@MainActivity)
            tabs.orientation = LinearLayout.HORIZONTAL
            val tLogin = tabPill("Entrar")
            val tSign = tabPill("Criar conta")
            tabs.addView(tLogin, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dpi(6) })
            tabs.addView(tSign, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dpi(6) })
            put(tabs, 26)

            val email = input("E-mail", "")
            email.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            put(email, 14)
            val pass = input("Senha (mínimo 8 caracteres)", "")
            pass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            put(pass, 10)
            val pass2 = input("Repita a senha", "")
            pass2.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            pass2.visibility = View.GONE
            put(pass2, 10)

            lateinit var submit: TextView
            fun refresh() {
                pass2.visibility = if (signup) View.VISIBLE else View.GONE
                styleTab(tLogin, !signup)
                styleTab(tSign, signup)
                submit.text = if (signup) "Criar conta" else "Entrar"
            }
            submit = button("Entrar") {
                val e = email.text.toString().trim()
                val p1 = pass.text.toString()
                if (!e.contains("@") || !e.contains(".")) {
                    toast("Digite um e-mail válido.")
                } else if (p1.length < 8) {
                    toast("A senha precisa ter pelo menos 8 caracteres.")
                } else if (signup && p1 != pass2.text.toString()) {
                    toast("As senhas não são iguais.")
                } else {
                    busy(submit, true)
                    if (signup) {
                        bg(onFail = { busy(submit, false) }, work = { Api.signUp(e, p1) }) { entered ->
                            busy(submit, false)
                            if (entered) {
                                startSession()
                            } else {
                                toast("Conta criada! Confirme seu e-mail e depois toque em Entrar.")
                                signup = false
                                refresh()
                            }
                        }
                    } else {
                        bg(onFail = { busy(submit, false) }, work = { Api.signIn(e, p1) }) {
                            startSession()
                        }
                    }
                }
            }
            put(submit, 18)
            tLogin.setOnClickListener { signup = false; refresh() }
            tSign.setOnClickListener { signup = true; refresh() }
            refresh()

            val notice = SpannableString("Ao continuar, você concorda com os Termos de Uso e confirma ter 18 anos ou mais.")
            val start = notice.indexOf("Termos de Uso")
            notice.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) { showTermsDialog() }
                override fun updateDrawState(ds: TextPaint) {
                    ds.color = 0xFF67E8F9.toInt()
                    ds.isUnderlineText = true
                }
            }, start, start + "Termos de Uso".length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            val nt = txt("", 12.5f, cFaint)
            nt.text = notice
            nt.movementMethod = LinkMovementMethod.getInstance()
            nt.highlightColor = Color.TRANSPARENT
            nt.gravity = Gravity.CENTER
            put(nt, 16)
        }
        setScreen(v, false)
    }

    private fun tabPill(label: String): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setTextColor(cWhite)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setPadding(dpi(12), dpi(12), dpi(12), dpi(12))
        t.isClickable = true
        t.pressable()
        return t
    }

    private fun styleTab(t: TextView, selected: Boolean) {
        if (selected) {
            val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7C4DFF.toInt(), 0xFF06B6D4.toInt()))
            g.cornerRadius = dp(16f)
            t.background = g
        } else {
            t.background = glass(16f)
        }
    }

    internal fun showTermsDialog() {
        val body = TextView(this)
        body.text = TERMS_TEXT
        body.textSize = 14f
        body.setTextColor(cWhite)
        body.setPadding(dpi(20), dpi(12), dpi(20), dpi(12))
        val sv = ScrollView(this)
        sv.addView(body)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Termos de Uso")
            .setView(sv)
            .setPositiveButton("Fechar", null)
            .show()
    }

    // ------------------------------------------------------------ termos (depois de criar a conta)

    private fun showTerms() {
        val v = scaffold("Termos de Uso", "Leia com atenção antes de continuar.") {
            put(card { put(txt(TERMS_TEXT, 13.5f, cDim), 0) }, 0)
            val c18 = CheckBox(this@MainActivity)
            c18.text = "Tenho 18 anos ou mais."
            c18.setTextColor(cWhite)
            val cOk = CheckBox(this@MainActivity)
            cOk.text = "Li e aceito os Termos de Uso. Sei que posso perder dinheiro e que o app não se responsabiliza pelo resultado das partidas entre jogadores."
            cOk.setTextColor(cWhite)
            put(c18, 16)
            put(cOk, 4)
            lateinit var go: TextView
            go = button("Aceitar e continuar") {
                if (!c18.isChecked || !cOk.isChecked) {
                    toast("Marque as duas opções para continuar.")
                } else {
                    busy(go, true)
                    bg(onFail = { busy(go, false) }, work = { Api.acceptTerms(TERMS_VERSION); Api.profile() }) { p ->
                        me = p
                        route()
                    }
                }
            }
            put(go, 16)
            put(button("Sair da conta", false) { logout() }, 10)
        }
        setScreen(v, false)
    }

    // ------------------------------------------------------------ configuração de perfil (obrigatória)

    private fun showSetup() {
        pendingPhoto = null
        pendingGif = false
        val v = scaffold("Seu perfil", "Antes de jogar, conte quem você é.") {
            val av = AvatarView(this@MainActivity)
            av.setPerson("?", null)
            av.setOnClickListener { pickPhoto(0) }
            setupAvatar = av
            put(av, 4, dpi(120), dpi(120))
            val hint = txt("Foto opcional — toque para escolher (JPG, PNG ou GIF)", 13f, cDim)
            hint.gravity = Gravity.CENTER
            put(hint, 8)

            put(card {
                put(label("NOME DE EXIBIÇÃO"), 0)
                val nameIn = input("Como você quer ser chamado", "")
                nameIn.filters = arrayOf(InputFilter.LengthFilter(20))
                put(nameIn, 8)
                put(label("PAÍS"), 16)
                val country = iconText(ICON_PIN, "Brasil", 16f, cWhite)
                country.background = glass(16f, 0.7f)
                country.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
                put(country, 8)
                put(label("BIO"), 16)
                val bioIn = input("Fale um pouco sobre você", "")
                bioIn.setSingleLine(false)
                bioIn.minLines = 3
                bioIn.gravity = Gravity.TOP or Gravity.START
                bioIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                bioIn.filters = arrayOf(InputFilter.LengthFilter(200))
                put(bioIn, 8)

                lateinit var done: TextView
                done = button("Concluir") {
                    val photo = pendingPhoto
                    val n = nameIn.text.toString().trim()
                    if (n.length < 3) {
                        toast("O nome precisa ter pelo menos 3 letras.")
                    } else {
                        busy(done, true)
                        val bio = bioIn.text.toString().trim()
                        bg(onFail = { busy(done, false) }, work = {
                            val f = JSONObject()
                            f.put("display_name", n)
                            f.put("bio", bio)
                            f.put("country", "BR")
                            f.put("profile_done", true)
                            if (photo != null) {
                                val url = Api.uploadAvatar(photo, pendingGif)
                                f.put("avatar_url", url)
                            }
                            Api.completeProfile(f)
                            Api.profile()
                        }) { p ->
                            me = p
                            route()
                        }
                    }
                }
                put(done, 20)
                val cancel = txt("Cancelar e sair", 14f, cDim)
                cancel.gravity = Gravity.CENTER
                cancel.setPadding(0, dpi(16), 0, dpi(8))
                cancel.isClickable = true
                cancel.setOnClickListener {
                    glassDialog(
                        title = "Sair?",
                        message = "Você pode entrar de novo depois e terminar o perfil.",
                        positive = "Sair",
                        negative = "Continuar",
                        danger = true
                    ) {
                        logout()
                        true
                    }
                }
                put(cancel, 4)
            }, 18)
        }
        setScreen(v, false)
    }

    // ------------------------------------------------------------ foto

    internal fun pickPhoto(purpose: Int) {
        photoPurpose = purpose
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "Escolher foto"), REQ_PHOTO)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != REQ_PHOTO || resultCode != RESULT_OK || uri == null) return
        val purpose = photoPurpose
        val isGif = (contentResolver.getType(uri) ?: "") == "image/gif"
        bg(work = { if (isGif) readGif(uri) else decodePhoto(uri) }) { pic ->
            if (purpose == 0) {
                pendingPhoto = pic.bytes
                pendingGif = pic.gif
                showPicked(setupAvatar, pic)
            } else {
                showPicked(profileAvatar, pic)
                bg(work = {
                    val url = Api.uploadAvatar(pic.bytes, pic.gif)
                    Api.updateProfile(JSONObject().put("avatar_url", url))
                    Api.profile()
                }) { p ->
                    me = p
                    toast(if (pic.gif) "GIF de perfil atualizado!" else "Foto atualizada!")
                }
            }
        }
    }

    private fun showPicked(av: AvatarView?, pic: Picked) {
        if (av == null) return
        if (pic.gif) av.setImageBytes(pic.bytes) else pic.bmp?.let { av.setBitmapDirect(it) }
    }

    private fun readGif(uri: Uri): Picked {
        val limit = 5 * 1024 * 1024
        val out = ByteArrayOutputStream()
        contentResolver.openInputStream(uri)?.use { input ->
            val buf = ByteArray(16 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > limit) throw ApiException(0, "O GIF é grande demais. Use um de até 5 MB.")
            }
        } ?: throw ApiException(0, "Não consegui abrir esse GIF.")
        return Picked(out.toByteArray(), null, true)
    }

    private fun decodePhoto(uri: Uri): Picked {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (bounds.outWidth / (s * 2) >= 1024 && bounds.outHeight / (s * 2) >= 1024) s *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = s
        var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw ApiException(0, "Não consegui abrir essa foto.")
        val orientation = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            } ?: 1
        } catch (e: Exception) {
            1
        }
        val deg = when (orientation) {
            6 -> 90f
            3 -> 180f
            8 -> 270f
            else -> 0f
        }
        if (deg != 0f) {
            val m = Matrix()
            m.postRotate(deg)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val side = min(bmp.width, bmp.height)
        val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val out = Bitmap.createScaledBitmap(square, 512, 512, true)
        val baos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 85, baos)
        return Picked(baos.toByteArray(), out, false)
    }

    // ------------------------------------------------------------ app principal

    internal fun showMain() {
        GameUi.attach(this)
        if (Game.state != null) {
            // voltou para o app no meio de uma sala/partida: mostra a sala, não o Lobby
            renderRoom()
        } else {
            nav.select(0, false)
            showTab(0)
        }
    }

    internal fun goTab(i: Int) {
        nav.select(i, true)
        showTab(i)
    }

    override fun onPause() {
        super.onPause()
        AppUpdate.onActivityPause()
        Game.lastActive = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        AppUpdate.onActivityResume(this) // continua instalação se o APK já foi baixado
        if (Api.hasSession() && Game.listener != null) {
            val away = System.currentTimeMillis() - Game.lastActive
            if (!Game.connected || (Game.lastActive > 0 && away > 15_000)) Game.reconnectNow(true)
            Game.send("sync")
            if (Game.state != null && !GameUi.inRoomScreen) renderRoom()
        }
    }

    internal fun showTab(i: Int) {
        GameUi.stopTicker()
        GameUi.inRoomScreen = false
        setupAvatar = null
        profileAvatar = null
        val v = when (i) {
            0 -> lobbyScreen()
            1 -> buildRooms()
            2 -> buildRanking()
            else -> profileScreen()
        }
        setScreen(v, true)
    }

    internal fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            h < 12 -> "Bom dia"
            h < 18 -> "Boa tarde"
            else -> "Boa noite"
        }
    }

    internal fun money(cents: Long): String =
        String.format(Locale.forLanguageTag("pt-BR"), "R$ %.2f", cents / 100.0)

    private fun buildRooms(): ScrollView = buildRoomList()

    private fun buildRanking(): ScrollView {
        var box: LinearLayout? = null
        val v = scaffold("Ranking", "Top 10 global do Duelo de Minas.") {
            val b = LinearLayout(this@MainActivity)
            b.orientation = LinearLayout.VERTICAL
            box = b
            put(b, 0)
            b.addView(txt("Carregando…", 14f, cDim))
        }
        bg(onFail = {
            box?.removeAllViews()
            box?.addView(txt("Não foi possível carregar o ranking.", 14f, cDim))
        }, work = {
            val list = Api.ranking()
            val ver = try { Api.verifiedIds() } catch (_: Exception) { emptySet<String>() }
            Pair(list, ver)
        }) { res ->
            renderRanking(box, res.first, res.second)
        }
        return v
    }

    private fun renderRanking(box: LinearLayout?, arr: JSONArray, verified: Set<String>) {
        if (box == null) return
        box.removeAllViews()
        if (arr.length() == 0) {
            box.addView(txt("Ninguém no ranking ainda. Seja o primeiro!", 14f, cDim))
            return
        }
        for (i in 0 until min(10, arr.length())) {
            val o = arr.getJSONObject(i)
            val pos = o.optInt("position", i + 1)
            val mine = o.str("id") == Api.userId
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dpi(14), dpi(10), dpi(14), dpi(10))
            if (mine) {
                val g = GradientDrawable()
                g.cornerRadius = dp(20f)
                g.setColor(0x337C4DFF)
                g.setStroke(dpi(2), 0xFF22D3EE.toInt())
                row.background = g
            } else {
                row.background = glass(20f)
            }
            val posBox = FrameLayout(this)
            if (pos <= 3) {
                val medal = when (pos) {
                    1 -> 0xFFFACC15.toInt()
                    2 -> 0xFFCBD5E1.toInt()
                    else -> 0xFFD97706.toInt()
                }
                posBox.addView(IconView(this, ICON_MEDAL, medal), FrameLayout.LayoutParams(dpi(28), dpi(28), Gravity.CENTER))
            } else {
                val posTv = txt("$pos", 16f, cDim, true)
                posTv.gravity = Gravity.CENTER
                posBox.addView(posTv, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
            }
            row.addView(posBox, LinearLayout.LayoutParams(dpi(40), dpi(30)))
            val av = AvatarView(this)
            av.setPerson(o.str("display_name"), o.str("avatar_url"))
            row.addView(av, LinearLayout.LayoutParams(dpi(46), dpi(46)))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(nameWithBadge(o.str("display_name").ifEmpty { "Jogador" }, 16f, o.str("id") in verified))
            col.addView(txt(if (o.str("country") == "BR") "Brasil" else o.str("country"), 12f, cDim))
            val colLp = LinearLayout.LayoutParams(0, WRAP, 1f)
            colLp.leftMargin = dpi(12)
            row.addView(col, colLp)
            val wins = o.optInt("wins", 0)
            row.addView(txt("$wins " + (if (wins == 1) "vitória" else "vitórias"), 15f, cWhite, true))
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dpi(if (i == 0) 0 else 8)
            box.addView(row, lp)
        }
    }

    internal fun confirmDelete() {
        glassDialog(
            title = "Apagar conta?",
            message = "Isso apaga seu perfil e sua foto e não dá para desfazer. Contas com saldo ou movimentações financeiras não podem ser apagadas por aqui.",
            positive = "Apagar",
            danger = true
        ) {
            bg(work = { Api.deleteAvatar(); Api.deleteAccount() }) {
                me = null
                toast("Conta apagada.")
                showAuth()
            }
            true
        }
    }

    // ------------------------------------------------------------ componentes visuais

    /**
     * Diálogo no mesmo estilo do app (vidro escuro, botões do app).
     * [onPositive] devolve true para fechar o diálogo, false para mantê-lo aberto.
     */
    internal fun glassDialog(
        title: String,
        message: String? = null,
        content: View? = null,
        positive: String,
        negative: String? = "Cancelar",
        danger: Boolean = false,
        onPositive: () -> Boolean = { true }
    ): android.app.Dialog {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dpi(22), dpi(24), dpi(22), dpi(20))
        box.background = GlassDrawable(dp(28f), dp(1f), 1f, 0xF2141436.toInt())

        box.addView(txt(title, 21f, cWhite, true))
        if (message != null) {
            val mt = txt(message, 14f, cDim)
            mt.setPadding(0, dpi(8), 0, 0)
            box.addView(mt)
        }
        if (content != null) {
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dpi(16)
            box.addView(content, lp)
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        if (negative != null) {
            val no = button(negative, false) { dlg.dismiss() }
            val nlp = LinearLayout.LayoutParams(0, WRAP, 1f)
            nlp.rightMargin = dpi(5)
            row.addView(no, nlp)
        }
        val yes = button(positive, true) { if (onPositive()) dlg.dismiss() }
        if (danger) {
            val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFEF4444.toInt(), 0xFFF97316.toInt()))
            g.cornerRadius = dp(18f)
            yes.background = g
        }
        val ylp = LinearLayout.LayoutParams(0, WRAP, 1f)
        if (negative != null) ylp.leftMargin = dpi(5)
        row.addView(yes, ylp)
        val rlp = LinearLayout.LayoutParams(MATCH, WRAP)
        rlp.topMargin = dpi(22)
        box.addView(row, rlp)

        dlg.setContentView(box)
        val w = dlg.window
        if (w != null) {
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setDimAmount(0.65f)
            val width = min(resources.displayMetrics.widthPixels - dpi(40), dpi(380))
            w.setLayout(width, android.view.WindowManager.LayoutParams.WRAP_CONTENT)
            w.setSoftInputMode(
                android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                    android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
            )
            setSecure(w, hasPasswordField(box))
        }
        dlg.show()
        return dlg
    }

    /** Linha com ícone desenhado + texto (no lugar de emoji). */
    internal fun iconText(kind: Int, s: String, sp: Float, color: Int = cDim, bold: Boolean = false, center: Boolean = false): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = if (center) Gravity.CENTER else (Gravity.CENTER_VERTICAL or Gravity.START)
        val sz = dpi((sp * 1.3f).toInt())
        r.addView(IconView(this, kind, color), LinearLayout.LayoutParams(sz, sz))
        val t = txt(s, sp, color, bold)
        t.setPadding(dpi(7), 0, 0, 0)
        r.addView(t, LinearLayout.LayoutParams(WRAP, WRAP))
        return r
    }

    /** Nome com o selo azul de verificado ao lado (quando [verified]). */
    internal fun nameWithBadge(name: String, sp: Float, verified: Boolean, color: Int = cWhite, bold: Boolean = true, center: Boolean = false): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = if (center) Gravity.CENTER else (Gravity.CENTER_VERTICAL or Gravity.START)
        val t = txt(name, sp, color, bold)
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        r.addView(t, LinearLayout.LayoutParams(WRAP, WRAP))
        if (verified) {
            val sz = dpi((sp * 1.15f).toInt())
            val lp = LinearLayout.LayoutParams(sz, sz)
            lp.leftMargin = dpi(5)
            r.addView(IconView(this, ICON_VERIFIED, 0xFF3B9BFF.toInt()), lp)
        }
        return r
    }

    /** Selo redondo de vidro com a bomba do jogo (logo do app). */
    internal fun logoBadge(sizeDp: Int): View {
        val f = FrameLayout(this)
        f.background = GlassDrawable(dp(sizeDp / 2f), dp(1.2f), 1.3f, 0x66101030)
        val ic = IconView(this, ICON_BOMB, cWhite)
        val inner = dpi((sizeDp * 0.5f).toInt())
        f.addView(ic, FrameLayout.LayoutParams(inner, inner, Gravity.CENTER))
        return f
    }

    internal fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    internal fun glass(radiusDp: Float, strength: Float = 1f) = GlassDrawable(dp(radiusDp), dp(1f), strength)

    internal fun txt(s: String, sp: Float, color: Int = cWhite, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        t.typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        return t
    }

    internal fun label(s: String): TextView {
        val t = txt(s, 11f, cDim, true)
        t.letterSpacing = 0.14f
        return t
    }

    internal fun LinearLayout.put(v: View, topDp: Int = 12, w: Int = MATCH, h: Int = WRAP): View {
        val lp = LinearLayout.LayoutParams(w, h)
        lp.topMargin = dpi(topDp)
        if (w != MATCH) lp.gravity = Gravity.CENTER_HORIZONTAL
        addView(v, lp)
        return v
    }

    internal fun scaffold(title: String, subtitle: String, build: LinearLayout.() -> Unit): ScrollView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        if (title.isNotEmpty()) {
            col.addView(txt(title, 32f, cWhite, true))
            val sub = txt(subtitle, 14f, cDim)
            sub.setPadding(0, dpi(4), 0, dpi(18))
            col.addView(sub)
        }
        col.build()
        val sv = ScrollView(this)
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        sv.isVerticalScrollBarEnabled = false
        sv.clipToPadding = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        return sv
    }

    internal fun card(build: LinearLayout.() -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dpi(18), dpi(18), dpi(18), dpi(18))
        c.background = glass(24f)
        c.build()
        return c
    }

    internal fun button(label: String, primary: Boolean = true, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.textSize = 16f
        b.setTextColor(cWhite)
        b.gravity = Gravity.CENTER
        b.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        b.setPadding(dpi(16), dpi(16), dpi(16), dpi(16))
        if (primary) {
            val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7C4DFF.toInt(), 0xFF06B6D4.toInt()))
            g.cornerRadius = dp(18f)
            b.background = g
        } else {
            b.background = glass(18f)
        }
        b.isClickable = true
        b.setOnClickListener { onClick() }
        // Protege todas as ações do app contra toques vindos de uma janela sobreposta.
        b.filterTouchesWhenObscured = true
        b.pressable()
        return b
    }

    internal fun input(placeholder: String, value: String): EditText {
        val e = EditText(this)
        e.setText(value)
        e.hint = placeholder
        e.setTextColor(cWhite)
        e.setHintTextColor(cFaint)
        e.textSize = 16f
        e.setSingleLine(true)
        e.background = glass(16f, 0.7f)
        e.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
        return e
    }
}
