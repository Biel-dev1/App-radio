package com.duelominas

import android.app.Activity
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Checks the public GitHub release and downloads the APK when a newer one exists. */
object AppUpdate {
    private const val API_URL = "https://api.github.com/repos/Biel-dev1/App-radio/releases/latest"
    private const val APK_NAME = "app-release.apk"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private class Latest(val version: Int, val apkUrl: String)

    private var launchChecked = false

    private fun installedVersion(a: Activity): Int =
        a.packageManager.getPackageInfo(a.packageName, 0).longVersionCode.toInt()

    /** Consulta a última versão publicada no GitHub. Chame fora da thread principal. */
    private fun fetchLatest(): Latest {
        val request = Request.Builder()
            .url(API_URL)
            .header("Accept", "application/vnd.github+json")
            .header("User-Agent", "Duelo-de-Minas")
            .build()
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("GitHub respondeu ${response.code}")
            val release = JSONObject(response.body?.string() ?: error("Resposta vazia"))
            val tag = release.optString("tag_name", "").removePrefix("v")
            val version = tag.toIntOrNull() ?: error("Versão inválida")
            val assets = release.optJSONArray("assets") ?: error("APK não encontrado")
            var apkUrl = ""
            for (i in 0 until assets.length()) {
                val asset = assets.optJSONObject(i) ?: continue
                if (asset.optString("name") == APK_NAME) {
                    apkUrl = asset.optString("browser_download_url")
                    break
                }
            }
            if (apkUrl.isBlank()) error("APK não encontrado")
            if (!apkUrl.startsWith("https://github.com/Biel-dev1/App-radio/releases/download/")) error("Origem da atualização não confiável")
            Latest(version, apkUrl)
        }
    }

    private fun askToUpdate(a: MainActivity, latest: Latest) {
        a.glassDialog(
            title = "Atualização disponível",
            message = "A versão v${latest.version} está pronta. Atualize agora para jogar com a versão mais recente.",
            positive = "Atualizar agora",
            negative = "Depois"
        ) {
            download(a, latest.version, latest.apkUrl)
            true
        }
    }

    /** Ao abrir o app: confere sozinho. Só aparece algo se existir versão mais nova. */
    fun checkOnLaunch(a: MainActivity) {
        if (launchChecked) return
        launchChecked = true
        thread {
            try {
                val latest = fetchLatest()
                if (latest.version > installedVersion(a)) {
                    a.runOnUiThread { if (!a.isFinishing) askToUpdate(a, latest) }
                }
            } catch (_: Exception) {
                // sem internet ou GitHub fora do ar: segue sem avisar
            }
        }
    }

    /** Verificação manual (Perfil > Atualizações): sempre responde com o resultado. */
    fun check(a: MainActivity) {
        a.toast("Verificando atualização…")
        thread {
            try {
                val latest = fetchLatest()
                val mine = installedVersion(a)
                a.runOnUiThread {
                    if (a.isFinishing) return@runOnUiThread
                    if (latest.version <= mine) {
                        a.glassDialog(
                            title = "Tudo atualizado",
                            message = "Você já está usando a versão mais recente (v$mine).",
                            positive = "Ok",
                            negative = null
                        )
                    } else {
                        askToUpdate(a, latest)
                    }
                }
            } catch (e: Exception) {
                a.runOnUiThread {
                    if (!a.isFinishing) {
                        a.glassDialog(
                            title = "Não foi possível verificar",
                            message = "Confira sua internet e tente novamente.",
                            positive = "Ok",
                            negative = null
                        )
                    }
                }
            }
        }
    }

    private fun download(activity: Activity, version: Int, url: String) {
        val dir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: return Toast.makeText(activity, "Não foi possível preparar o download.", Toast.LENGTH_SHORT).show()
        val file = File(dir, "duelo-minas-v$version.apk")
        if (file.exists()) file.delete()

        val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle("Duelo de Minas v$version")
            .setDescription("Baixando atualização…")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationUri(Uri.fromFile(file))
        val downloadId = manager.enqueue(request)

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) != downloadId) return
                try {
                    activity.unregisterReceiver(this)
                } catch (_: Exception) { }
                val query = DownloadManager.Query().setFilterById(downloadId)
                manager.query(query)?.use { cursor ->
                    if (!cursor.moveToFirst() || cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_SUCCESSFUL) {
                        Toast.makeText(activity, "O download da atualização falhou.", Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                install(activity, file)
            }
        }
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) {
            activity.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            activity.registerReceiver(receiver, filter)
        }
        Toast.makeText(activity, "Atualização baixando em segundo plano.", Toast.LENGTH_SHORT).show()
    }

    private fun install(activity: Activity, file: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
            val settings = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                .setData(Uri.parse("package:${activity.packageName}"))
            activity.startActivity(settings)
            Toast.makeText(activity, "Permita instalar e abra o app de novo para atualizar.", Toast.LENGTH_LONG).show()
            return
        }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        activity.startActivity(intent)
    }
}
