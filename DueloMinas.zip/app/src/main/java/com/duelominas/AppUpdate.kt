package com.duelominas

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Checks the public GitHub release and downloads the APK when a newer one exists. */
object AppUpdate {
    private const val API_URL = "https://api.github.com/repos/Biel-dev1/App-radio/releases/latest"
    private const val APK_NAME = "app-release.apk"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    fun check(activity: Activity) {
        val progress = AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Procurando atualização")
            .setMessage("Verificando a versão mais recente…")
            .setNegativeButton("Cancelar", null)
            .create()
        progress.show()

        thread {
            try {
                val request = Request.Builder()
                    .url(API_URL)
                    .header("Accept", "application/vnd.github+json")
                    .header("User-Agent", "Duelo-de-Minas")
                    .build()
                val response = client.newCall(request).execute()
                if (!response.isSuccessful) error("GitHub respondeu ${response.code}")
                val release = JSONObject(response.body?.string() ?: error("Resposta vazia"))
                val tag = release.optString("tag_name", "").removePrefix("v")
                val version = tag.toIntOrNull() ?: error("Versão inválida")
                val assets = release.optJSONArray("assets") ?: error("APK não encontrado")
                var apkUrl = ""
                for (i in 0 until assets.length()) {
                    val asset = assets.optJSONObject(i) ?: continue
                    if (asset.optString("name") == APK_NAME) {
                        apkUrl = asset.optString("browser_download_url")
                        break
                    }
                }
                if (apkUrl.isBlank()) error("APK não encontrado")

                activity.runOnUiThread {
                    if (!activity.isFinishing && progress.isShowing) progress.dismiss()
                    if (version <= BuildConfig.VERSION_CODE) {
                        AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
                            .setTitle("Tudo atualizado")
                            .setMessage("Você já está usando a versão mais recente (v${BuildConfig.VERSION_CODE}).")
                            .setPositiveButton("OK", null)
                            .show()
                    } else {
                        AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
                            .setTitle("Nova versão disponível")
                            .setMessage("A versão v$version está pronta. Baixar e instalar agora?")
                            .setNegativeButton("Depois", null)
                            .setPositiveButton("Atualizar") { _, _ -> download(activity, version, apkUrl) }
                            .show()
                    }
                }
            } catch (e: Exception) {
                activity.runOnUiThread {
                    if (!activity.isFinishing && progress.isShowing) progress.dismiss()
                    if (!activity.isFinishing) {
                        AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
                            .setTitle("Não foi possível verificar")
                            .setMessage("Confira sua internet e tente novamente.")
                            .setPositiveButton("OK", null)
                            .show()
                    }
                }
            }
        }
    }

    private fun download(activity: Activity, version: Int, url: String) {
        val dir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: return Toast.makeText(activity, "Não foi possível preparar o download.", Toast.LENGTH_SHORT).show()
        val file = File(dir, "duelo-minas-v$version.apk")
        if (file.exists()) file.delete()

        val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle("Duelo de Minas v$version")
            .setDescription("Baixando atualização…")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationUri(Uri.fromFile(file))
        val downloadId = manager.enqueue(request)

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) != downloadId) return
                try {
                    activity.unregisterReceiver(this)
                } catch (_: Exception) { }
                val query = DownloadManager.Query().setFilterById(downloadId)
                manager.query(query)?.use { cursor ->
                    if (!cursor.moveToFirst() || cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_SUCCESSFUL) {
                        Toast.makeText(activity, "O download da atualização falhou.", Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                install(activity, file)
            }
        }
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) {
            activity.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            activity.registerReceiver(receiver, filter)
        }
        Toast.makeText(activity, "Atualização baixando em segundo plano.", Toast.LENGTH_SHORT).show()
    }

    private fun install(activity: Activity, file: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
            val settings = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                .setData(Uri.parse("package:${activity.packageName}"))
            activity.startActivity(settings)
            Toast.makeText(activity, "Permita instalar atualizações e toque em Procurar atualização novamente.", Toast.LENGTH_LONG).show()
            return
        }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        activity.startActivity(intent)
    }
}
