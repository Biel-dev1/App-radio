package com.duelominas

import android.app.Activity
import android.app.DownloadManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Atualização:
 * 1) consulta release no GitHub
 * 2) baixa APK em segundo plano
 * 3) confere SHA-256
 * 4) abre o instalador do sistema sozinho
 *
 * O Android sempre pede um toque final de confirmação (regra do sistema).
 * Se faltar permissão de "instalar apps desconhecidos", guarda o APK e
 * tenta instalar de novo quando o app volta (onResume).
 */
object AppUpdate {
    private const val API_URL = "https://api.github.com/repos/Biel-dev1/App-radio/releases/latest"
    private const val APK_NAME = "app-release.apk"
    private const val PREFS = "app_update"
    private const val KEY_PENDING = "pending_apk"
    private const val KEY_PENDING_VER = "pending_ver"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private class Latest(val version: Int, val apkUrl: String, val shaUrl: String, val size: Long)

    private var launchChecked = false
    private var installing = false

    private fun installedVersion(a: Activity): Int =
        a.packageManager.getPackageInfo(a.packageName, 0).longVersionCode.toInt()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun savePending(ctx: Context, file: File, version: Int) {
        prefs(ctx).edit()
            .putString(KEY_PENDING, file.absolutePath)
            .putInt(KEY_PENDING_VER, version)
            .apply()
    }

    private fun clearPending(ctx: Context) {
        prefs(ctx).edit().remove(KEY_PENDING).remove(KEY_PENDING_VER).apply()
    }

    private fun pendingFile(ctx: Context): File? {
        val path = prefs(ctx).getString(KEY_PENDING, null) ?: return null
        val f = File(path)
        return if (f.isFile && f.length() > 100_000) f else null
    }

    /** Consulta a última versão publicada no GitHub. Fora da thread principal. */
    private fun fetchLatest(): Latest {
        val request = Request.Builder()
            .url(API_URL)
            .header("Accept", "application/vnd.github+json")
            .header("User-Agent", "Duelo-de-Minas")
            .build()
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("GitHub respondeu ${response.code}")
            val release = JSONObject(response.body?.string() ?: error("Resposta vazia"))
            val tag = release.optString("tag_name", "").removePrefix("v")
            val version = tag.toIntOrNull() ?: error("Versão inválida")
            val assets = release.optJSONArray("assets") ?: error("APK não encontrado")
            var apkUrl = ""
            var shaUrl = ""
            var size = 0L
            for (i in 0 until assets.length()) {
                val asset = assets.optJSONObject(i) ?: continue
                val name = asset.optString("name")
                when (name) {
                    APK_NAME -> {
                        apkUrl = asset.optString("browser_download_url")
                        size = asset.optLong("size", 0)
                    }
                    "$APK_NAME.sha256" -> shaUrl = asset.optString("browser_download_url")
                }
            }
            if (apkUrl.isBlank() || size !in 100_000..200_000_000) error("Atualização incompleta")
            if (!apkUrl.startsWith("https://github.com/Biel-dev1/App-radio/releases/download/")) {
                error("Origem da atualização não confiável")
            }
            // SHA opcional se a release antiga não tiver; preferimos com hash
            if (shaUrl.isNotBlank() &&
                !shaUrl.startsWith("https://github.com/Biel-dev1/App-radio/releases/download/")
            ) error("Origem do hash não confiável")
            Latest(version, apkUrl, shaUrl, size)
        }
    }

    fun checkOnLaunch(a: MainActivity) {
        if (launchChecked) return
        launchChecked = true
        // Se já tem APK baixado de antes, tenta instalar
        tryInstallPending(a)
        thread {
            try {
                val latest = fetchLatest()
                if (latest.version > installedVersion(a)) {
                    a.runOnUiThread { askToUpdate(a, latest) }
                }
            } catch (_: Exception) { }
        }
    }

    fun check(a: Activity) {
        Toast.makeText(a, "Procurando atualização…", Toast.LENGTH_SHORT).show()
        thread {
            try {
                val latest = fetchLatest()
                a.runOnUiThread {
                    val mine = installedVersion(a)
                    when {
                        latest.version > mine -> askToUpdate(a, latest)
                        else -> Toast.makeText(a, "Você já está na versão mais recente (v$mine).", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                a.runOnUiThread {
                    Toast.makeText(a, "Não deu para checar: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** Chamado no onResume: se o usuário voltou das configurações de permissão, instala. */
    fun onActivityResume(a: Activity) {
        tryInstallPending(a)
    }

    private fun askToUpdate(a: Activity, latest: Latest) {
        android.app.AlertDialog.Builder(a)
            .setTitle("Atualização disponível")
            .setMessage("A versão v${latest.version} está pronta. Baixar e instalar agora?")
            .setPositiveButton("Atualizar") { _, _ -> download(a, latest) }
            .setNegativeButton("Depois", null)
            .show()
    }

    private fun download(activity: Activity, latest: Latest) {
        thread {
            val expected = try {
                if (latest.shaUrl.isBlank()) null
                else {
                    val req = Request.Builder().url(latest.shaUrl)
                        .header("User-Agent", "Duelo-de-Minas").build()
                    client.newCall(req).execute().use {
                        if (!it.isSuccessful) error("hash indisponível")
                        // formato: "<hex>  app-release.apk" ou só hex
                        val body = it.body?.string()?.trim().orEmpty()
                        body.split(Regex("\\s+")).firstOrNull()
                            ?.takeIf { h -> h.length == 64 && h.all { c -> c in "0123456789abcdefABCDEF" } }
                            ?.lowercase()
                            ?: error("hash inválido")
                    }
                }
            } catch (e: Exception) {
                activity.runOnUiThread {
                    Toast.makeText(activity, "Falha ao ler verificação: ${e.message}", Toast.LENGTH_LONG).show()
                }
                return@thread
            }

            activity.runOnUiThread {
                startDownload(activity, latest, expected)
            }
        }
    }

    private fun startDownload(activity: Activity, latest: Latest, expected: String?) {
        val dir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: activity.filesDir
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, "duelo-minas-v${latest.version}.apk")
        if (file.exists()) file.delete()

        val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val request = DownloadManager.Request(Uri.parse(latest.apkUrl))
            .setTitle("Duelo de Minas v${latest.version}")
            .setDescription("Baixando atualização…")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(activity, Environment.DIRECTORY_DOWNLOADS, file.name)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)

        val downloadId = manager.enqueue(request)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) ?: return
                if (id != downloadId) return
                try {
                    activity.unregisterReceiver(this)
                } catch (_: Exception) { }

                val query = DownloadManager.Query().setFilterById(downloadId)
                manager.query(query)?.use { cursor ->
                    if (!cursor.moveToFirst() ||
                        cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        != DownloadManager.STATUS_SUCCESSFUL
                    ) {
                        Toast.makeText(activity, "O download da atualização falhou.", Toast.LENGTH_SHORT).show()
                        return
                    }
                }

                // DownloadManager pode gravar com o nome pedido; garante o File certo
                val downloaded = if (file.exists()) file
                else File(dir, file.name)

                if (!downloaded.exists() || downloaded.length() < 100_000) {
                    Toast.makeText(activity, "Arquivo da atualização não encontrado.", Toast.LENGTH_LONG).show()
                    return
                }
                if (downloaded.length() != latest.size) {
                    // tamanho divergente às vezes por redirect; confia no hash se houver
                    if (expected == null) {
                        downloaded.delete()
                        Toast.makeText(activity, "Tamanho da atualização inválido.", Toast.LENGTH_LONG).show()
                        return
                    }
                }
                if (expected != null && sha256(downloaded) != expected) {
                    downloaded.delete()
                    Toast.makeText(activity, "A atualização não passou na verificação.", Toast.LENGTH_LONG).show()
                    return
                }

                savePending(activity, downloaded, latest.version)
                Toast.makeText(activity, "Download ok. Abrindo instalação…", Toast.LENGTH_SHORT).show()
                install(activity, downloaded)
            }
        }
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) {
            activity.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            activity.registerReceiver(receiver, filter)
        }
        Toast.makeText(activity, "Baixando atualização em segundo plano…", Toast.LENGTH_SHORT).show()
    }

    private fun sha256(file: File): String = FileInputStream(file).use { input ->
        val md = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(8192)
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            md.update(buffer, 0, n)
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun tryInstallPending(a: Activity) {
        val file = pendingFile(a) ?: return
        val ver = prefs(a).getInt(KEY_PENDING_VER, 0)
        if (ver > 0 && ver <= installedVersion(a)) {
            // já atualizou
            file.delete()
            clearPending(a)
            return
        }
        install(a, file)
    }

    private fun install(activity: Activity, file: File) {
        if (installing) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !activity.packageManager.canRequestPackageInstalls()
        ) {
            savePending(activity, file, prefs(activity).getInt(KEY_PENDING_VER, 0))
            Toast.makeText(
                activity,
                "Ative “Permitir desta fonte” e volte ao app — a instalação continua sozinha.",
                Toast.LENGTH_LONG
            ).show()
            try {
                activity.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                        .setData(Uri.parse("package:${activity.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
                activity.startActivity(
                    Intent(Settings.ACTION_SECURITY_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            return
        }

        try {
            installing = true
            installWithSession(activity, file)
        } catch (e: Exception) {
            installing = false
            Toast.makeText(activity, "Não abriu o instalador: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Instala via PackageInstaller. No Android 12+, quando o app já é o "instalador" dele mesmo,
     * a atualização acontece sem tela de confirmação (USER_ACTION_NOT_REQUIRED).
     * Se o sistema exigir confirmação, abre a tela normal do Android.
     */
    private fun installWithSession(activity: Activity, file: File) {
        val ctx = activity.applicationContext
        val pi = ctx.packageManager.packageInstaller
        val params = android.content.pm.PackageInstaller.SessionParams(
            android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL
        )
        params.setAppPackageName(ctx.packageName)
        if (Build.VERSION.SDK_INT >= 31) {
            params.setRequireUserAction(
                android.content.pm.PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED
            )
        }
        val id = pi.createSession(params)
        pi.openSession(id).use { session ->
            FileInputStream(file).use { input ->
                session.openWrite("base.apk", 0, file.length()).use { out ->
                    input.copyTo(out)
                    session.fsync(out)
                }
            }
            val action = "${ctx.packageName}.INSTALL_RESULT"
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    when (i.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS, -1)) {
                        android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                            @Suppress("DEPRECATION")
                            val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                            if (confirm != null) {
                                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                try { c.startActivity(confirm) } catch (_: Exception) { }
                            }
                        }
                        android.content.pm.PackageInstaller.STATUS_SUCCESS -> {
                            try { c.unregisterReceiver(this) } catch (_: Exception) { }
                            installing = false
                        }
                        else -> {
                            try { c.unregisterReceiver(this) } catch (_: Exception) { }
                            installing = false
                            val msg = i.getStringExtra(android.content.pm.PackageInstaller.EXTRA_STATUS_MESSAGE)
                            Toast.makeText(c, "Instalação não concluída: ${msg ?: "tente de novo"}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            val filter = IntentFilter(action)
            if (Build.VERSION.SDK_INT >= 33) {
                ctx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION", "UnspecifiedRegisterReceiverFlag")
                ctx.registerReceiver(receiver, filter)
            }
            val intent = Intent(action).setPackage(ctx.packageName)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pending = PendingIntent.getBroadcast(ctx, id, intent, flags)
            session.commit(pending.intentSender)
        }
    }
}
