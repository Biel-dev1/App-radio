package com.duelominas

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Busca uma versão publicada no GitHub e abre o instalador do Android. */
object AppUpdater {
    private const val RELEASE_URL = "https://api.github.com/repos/Biel-dev1/App-radio/releases/latest"
    private val http = OkHttpClient.Builder()
        .callTimeout(3, TimeUnit.MINUTES)
        .build()

    fun check(activity: MainActivity) {
        if (!activity.packageManager.canRequestPackageInstalls()) {
            activity.toast("Permita instalar apps pelo Duelo de Minas e toque em atualizar novamente.")
            val settings = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${activity.packageName}")
            )
            activity.startActivity(settings)
            return
        }

        activity.toast("Procurando atualização…")
        thread(name = "app-update-check") {
            try {
                val releaseRequest = Request.Builder()
                    .url(RELEASE_URL)
                    .header("Accept", "application/vnd.github+json")
                    .header("X-GitHub-Api-Version", "2022-11-28")
                    .build()
                val release = http.newCall(releaseRequest).execute().use { response ->
                    if (response.code == 404) {
                        activity.runOnUiThread {
                            activity.toast("Ainda não há uma versão de atualização publicada.")
                        }
                        return@thread
                    }
                    if (!response.isSuccessful) error("GitHub respondeu ${response.code}.")
                    JSONObject(response.body?.string() ?: error("Resposta vazia do GitHub."))
                }

                val releaseTag = release.optString("tag_name")
                val latestCode = releaseTag.removePrefix("v").toLongOrNull()
                    ?: error("A versão publicada está em formato inválido.")
                val packageInfo = activity.packageManager.getPackageInfo(activity.packageName, 0)
                val installedCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    packageInfo.longVersionCode
                } else {
                    @Suppress("DEPRECATION")
                    packageInfo.versionCode.toLong()
                }
                if (latestCode <= installedCode) {
                    activity.runOnUiThread { activity.toast("Seu app já está atualizado.") }
                    return@thread
                }

                val assets = release.optJSONArray("assets") ?: error("A versão não contém arquivos.")
                var downloadUrl = ""
                for (i in 0 until assets.length()) {
                    val asset = assets.optJSONObject(i) ?: continue
                    if (asset.optString("name") == "DueloMinas.apk") {
                        downloadUrl = asset.optString("browser_download_url")
                        break
                    }
                }
                if (downloadUrl.isBlank()) error("O APK dessa versão não foi encontrado.")

                val apk = File(activity.cacheDir, "updates/DueloMinas.apk")
                apk.parentFile?.mkdirs()
                http.newCall(Request.Builder().url(downloadUrl).build()).execute().use { response ->
                    if (!response.isSuccessful) error("Não foi possível baixar o APK (${response.code}).")
                    val body = response.body ?: error("O APK veio vazio.")
                    if (body.contentLength() > 100L * 1024L * 1024L) error("O APK excede o tamanho esperado.")
                    FileOutputStream(apk).use { output -> body.byteStream().use { it.copyTo(output) } }
                }

                val uri = FileProvider.getUriForFile(
                    activity,
                    "${activity.packageName}.fileprovider",
                    apk
                )
                val install = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                activity.runOnUiThread { activity.startActivity(install) }
            } catch (e: Exception) {
                activity.runOnUiThread {
                    activity.toast(e.message?.let { "Falha ao atualizar: $it" } ?: "Falha ao verificar atualização.")
                }
            }
        }
    }
}
