package com.duelominas

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Path
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import java.nio.ByteBuffer
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.View
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

/** Baixa e guarda fotos em memória. */
object ImageLoader {
    private val http = OkHttpClient()
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private val bytesCache = object : LruCache<String, ByteArray>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ByteArray): Int = value.size
    }

    /** Baixa o arquivo sem decodificar (usado nos GIFs animados). [done] roda na thread principal. */
    fun loadBytes(url: String, done: (ByteArray?) -> Unit) {
        val cached = bytesCache.get(url)
        if (cached != null) {
            done(cached)
            return
        }
        thread {
            var out: ByteArray? = null
            try {
                http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    val b = r.body?.bytes()
                    if (r.isSuccessful && b != null && b.size <= 6 * 1024 * 1024) out = b
                }
            } catch (_: Exception) {
            }
            val result = out
            if (result != null) bytesCache.put(url, result)
            Handler(Looper.getMainLooper()).post { done(result) }
        }
    }

    /** Chama [done] sempre na thread principal. */
    fun load(url: String, maxPx: Int, done: (Bitmap?) -> Unit) {
        val cached = cache.get(url)
        if (cached != null) {
            done(cached)
            return
        }
        thread {
            var bmp: Bitmap? = null
            try {
                http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    val bytes = r.body?.bytes()
                    if (r.isSuccessful && bytes != null) {
                        val o = BitmapFactory.Options()
                        o.inJustDecodeBounds = true
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                        var s = 1
                        while (o.outWidth / (s * 2) >= maxPx && o.outHeight / (s * 2) >= maxPx) s *= 2
                        val o2 = BitmapFactory.Options()
                        o2.inSampleSize = s
                        bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
                    }
                }
            } catch (_: Exception) {
            }
            val result = bmp
            if (result != null) cache.put(url, result)
            Handler(Looper.getMainLooper()).post { done(result) }
        }
    }
}

/** Foto de perfil redonda com anel de vidro. Sem foto, mostra a inicial do nome. Aceita GIF animado. */
class AvatarView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val clip = Path()
    private var bitmap: Bitmap? = null
    private var shader: BitmapShader? = null
    private var anim: AnimatedImageDrawable? = null
    private var initial = "?"
    private var url: String? = null

    private fun isGifUrl(u: String): Boolean = u.substringBefore('?').lowercase().endsWith(".gif")

    private fun clearImage() {
        anim?.stop()
        anim = null
        bitmap = null
        shader = null
    }

    fun setPerson(name: String?, avatarUrl: String?) {
        initial = (name ?: "?").trim().take(1).uppercase().ifEmpty { "?" }
        if (avatarUrl.isNullOrEmpty()) {
            url = null
            clearImage()
            invalidate()
            return
        }
        val want: String = avatarUrl
        if (want == url && (bitmap != null || anim != null)) {
            invalidate()
            return
        }
        url = want
        clearImage()
        invalidate()
        if (isGifUrl(want)) {
            ImageLoader.loadBytes(want) { b ->
                if (url == want && b != null) setImageBytes(b)
            }
        } else {
            ImageLoader.load(want, 512) { b ->
                if (url == want && b != null) {
                    setBitmapDirect(b)
                }
            }
        }
    }

    fun setBitmapDirect(b: Bitmap) {
        clearImage()
        bitmap = b
        shader = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        invalidate()
    }

    /** Mostra um GIF (animado no Android 9+; nos mais antigos aparece o primeiro quadro). */
    fun setImageBytes(bytes: ByteArray) {
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                val src = ImageDecoder.createSource(ByteBuffer.wrap(bytes))
                val dr = ImageDecoder.decodeDrawable(src) { dec, info, _ ->
                    val big = max(info.size.width, info.size.height)
                    if (big > 512) dec.setTargetSampleSize((big + 511) / 512)
                }
                if (dr is AnimatedImageDrawable) {
                    clearImage()
                    dr.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                    dr.callback = this
                    dr.setBounds(0, 0, dr.intrinsicWidth, dr.intrinsicHeight)
                    anim = dr
                    if (isAttachedToWindow) dr.start()
                    invalidate()
                    return
                }
            } catch (_: Exception) {
            }
        }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        if (bmp != null) setBitmapDirect(bmp)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim?.start()
    }

    override fun onDetachedFromWindow() {
        anim?.stop()
        super.onDetachedFromWindow()
    }

    override fun invalidateDrawable(who: Drawable) {
        invalidate()
    }

    override fun verifyDrawable(who: Drawable): Boolean = who === anim || super.verifyDrawable(who)

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - d * 3f
        val b = bitmap
        val sh = shader
        val gif = anim
        p.style = Paint.Style.FILL
        if (gif != null && gif.intrinsicWidth > 0 && gif.intrinsicHeight > 0) {
            val w = gif.intrinsicWidth.toFloat()
            val h = gif.intrinsicHeight.toFloat()
            val sc = max(2f * r / w, 2f * r / h)
            clip.reset()
            clip.addCircle(cx, cy, r, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(clip)
            canvas.translate(cx - w * sc / 2f, cy - h * sc / 2f)
            canvas.scale(sc, sc)
            gif.draw(canvas)
            canvas.restore()
        } else if (b != null && sh != null) {
            val sc = max(2f * r / b.width, 2f * r / b.height)
            val m = Matrix()
            m.setScale(sc, sc)
            m.postTranslate(cx - b.width * sc / 2f, cy - b.height * sc / 2f)
            sh.setLocalMatrix(m)
            p.shader = sh
            canvas.drawCircle(cx, cy, r, p)
        } else {
            p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r,
                0xFF7C4DFF.toInt(), 0xFF22D3EE.toInt(), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r, p)
            tp.textSize = r * 0.95f
            canvas.drawText(initial, cx, cy + tp.textSize * 0.34f, tp)
        }
        p.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(),
            0xE6FFFFFF.toInt(), 0x33FFFFFF, Shader.TileMode.CLAMP)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d * 2.2f
        canvas.drawCircle(cx, cy, r, p)
    }
}
