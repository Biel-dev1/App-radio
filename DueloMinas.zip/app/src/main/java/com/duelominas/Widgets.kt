package com.duelominas

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.View
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

/** Baixa e guarda fotos em memória. */
object ImageLoader {
    private val http = OkHttpClient()
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    /** Chama [done] sempre na thread principal. */
    fun load(url: String, maxPx: Int, done: (Bitmap?) -> Unit) {
        val cached = cache.get(url)
        if (cached != null) {
            done(cached)
            return
        }
        thread {
            var bmp: Bitmap? = null
            try {
                http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    val bytes = r.body?.bytes()
                    if (r.isSuccessful && bytes != null) {
                        val o = BitmapFactory.Options()
                        o.inJustDecodeBounds = true
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                        var s = 1
                        while (o.outWidth / (s * 2) >= maxPx && o.outHeight / (s * 2) >= maxPx) s *= 2
                        val o2 = BitmapFactory.Options()
                        o2.inSampleSize = s
                        bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
                    }
                }
            } catch (_: Exception) {
            }
            val result = bmp
            if (result != null) cache.put(url, result)
            Handler(Looper.getMainLooper()).post { done(result) }
        }
    }
}

/** Foto de perfil redonda com anel de vidro. Sem foto, mostra a inicial do nome. */
class AvatarView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private var bitmap: Bitmap? = null
    private var shader: BitmapShader? = null
    private var initial = "?"
    private var url: String? = null

    fun setPerson(name: String?, avatarUrl: String?) {
        initial = (name ?: "?").trim().take(1).uppercase().ifEmpty { "?" }
        if (avatarUrl.isNullOrEmpty()) {
            url = null
            bitmap = null
            shader = null
            invalidate()
            return
        }
        val want: String = avatarUrl
        if (want == url && bitmap != null) {
            invalidate()
            return
        }
        url = want
        bitmap = null
        shader = null
        invalidate()
        ImageLoader.load(want, 512) { b ->
            if (url == want && b != null) {
                setBitmapDirect(b)
            }
        }
    }

    fun setBitmapDirect(b: Bitmap) {
        bitmap = b
        shader = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - d * 3f
        val b = bitmap
        val sh = shader
        p.style = Paint.Style.FILL
        if (b != null && sh != null) {
            val sc = max(2f * r / b.width, 2f * r / b.height)
            val m = Matrix()
            m.setScale(sc, sc)
            m.postTranslate(cx - b.width * sc / 2f, cy - b.height * sc / 2f)
            sh.setLocalMatrix(m)
            p.shader = sh
            canvas.drawCircle(cx, cy, r, p)
        } else {
            p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r,
                0xFF7C4DFF.toInt(), 0xFF22D3EE.toInt(), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r, p)
            tp.textSize = r * 0.95f
            canvas.drawText(initial, cx, cy + tp.textSize * 0.34f, tp)
        }
        p.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(),
            0xE6FFFFFF.toInt(), 0x33FFFFFF, Shader.TileMode.CLAMP)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d * 2.2f
        canvas.drawCircle(cx, cy, r, p)
    }
}
