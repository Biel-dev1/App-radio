# R8 no release: ofusca nomes e remove código morto.
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# Não deixa o mapa de nomes legível no APK
-repackageclasses 'd'
-allowaccessmodification
-overloadaggressively

# Stack trace mínimo (sem path do fonte)
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# OkHttp / JSON usados por reflexão mínima
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-dontwarn javax.annotation.**

# FileProvider e entry points do Android
-keep class androidx.core.content.FileProvider { *; }
-keep class com.duelominas.MainActivity { *; }

# Não manter nomes de pacote legíveis do jogo (exceto Activity)
-keepnames class com.duelominas.MainActivity
