# R8 ligado no release: ofusca o código e remove o que não é usado.
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
